# TrackTWLite v1 beta9 fix31.7.13

Changes from fix31.7.12:
- Category edits remain local-first, but are now tracked with a durable `categorySyncPending` flag.
- A manual category change no longer silently swallows Track.TW PUT failures.
- After `PUT /package/setting/{userPackageId}`, Packly re-fetches the matching inbox/archive list and verifies `extra.category` actually matches the local category before marking sync complete.
- Verification retries briefly for eventual-consistency lag.
- If Track.TW still differs or the PUT fails, the local category is kept, the sync remains pending, and the real API/verification error is surfaced.
- Background inbox/archive refresh retries Packly-owned categories through the same verified write path.
- Room schema upgraded from v9 to v10 with a non-destructive migration for `categorySyncPending`.


## fix31.7.14
- Packly category is now strictly local-only (Room).
- Removed all Track.TW category import/reconciliation from UserPackage.extra.
- Removed all category PUTs to `/package/setting/{id}`.
- Existing Track.TW extra is still preserved unchanged when editing note/notification settings.
- Amount remains local-only; note and notify_state continue using official Track.TW APIs.

## fix31.7.18 — Polling / arrival-notification reliability
- FULL 30-minute polling also checks `/package/tracking/{id}` for up to 12 non-terminal
  inbox packages per cycle, rotating the window for larger inboxes. A stale summary
  can no longer indefinitely hide a newer arrival visible in package details.
- Background, home, widget and detail refreshes share notification dispatch. Opening
  details no longer silently consumes a transition without checking local alerts.
- Android device alerts are queued persistently before posting, deduplicated by
  package + stage + event time, and retried on later sync if permissions/channel
  settings block the initial post. Explicitly disabling Packly alerts clears the queue.
  This cannot retroactively reconstruct transitions that happened before the upgrade.
- The official Track.TW `notify_state` remains separate from Packly's own Android
  alerts. New import still requests `active`, but the server's returned state is
  authoritative. Missing server state is displayed as unknown rather than falsely off;
  updating the bell checks a fresh server response instead of blindly claiming success.
- Device pickup reminders are no longer marked sent if Android blocks posting.
- Scope: source change only. Requires Android Gradle build + on-device API verification.
