# TrackTWLite fix31.7.18 — on-device regression checklist

These are **manual tests to run after building/installing**. No real Track.TW API
or Android notification permission was available in the authoring environment.

1. Add a new package, check its server-side bell state in both the returned list
   and package detail. The server may force imported packages to `inactive` even
   when the request explicitly asks for `active`; Packly must not fake `active`.
   Missing `notify_state` should show the unknown bell, not the crossed-out bell.
2. With Packly device notifications enabled, leave a package in transit. Wait for
   its status to become arrived *in the tracking endpoint*, while the summary
   endpoint still says in transit. Let the 30-minute background WorkManager poll
   run. Within the selected detail-check rotation the home screen and widget
   should show arrived and one local arrival notification should be posted.
3. Open details for a different package just after its status changes from in
   transit to arrived. The new status must be written to Room and the shared
   notification logic must run once; later background polls must not duplicate it.
4. Revoke Android notification permission before an arrival. Once a poll detects
   the transition, grant permission and run another sync while the package is
   still at the same stage. The queued alert should then post once; it must not
   be marked delivered while permissions were blocked.
5. Explicitly disable Packly device notifications, run a sync, and re-enable:
   old disabled-stage events must not be replayed. Track.TW official bell status
   must not alter Packly's own notification settings.
6. Disable the Android "物流更新" channel: an arrival must remain queued. Re-enable
   it and refresh; expect one alert. Test pickup-deadline reminders similarly.
7. Confirm no false arrivals when a package already arrived before first import,
   when detail returns older/empty history, or when a package is fully archived.
8. Verify an App update does not clear Room/amount/category or the 30-minute
   polling preference, and note any Track.TW 429/rate limits in `PacklySync` logs.
