package tw.tracklite.data.api

import retrofit2.Response
import retrofit2.http.*
import tw.tracklite.data.model.*

interface TrackApi {
    @GET("carrier/available")
    suspend fun carriers(): List<Carrier>

    @POST("carrier/detect")
    suspend fun detect(@Body body: DetectRequest): DetectResponse

    @GET("package/all/{folder}")
    suspend fun packages(
        @Path("folder") folder: String,
        @Query("page") page: Int,
        @Query("size") size: Int,
        @Query("q") query: String? = null,
        @Query("delivery_stage") deliveryStage: String? = null,
        @Query("sort_by") sortBy: String = "created_at",
        @Query("sort_direction") sortDirection: String = "desc"
    ): PackagePage

    @POST("package/import")
    suspend fun importPackage(@Body body: ImportRequest): Response<Unit>

    @GET("package/tracking/{id}")
    suspend fun tracking(@Path("id") userPackageId: String): TrackingPackage

    @PUT("package/setting/{id}")
    suspend fun updatePackageSetting(
        @Path("id") userPackageId: String,
        @Body body: PackageSettingRequest
    ): Response<Unit>

    @PATCH("package/state/{id}/{state}")
    suspend fun move(
        @Path("id") userPackageId: String,
        @Path("state") action: String
    ): Response<Unit>
}
