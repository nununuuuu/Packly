package tw.tracklite.widget

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.*
import androidx.glance.appwidget.*
import androidx.glance.appwidget.action.actionStartActivity
import androidx.glance.action.clickable
import androidx.glance.layout.*
import androidx.glance.text.*
import androidx.glance.unit.ColorProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import tw.tracklite.EXTRA_SCREEN
import tw.tracklite.EXTRA_STATUS_FILTER
import tw.tracklite.MainActivity
import tw.tracklite.R
import tw.tracklite.TrackLiteApp
import tw.tracklite.data.db.PackageEntity
import java.io.File
import java.net.URL

private val widgetBackground = ColorProvider(Color(0xFFF7F3F8))
private val widgetPanel = ColorProvider(Color(0xFFE9E6EA))
private val widgetText = ColorProvider(Color(0xFF1D1B20))

// Compatibility helpers used by existing notification/background code.
fun recordWidgetSyncSuccess(context: Context) = WidgetSyncStatus.recordSuccess(context)
fun recordWidgetSyncFailure(context: Context) = WidgetSyncStatus.recordFailure(context)

private fun openAppIntent(context: Context, statusFilter: String? = null, screen: String = "home") =
    android.content.Intent(context, MainActivity::class.java).apply {
        flags = android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP
        putExtra(EXTRA_SCREEN, screen)
        statusFilter?.let { putExtra(EXTRA_STATUS_FILTER, it) }
    }

private fun carrierLogoUrl(logo: String?): String? {
    val value = logo?.trim().orEmpty()
    if (value.isBlank()) return null
    return if (value.startsWith("http://") || value.startsWith("https://")) value else "https://track.tw/storage/$value"
}

/** Best-effort cache warmer. Native widget rendering itself never touches network. */
suspend fun refreshWidgetCarrierLogoCache(context: Context, items: List<PackageEntity>) = withContext(Dispatchers.IO) {
    if (items.isEmpty()) return@withContext
    val dir = File(context.cacheDir, "widget_carrier_logos").apply { mkdirs() }
    val missingItems = items.filter { item ->
        val cache = File(dir, "${item.carrierId.ifBlank { item.carrierName.hashCode().toString() }}.img")
        !cache.exists() || cache.length() <= 0
    }
    if (missingItems.isEmpty()) return@withContext

    val app = context.applicationContext as TrackLiteApp
    val carriers = runCatching { app.container.repository.carriers() }.getOrDefault(emptyList())
    if (carriers.isEmpty()) return@withContext
    val carrierById = carriers.associateBy { it.id }
    missingItems.forEach { item ->
        val cache = File(dir, "${item.carrierId.ifBlank { item.carrierName.hashCode().toString() }}.img")
        val carrier = carrierById[item.carrierId] ?: carriers.firstOrNull { it.name == item.carrierName }
        val url = carrierLogoUrl(carrier?.logo) ?: return@forEach
        runCatching {
            URL(url).openConnection().apply { connectTimeout = 5000; readTimeout = 5000 }.getInputStream().use { input ->
                val bytes = input.readBytes()
                if (bytes.isNotEmpty()) cache.writeBytes(bytes)
            }
        }
    }
}

/** The small two-tile overview remains Glance; only the interactive package-list widget is native RemoteViews. */
class PackageSummaryWidget : GlanceAppWidget() {
    override suspend fun provideGlance(context: Context, id: androidx.glance.GlanceId) {
        val items = (context.applicationContext as TrackLiteApp).container.db.packages().inbox()
        val arrived = items.count { it.deliveryStage == "arrived" }
        val transit = items.count { it.deliveryStage in setOf("in_transit", "out_for_delivery") }
        provideContent { SummaryContent(context, arrived, transit) }
    }

    @Composable
    private fun SummaryContent(context: Context, arrived: Int, transit: Int) {
        Column(
            modifier = GlanceModifier.fillMaxSize().background(widgetBackground).cornerRadius(R.dimen.widget_radius_large).padding(8.dp)
        ) {
            SummaryTile(context, "📦", "待取件", arrived, "arrived", GlanceModifier.defaultWeight().fillMaxWidth())
            Spacer(GlanceModifier.height(7.dp))
            SummaryTile(context, "🚚", "配送中", transit, "transit", GlanceModifier.defaultWeight().fillMaxWidth())
        }
    }

    @Composable
    private fun SummaryTile(context: Context, icon: String, label: String, count: Int, statusFilter: String, modifier: GlanceModifier) {
        Row(
            modifier = modifier
                .background(widgetPanel)
                .cornerRadius(R.dimen.widget_radius_medium)
                .padding(horizontal = 10.dp, vertical = 8.dp)
                .clickable(actionStartActivity(openAppIntent(context, statusFilter))),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(icon, style = TextStyle(fontSize = 16.sp))
            Spacer(GlanceModifier.width(5.dp))
            Text(label, style = TextStyle(color = widgetText, fontWeight = FontWeight.Bold, fontSize = 16.sp))
            Spacer(GlanceModifier.defaultWeight())
            Text(count.toString(), style = TextStyle(color = widgetText, fontWeight = FontWeight.Bold, fontSize = 30.sp))
        }
    }

    companion object {
        suspend fun updateAll(context: Context) { PackageSummaryWidget().updateAll(context) }
    }
}

suspend fun updatePacklyWidgets(context: Context) {
    WidgetInvalidator(context).packagesChanged()
}

// Compatibility with one-shot work that may survive an app upgrade from older fixes.
class WidgetRefreshWorker(ctx: Context, params: androidx.work.WorkerParameters) : androidx.work.CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        runCatching { WidgetInvalidator(applicationContext).packagesChanged() }
        return Result.success()
    }
}

class PackageSummaryWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = PackageSummaryWidget()
}
