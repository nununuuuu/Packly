package tw.tracklite.data.repo

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.delay
import kotlinx.coroutines.CancellationException
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import tw.tracklite.data.api.TrackApi
import tw.tracklite.data.db.PackageDao
import tw.tracklite.data.db.PackageEntity
import tw.tracklite.data.db.CategoryDao
import tw.tracklite.data.db.CategoryEntity
import tw.tracklite.data.model.*
import android.util.Log

class PackageRepository(
    private val api: TrackApi,
    private val dao: PackageDao,
    private val categoryDao: CategoryDao
) {
    fun observeInbox(): Flow<List<PackageEntity>> = dao.observeInbox()
    fun observeArchive(): Flow<List<PackageEntity>> = dao.observeArchive()
    fun observeCategories(): Flow<List<CategoryEntity>> = categoryDao.observeAll()

    suspend fun ensureDefaultCategories() {
        if (categoryDao.count() > 0) return
        categoryDao.upsert(defaultCategories())
    }

    suspend fun addCategory(name: String, iconType: String, iconValue: String) {
        val clean = name.trim()
        if (clean.isBlank()) return
        val order = categoryDao.all().maxOfOrNull { it.sortOrder }?.plus(1) ?: 0
        categoryDao.upsert(CategoryEntity(java.util.UUID.randomUUID().toString(), clean, iconType, iconValue, order))
    }

    suspend fun updateCategory(category: CategoryEntity, name: String, iconType: String, iconValue: String) {
        val clean = name.trim()
        if (clean.isBlank()) return
        if (clean != category.name) dao.renameCategory(category.name, clean)
        categoryDao.upsert(category.copy(name = clean, iconType = iconType, iconValue = iconValue))
    }

    suspend fun deleteCategory(category: CategoryEntity) {
        dao.clearCategory(category.name)
        categoryDao.delete(category)
    }

    suspend fun carriers(): List<Carrier> = api.carriers()

    suspend fun detectCarrier(trackingNumber: String, known: List<Carrier>): List<Carrier> {
        val response = api.detect(DetectRequest(listOf(trackingNumber.trim())))
        return known.filter { carrier ->
            response.carriers.any { candidate ->
                candidate.equals(carrier.id, ignoreCase = true) || candidate.equals(carrier.name, ignoreCase = true)
            }
        }
    }

    suspend fun detectCarriersBatch(trackingNumbers: List<String>, known: List<Carrier>): Map<String, List<Carrier>> {
        val clean = trackingNumbers.map { it.trim() }.filter { it.isNotBlank() }.distinct()
        if (clean.isEmpty()) return emptyMap()
        val response = api.detect(DetectRequest(clean))
        // Track.TW accepts multiple tracking_numbers. When the response preserves one carrier
        // entry per input, map them directly. If not, fall back to single-number detection so
        // an ambiguous response never assigns the wrong carrier to a package.
        if (response.carriers.size == clean.size) {
            return clean.mapIndexed { index, number ->
                val candidate = response.carriers[index]
                number to known.filter { carrier ->
                    candidate.equals(carrier.id, ignoreCase = true) || candidate.equals(carrier.name, ignoreCase = true)
                }
            }.toMap()
        }
        return clean.associateWith { number -> detectCarrier(number, known) }
    }

    suspend fun importPackage(
        carrier: Carrier,
        trackingNumber: String,
        title: String,
        requirementValues: Map<String, String>
    ) {
        val number = trackingNumber.trim()
        val display = title.trim()
        val encoded = if (display.isBlank()) number else "$number,$display"
        val extras = requirementValues.filterValues { it.isNotBlank() }
        val response = api.importPackage(
            ImportRequest(
                carrierId = carrier.id,
                trackingNumber = listOf(encoded),
                notifyState = "active",
                extraFields = if (extras.isEmpty()) emptyMap() else mapOf(number to extras)
            )
        )
        if (!response.isSuccessful) {
            error("匯入失敗：HTTP ${response.code()} ${response.errorBody()?.string().orEmpty()}")
        }
        syncInbox()
        dao.inbox().firstOrNull { it.trackingNumber.equals(number, ignoreCase = true) }?.let { item ->
            dao.setExtraFieldsJson(item.id, encodeExtraFields(extras))
        }
    }


    suspend fun importPackages(drafts: List<PackageImportDraft>) {
        val clean = drafts.filter { it.trackingNumber.isNotBlank() }
        if (clean.isEmpty()) return
        clean.groupBy { it.carrier.id }.forEach { (_, group) ->
            val carrier = group.first().carrier
            val numbers = group.map { draft ->
                val number = draft.trackingNumber.trim()
                val display = draft.title.trim()
                if (display.isBlank()) number else "$number,$display"
            }
            val extraFields = buildMap {
                group.forEach { draft ->
                    val number = draft.trackingNumber.trim()
                    val extras = draft.requirementValues.filterValues { it.isNotBlank() }
                    if (extras.isNotEmpty()) put(number, extras)
                }
            }
            val response = api.importPackage(
                ImportRequest(
                    carrierId = carrier.id,
                    trackingNumber = numbers,
                    notifyState = "active",
                    extraFields = extraFields
                )
            )
            if (!response.isSuccessful) {
                error("匯入失敗：HTTP ${response.code()} ${response.errorBody()?.string().orEmpty()}")
            }
        }
        syncInbox()
        var inbox = dao.inbox()
        val expected = clean.map { it.trackingNumber.trim().uppercase() }.toSet()
        if (!expected.all { number -> inbox.any { it.trackingNumber.trim().uppercase() == number } }) {
            delay(1200L)
            syncInbox()
            inbox = dao.inbox()
        }
        clean.forEach { draft ->
            val item = inbox.firstOrNull { it.trackingNumber.equals(draft.trackingNumber.trim(), ignoreCase = true) } ?: return@forEach
            // `draft.title` is sent to Track.TW as the official package note via /package/import.
            // Do not duplicate it into the legacy local customTitle field; the next API sync is authoritative.
            // Persist the carrier requirement values used by import for future recovery/debug flows.
            val savedExtras = draft.requirementValues.filterValues { it.isNotBlank() }
            dao.setExtraFieldsJson(item.id, encodeExtraFields(savedExtras))
            if (draft.amount != null) dao.setAmount(item.id, draft.amount)
            if (draft.category.isNotBlank()) {
                // Packly category is intentionally local-only. Do not read/write Track.TW extra.category.
                dao.setCategory(item.id, draft.category.trim())
            }
        }
    }

    suspend fun syncInbox(
        query: String? = null,
        deliveryStage: String? = null,
        enrichTracking: Boolean = true
    ): SyncResult {
        val before = dao.inbox().associateBy { it.id }
        val page = api.packages(
            folder = "inbox",
            page = 1,
            size = 100,
            query = query?.takeIf { it.isNotBlank() },
            deliveryStage = deliveryStage?.takeIf { it.isNotBlank() }
        )
        val entities = page.data.map { up -> up.toEntity(before[up.id]) }
        dao.upsert(entities)

        if (enrichTracking) {
            // The inbox API can lag behind /package/tracking even when a polling cycle succeeds.
            // Check active packages, not only those already marked "arrived" by the inbox API.
            // Cap the number of detail requests and rotate the window each 30-minute epoch so
            // large inboxes are covered over successive cycles without hammering the API.
            val candidates = entities.filter { item ->
                item.deliveryStage !in setOf("delivered", "picked_up", "returned", "cancel", "lost")
            }.sortedBy { it.id }
            if (candidates.isNotEmpty()) {
                val epoch = System.currentTimeMillis() / (30L * 60L * 1000L)
                val start = ((epoch * MAX_DETAIL_CHECKS) % candidates.size).toInt()
                val selected = (0 until minOf(MAX_DETAIL_CHECKS, candidates.size))
                    .map { candidates[(start + it) % candidates.size] }
                selected.forEach { item ->
                    try {
                        tracking(item.id)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        Log.w("PacklySync", "Detail reconciliation failed for ${item.id}", e)
                    }
                }
                Log.i("PacklySync", "Detail reconciliation: ${selected.size}/${candidates.size} active packages checked")
            }
        }

        val finalItems = dao.inbox()
        val changes = finalItems.mapNotNull { new ->
            val old = before[new.id]
            if (old != null && isNewStage(old, new)) {
                PackageChange(old, new)
            } else null
        }
        return SyncResult(finalItems, page.counts.orEmpty(), changes)
    }

    suspend fun loadArchive(): List<PackageEntity> {
        val old = dao.folder("archive").associateBy { it.id }
        val page = api.packages("archive", 1, 100)
        val entities = page.data.map { it.toEntity(old[it.id]).copy(folder = "archive", archived = true) }
        dao.upsert(entities)
        return dao.folder("archive")
    }

    suspend fun autoArchiveDelivered(now: Long = System.currentTimeMillis()): Int {
        val cutoff = now - 48L * 60L * 60L * 1000L
        val due = dao.inbox().filter { it.deliveryStage == "delivered" && it.deliveredAt > 0L && it.deliveredAt <= cutoff }
        var count = 0
        due.forEach { item ->
            runCatching { archive(item.id) }.onSuccess { count++ }
        }
        return count
    }

    suspend fun tracking(userPackageId: String): TrackingPackage {
        val tracking = api.tracking(userPackageId)
        cacheTracking(userPackageId, tracking)
        return tracking
    }

    suspend fun packageById(id: String): PackageEntity? = dao.byId(id)

    suspend fun inboxSnapshot(): List<PackageEntity> = dao.inbox()

    suspend fun refreshPackage(userPackageId: String): PackageEntity? {
        tracking(userPackageId)
        return dao.byId(userPackageId)
    }

    private suspend fun cacheTracking(userPackageId: String, tracking: TrackingPackage) {
        val old = dao.byId(userPackageId)
        val latest = tracking.packageHistory.maxWithOrNull(compareBy<PackageHistory> { it.time ?: 0L }.thenBy { it.createdAt ?: "" })
        val candidateTime = latest?.time ?: 0L
        // An empty/older detail response must never erase a newer inbox event.
        val keepExistingEvent = old != null && old.eventTime > 0L &&
            (latest == null || candidateTime <= 0L || candidateTime < old.eventTime)
        val entity = PackageEntity(
            id = userPackageId,
            trackingNumber = tracking.trackingNumber,
            carrierId = tracking.carrierId.orEmpty(),
            carrierName = tracking.carrier?.name.orEmpty(),
            title = old?.title.orEmpty(),
            latestStatus = if (keepExistingEvent) old!!.latestStatus else (latest?.status ?: latest?.checkpointStatus ?: "尚無貨態"),
            checkpointStatus = if (keepExistingEvent) old!!.checkpointStatus else latest?.checkpointStatus.orEmpty(),
            deliveryStage = if (keepExistingEvent) old!!.deliveryStage else latest?.deliveryStage.orEmpty(),
            latestEventKey = if (keepExistingEvent) old!!.latestEventKey else eventKey(latest),
            eventTime = if (keepExistingEvent) old!!.eventTime else candidateTime,
            updatedAt = if (keepExistingEvent) old!!.updatedAt else (tracking.updatedAt ?: latest?.createdAt.orEmpty()),
            // /package/tracking is not an authoritative source for the official notify_state.
            notifyState = old?.notifyState.orEmpty(),
            pickupReminderFlags = old?.pickupReminderFlags ?: 0,
            userExtraJson = old?.userExtraJson.orEmpty(),
            folder = old?.folder ?: "inbox",
            archived = old?.archived ?: false,
            customTitle = old?.customTitle.orEmpty(),
            amount = old?.amount,
            category = old?.category.orEmpty(),
            pickupStore = pickupStoreValue(tracking.metadata) ?: old?.pickupStore.orEmpty(),
            pickupDeadline = metadataValue(tracking.metadata, listOf("pickup_deadline", "deadline", "expire", "expiry", "pickup_date", "取件期限", "領取期限")) ?: old?.pickupDeadline.orEmpty(),
            extraFieldsJson = old?.extraFieldsJson.orEmpty(),
            deliveredAt = when {
                (if (keepExistingEvent) old?.deliveryStage else latest?.deliveryStage) == "delivered" && (old?.deliveredAt ?: 0L) == 0L -> System.currentTimeMillis()
                (if (keepExistingEvent) old?.deliveryStage else latest?.deliveryStage) == "delivered" -> old?.deliveredAt ?: 0L
                else -> 0L
            }
        )
        dao.upsert(entity)
    }

    private fun parseUserExtra(raw: String): com.google.gson.JsonObject {
        if (raw.isBlank()) return com.google.gson.JsonObject()
        return runCatching {
            val parsed = com.google.gson.JsonParser.parseString(raw)
            if (parsed.isJsonObject) parsed.asJsonObject.deepCopy() else com.google.gson.JsonObject()
        }.getOrDefault(com.google.gson.JsonObject())
    }

    private fun encodeUserExtra(extra: com.google.gson.JsonElement?): String {
        if (extra == null || extra.isJsonNull) return ""
        return Gson().toJson(extra)
    }

    private suspend fun updateUserPackageSetting(
        item: PackageEntity,
        note: String = item.title,
        notifyState: String = item.notifyState
    ): PackageEntity? {
        // Preserve Track.TW's existing extra object for unrelated setting edits (note/notify),
        // but Packly never imports, interprets, or writes official category fields.
        val extra = parseUserExtra(item.userExtraJson)
        val extraElement: com.google.gson.JsonElement =
            if (extra.entrySet().isEmpty()) com.google.gson.JsonNull.INSTANCE else extra
        val request = PackageSettingRequest(
            id = item.id,
            note = note.trim(),
            // A missing official notify_state is unknown, NOT implicitly "active".
            notifyState = notifyState.takeIf { it in setOf("active", "inactive", "complete", "abort") }
                ?: error("官方通知狀態尚未取得，請先同步或明確設定鈴鐺狀態"),
            pickupReminderFlags = item.pickupReminderFlags,
            state = item.folder.ifBlank { if (item.archived) "archive" else "inbox" },
            extra = extraElement
        )
        val response = api.updatePackageSetting(item.id, request)
        if (!response.isSuccessful) {
            error("更新包裹設定失敗：HTTP ${response.code()} ${response.errorBody()?.string().orEmpty()}")
        }

        // Mirror the successful server mutation immediately. A subsequent list sync remains authoritative.
        dao.upsert(
            item.copy(
                title = request.note,
                notifyState = request.notifyState,
                category = item.category,
                userExtraJson = encodeUserExtra(extraElement)
            )
        )
        return dao.byId(item.id)
    }

    suspend fun setNote(id: String, note: String): PackageEntity? {
        val item = dao.byId(id) ?: return null
        val updated = updateUserPackageSetting(item, note = note)
        // Official client re-fetches the list after PUT /package/setting/{id}; do the same so
        // normalized note=null/empty and any server-side adjustments are reconciled into Room.
        if (item.folder == "archive" || item.archived) loadArchive() else syncInbox(enrichTracking = false)
        return dao.byId(id) ?: updated
    }

    suspend fun setNotifyEnabled(id: String, enabled: Boolean): PackageEntity? {
        val item = dao.byId(id) ?: return null
        if (item.notifyState == "complete" || item.notifyState == "abort") return item
        val target = if (enabled) "active" else "inactive"
        val updated = updateUserPackageSetting(item, notifyState = target)
        // Re-read the server value instead of treating a successful PUT as proof that Track.TW
        // actually enabled active tracking for an API-imported package.
        val serverPage = try {
            api.packages(if (item.folder == "archive" || item.archived) "archive" else "inbox", 1, 100)
        } catch (e: Exception) {
            // PUT succeeded, but the read-back failed. Keep the server state explicitly unknown.
            dao.byId(id)?.let { dao.upsert(it.copy(notifyState = "")) }
            throw e
        }
        val serverValue = serverPage.data.firstOrNull { it.id == id }?.notifyState
        val confirmed = serverValue?.takeIf { it in setOf("active", "inactive", "complete", "abort") }
        val current = dao.byId(id) ?: updated
        if (current != null) dao.upsert(current.copy(notifyState = confirmed.orEmpty()))
        if (confirmed == null) error("官方 API 未回傳通知狀態，無法確認鈴鐺是否已變更")
        if (confirmed != target) error("官方目前通知狀態為 $confirmed，未確認切換成功")
        return dao.byId(id) ?: updated
    }

    suspend fun setAmount(id: String, amount: Long?) = dao.setAmount(id, amount)

    suspend fun setCategory(id: String, category: String): PackageEntity? {
        // Category is a Packly-local field only. Never call Track.TW and never reconcile
        // against UserPackage.extra.category.
        dao.setCategory(id, category.trim())
        return dao.byId(id)
    }

    suspend fun archive(id: String) = move(id, "archive")
    suspend fun restore(id: String) = move(id, "inbox")

    suspend fun delete(id: String) {
        move(id, "delete")
        dao.delete(id)
    }

    private suspend fun move(id: String, action: String) {
        val response = api.move(id, action)
        if (!response.isSuccessful) error("操作失敗：HTTP ${response.code()}")
        when (action) {
            "archive" -> dao.markArchived(id)
            // Restores are reconciled by the caller through PackageSyncCoordinator.
            // Do not hide a network refresh inside a repository mutation.
            "inbox" -> Unit
        }
    }

    private fun UserPackage.toEntity(old: PackageEntity?): PackageEntity {
        val p = pkg
        val latest = p?.latestPackageHistory
        val candidateTime = latest?.time ?: 0L
        // /package/all can occasionally lag behind /package/tracking. Never let a list refresh
        // roll Room back to an older (or lower-fidelity same-time) event that detail/background
        // sync has already persisted. Room is the monotonic source of truth for the UI.
        val keepExistingEvent = old != null && old.eventTime > 0L && (candidateTime <= 0L || candidateTime <= old.eventTime)
        val latestStatus = if (keepExistingEvent) old!!.latestStatus else (latest?.status ?: latest?.checkpointStatus ?: "尚無貨態")
        val checkpointStatus = if (keepExistingEvent) old!!.checkpointStatus else latest?.checkpointStatus.orEmpty()
        val deliveryStage = if (keepExistingEvent) old!!.deliveryStage else latest?.deliveryStage.orEmpty()
        val latestEventKey = if (keepExistingEvent) old!!.latestEventKey else eventKey(latest)
        val eventTime = if (keepExistingEvent) old!!.eventTime else candidateTime
        val eventUpdatedAt = if (keepExistingEvent) old!!.updatedAt else (updatedAt ?: latest?.createdAt.orEmpty())

        return PackageEntity(
            id = id,
            trackingNumber = p?.trackingNumber.orEmpty().ifBlank { old?.trackingNumber.orEmpty() },
            carrierId = p?.carrierId.orEmpty().ifBlank { old?.carrierId.orEmpty() },
            carrierName = p?.carrier?.name.orEmpty().ifBlank { old?.carrierName.orEmpty() },
            // Track.TW `note` is the authoritative package note. Keep it separate from the
            // tracking number: an empty note must remain empty and UI falls back to the number only for title display.
            title = note?.trim().orEmpty(),
            latestStatus = latestStatus,
            checkpointStatus = checkpointStatus,
            deliveryStage = deliveryStage,
            latestEventKey = latestEventKey,
            eventTime = eventTime,
            updatedAt = eventUpdatedAt,
            // If the list omits the field, retain a known prior value; otherwise show unknown.
            notifyState = notifyState?.takeIf { it in setOf("active", "inactive", "complete", "abort") }
                ?: old?.notifyState.orEmpty(),
            pickupReminderFlags = pickupReminderFlags,
            userExtraJson = encodeUserExtra(extra),
            folder = state,
            archived = state == "archive",
            customTitle = old?.customTitle.orEmpty(),
            amount = old?.amount,
            // Category is Packly-local only. Never import Track.TW extra.category.
            category = old?.category.orEmpty(),
            categoryManagedByPackly = false,
            categorySyncPending = false,
            pickupStore = old?.pickupStore.orEmpty(),
            pickupDeadline = old?.pickupDeadline.orEmpty(),
            extraFieldsJson = old?.extraFieldsJson.orEmpty(),
            deliveredAt = when {
                deliveryStage == "delivered" && (old?.deliveredAt ?: 0L) == 0L -> System.currentTimeMillis()
                deliveryStage == "delivered" -> old?.deliveredAt ?: 0L
                else -> 0L
            }
        )
    }

    private fun encodeExtraFields(values: Map<String, String>): String {
        val clean = values.filterValues { it.isNotBlank() }
        return if (clean.isEmpty()) "" else Gson().toJson(clean)
    }

    private fun decodeExtraFields(raw: String): Map<String, String> {
        if (raw.isBlank()) return emptyMap()
        return runCatching {
            val type = object : TypeToken<Map<String, String>>() {}.type
            Gson().fromJson<Map<String, String>>(raw, type).orEmpty().filterValues { it.isNotBlank() }
        }.getOrDefault(emptyMap())
    }

    private fun flattenMetadata(meta0: com.google.gson.JsonElement?): LinkedHashMap<String, String> {
        var meta = meta0 ?: return linkedMapOf()
        if (meta.isJsonPrimitive && meta.asJsonPrimitive.isString) {
            val raw = meta.asString.trim()
            if (raw.startsWith("{") || raw.startsWith("[")) {
                runCatching { com.google.gson.JsonParser.parseString(raw) }.getOrNull()?.let { meta = it }
            }
        }
        val flat = linkedMapOf<String, String>()
        fun walk(prefix: String, e: com.google.gson.JsonElement) {
            when {
                e.isJsonObject -> e.asJsonObject.entrySet().forEach { (k, v) -> walk(if (prefix.isBlank()) k else "$prefix.$k", v) }
                e.isJsonArray -> e.asJsonArray.forEachIndexed { i, v -> walk("$prefix[$i]", v) }
                e.isJsonPrimitive -> {
                    val value = when {
                        e.asJsonPrimitive.isString -> e.asString
                        e.asJsonPrimitive.isNumber -> e.asNumber.toString()
                        e.asJsonPrimitive.isBoolean -> if (e.asBoolean) "true" else "false"
                        else -> ""
                    }.trim()
                    if (value.isNotBlank()) flat[prefix] = value
                }
            }
        }
        when {
            meta.isJsonObject || meta.isJsonArray -> walk("", meta)
            meta.isJsonPrimitive -> flat["value"] = meta.asString
        }
        return flat
    }

    private fun metadataValue(meta0: com.google.gson.JsonElement?, keys: List<String>): String? {
        val flat = flattenMetadata(meta0)
        return keys.asSequence().mapNotNull { wanted ->
            flat.entries.firstOrNull { (k, _) ->
                val key = k.lowercase()
                val w = wanted.lowercase()
                key == w || key.endsWith(".$w") || key.contains(w)
            }?.value
        }.firstOrNull()
    }

    private fun pickupStoreValue(meta0: com.google.gson.JsonElement?): String? {
        val flat = flattenMetadata(meta0)
        if (flat.isEmpty()) return null
        fun find(keys: List<String>): String? = keys.asSequence().mapNotNull { wanted ->
            flat.entries.firstOrNull { (k, _) ->
                val key = k.lowercase()
                val w = wanted.lowercase()
                key == w || key.endsWith(".$w") || key.contains(w)
            }?.value
        }.firstOrNull()

        // Track.TW convenience-store metadata uses `dst` for "store name (address)".
        // Keep the raw combined value in Room; the UI splits it for home/detail display.
        find(listOf("dst"))?.takeIf { it.isNotBlank() }?.let { return it }

        val name = find(listOf(
            "pickup_store_name", "pickupStoreName", "store_name", "storeName", "shop_name", "shopName",
            "branch_name", "branchName", "recipient_store", "recipientStore", "pickup_store", "pickupStore",
            "pickup_point", "pickupPoint", "cvs_store_name", "CVSStoreName", "destination_name", "destinationName", "location_name", "locationName",
            "取件門市", "門市名稱", "取貨門市", "取件店舖", "取貨店舖", "門市"
        ))
        val address = find(listOf(
            "pickup_store_address", "pickupStoreAddress", "store_address", "storeAddress", "shop_address", "shopAddress",
            "branch_address", "branchAddress", "pickup_address", "pickupAddress", "recipient_address", "recipientAddress",
            "destination_address", "destinationAddress", "location_address", "locationAddress", "cvs_store_address", "CVSStoreAddress",
            "取件地址", "門市地址", "取貨地址"
        ))
        if (!name.isNullOrBlank() && !address.isNullOrBlank() && !name.contains(address, ignoreCase = true) && !address.contains(name, ignoreCase = true)) {
            return "$name（$address）"
        }
        if (!name.isNullOrBlank()) return name
        if (!address.isNullOrBlank()) return address

        val heuristic = flat.entries.firstOrNull { (k, v) ->
            val key = k.lowercase()
            (key.contains("store") || key.contains("shop") || key.contains("branch") || key.contains("pickup") || key.contains("門市") || key.contains("店舖")) &&
                !key.contains("id") && !key.contains("code") && v.length in 2..160
        }?.value
        return heuristic
    }

    private fun defaultCategories(): List<CategoryEntity> = listOf(
        CategoryEntity("food", "食物飲料", "material", "restaurant", 0),
        CategoryEntity("daily", "生活用品", "material", "shopping_basket", 1),
        CategoryEntity("home", "居家", "material", "home", 2),
        CategoryEntity("stationery", "文具", "material", "edit", 3),
        CategoryEntity("3c", "3C", "material", "devices", 4),
        CategoryEntity("appliance", "家電", "material", "kitchen", 5),
        CategoryEntity("clothing", "服飾配件", "material", "checkroom", 6),
        CategoryEntity("beauty", "美妝保養", "material", "face", 7),
        CategoryEntity("medical", "醫療保健", "material", "medical_services", 8),
        CategoryEntity("sports", "運動戶外", "material", "sports_soccer", 9),
        CategoryEntity("vehicle", "汽機車", "material", "directions_car", 10),
        CategoryEntity("tools", "工具", "material", "build", 11),
        CategoryEntity("building", "建材", "material", "construction", 12),
        CategoryEntity("tickets", "票券", "material", "confirmation_number", 13),
        CategoryEntity("books", "書籍", "material", "menu_book", 14),
        CategoryEntity("pets", "寵物", "material", "pets", 15),
        CategoryEntity("toys", "玩具", "material", "toys", 16),
        CategoryEntity("baby", "母嬰", "material", "child_care", 17),
        CategoryEntity("finance", "金融", "material", "account_balance", 18),
        CategoryEntity("non_product", "非商品", "material", "block", 19),
        CategoryEntity("other", "其他", "material", "category", 20)
    )

    private fun eventKey(h: PackageHistory?): String = listOf(
        h?.id,
        h?.status,
        h?.checkpointStatus,
        h?.deliveryStage,
        h?.time,
        h?.createdAt
    ).joinToString("|")

    companion object {
        private const val MAX_DETAIL_CHECKS = 12

        fun isNewStage(old: PackageEntity?, new: PackageEntity): Boolean =
            old != null && old.deliveryStage.isNotBlank() && new.deliveryStage.isNotBlank() &&
                old.deliveryStage != new.deliveryStage &&
                (old.latestEventKey != new.latestEventKey || old.eventTime != new.eventTime)
    }
}

data class PackageChange(val old: PackageEntity, val new: PackageEntity)
data class SyncResult(
    val items: List<PackageEntity>,
    val counts: Map<String, Int>,
    val changes: List<PackageChange>
)
