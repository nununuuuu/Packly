package tw.tracklite.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import retrofit2.HttpException
import tw.tracklite.TrackLiteApp
import tw.tracklite.data.db.PackageEntity
import tw.tracklite.data.db.CategoryEntity
import tw.tracklite.data.model.*
import tw.tracklite.notify.ChangeNotifier
import tw.tracklite.notify.DiscordNotifier
import tw.tracklite.notify.Notifications
import tw.tracklite.widget.WidgetSyncStatus
import tw.tracklite.data.sync.SyncMode
import tw.tracklite.data.sync.SyncSource
import tw.tracklite.worker.SyncScheduler
import java.io.IOException

enum class ApiStatus { NOT_CONFIGURED, CHECKING, CONNECTED, INVALID, NETWORK_ERROR }

data class MainState(
    val items: List<PackageEntity> = emptyList(),
    val archivedItems: List<PackageEntity> = emptyList(),
    val carriers: List<Carrier> = emptyList(),
    val categories: List<CategoryEntity> = emptyList(),
    val counts: Map<String, Int> = emptyMap(),
    val detail: TrackingPackage? = null,
    val selected: PackageEntity? = null,
    val loading: Boolean = false,
    val settingsLoaded: Boolean = false,
    val detailLoading: Boolean = false,
    val tokenPresent: Boolean = false,
    val apiStatus: ApiStatus = ApiStatus.NOT_CONFIGURED,
    val clipboardDetect: Boolean = true,
    val deviceNotifications: Boolean = true,
    val discordEnabled: Boolean = false,
    val discordWebhook: String = "",
    val discordSavedAt: Long = 0L,
    val themeColor: Int = 0xFF6750A4.toInt(),
    val syncIntervalMinutes: Int = 30,
    val autoArchiveDelivered: Boolean = true,
    val notificationStages: Set<String> = emptySet(),
    val pickupTomorrow: Boolean = true,
    val pickupFinalDay: Boolean = true,
    val autoCheckUpdates: Boolean = true,
    val homeAttentionTypes: Set<String> = setOf("final_day", "tomorrow", "exception", "lost"),
    val message: String? = null,
    val error: String? = null
)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val c = (app as TrackLiteApp).container
    private val mutable = MutableStateFlow(MainState())
    private var lastForegroundSyncAt = 0L
    private var foregroundSyncRunning = false
    val state: StateFlow<MainState> = combine(c.repository.observeInbox(), c.repository.observeArchive(), c.repository.observeCategories(), mutable) { items, archivedItems, categories, s ->
        val all = items + archivedItems
        val selected = s.selected?.let { old -> all.firstOrNull { it.id == old.id } ?: old }
        s.copy(items = items, archivedItems = archivedItems, categories = categories, selected = selected)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), MainState())

    init {
        viewModelScope.launch {
            c.repository.ensureDefaultCategories()
            val token = c.settings.token()
            mutable.update {
                it.copy(
                    tokenPresent = token.isNotBlank(),
                    apiStatus = if (token.isBlank()) ApiStatus.NOT_CONFIGURED else ApiStatus.CHECKING,
                    clipboardDetect = c.settings.clipboardDetect(),
                    deviceNotifications = c.settings.deviceNotifications(),
                    discordEnabled = c.settings.discordEnabled(),
                    discordWebhook = c.settings.discordWebhook(),
                    themeColor = c.settings.themeColor(),
                    syncIntervalMinutes = c.settings.syncIntervalMinutes(),
                    autoArchiveDelivered = c.settings.autoArchiveDelivered(),
                    notificationStages = c.settings.notificationStages(),
                    pickupTomorrow = c.settings.pickupTomorrow(),
                    pickupFinalDay = c.settings.pickupFinalDay(),
                    autoCheckUpdates = c.settings.autoCheckUpdates(),
                    homeAttentionTypes = c.settings.homeAttentionTypes(),
                    settingsLoaded = true
                )
            }
            if (token.isNotBlank()) verifyToken(loadData = true)
        }
    }

    fun saveToken(token: String) = viewModelScope.launch {
        val clean = token.trim().removePrefix("Bearer ").trim()
        c.settings.saveToken(clean)
        mutable.update {
            it.copy(
                tokenPresent = clean.isNotBlank(),
                apiStatus = if (clean.isBlank()) ApiStatus.NOT_CONFIGURED else ApiStatus.CHECKING,
                carriers = emptyList(), error = null
            )
        }
        if (clean.isNotBlank()) verifyToken(loadData = true)
    }

    fun clearToken() = viewModelScope.launch {
        c.settings.saveToken("")
        mutable.update { it.copy(tokenPresent = false, apiStatus = ApiStatus.NOT_CONFIGURED, carriers = emptyList(), counts = emptyMap(), message = "API Token 已清除") }
    }

    fun verifyToken(loadData: Boolean = false) = viewModelScope.launch {
        val token = c.settings.token()
        if (token.isBlank()) {
            mutable.update { it.copy(tokenPresent = false, apiStatus = ApiStatus.NOT_CONFIGURED) }
            return@launch
        }
        mutable.update { it.copy(tokenPresent = true, apiStatus = ApiStatus.CHECKING, error = null) }
        runCatching { c.repository.carriers() }
            .onSuccess { carriers ->
                mutable.update { it.copy(apiStatus = ApiStatus.CONNECTED, carriers = carriers, error = null) }
                if (loadData) refreshAll()
            }
            .onFailure { e ->
                mutable.update { it.copy(apiStatus = apiStatusFor(e), error = friendly(e)) }
            }
    }

    fun setClipboardDetect(v: Boolean) = viewModelScope.launch {
        c.settings.setClipboardDetect(v)
        mutable.update { it.copy(clipboardDetect = v) }
    }

    fun setDeviceNotifications(v: Boolean) = viewModelScope.launch {
        c.settings.setDeviceNotifications(v)
        mutable.update { it.copy(deviceNotifications = v) }
    }

    fun setNotificationStage(stage: String, enabled: Boolean) = viewModelScope.launch {
        val next = if (enabled) mutable.value.notificationStages + stage else mutable.value.notificationStages - stage
        c.settings.setNotificationStages(next)
        mutable.update { it.copy(notificationStages = next) }
    }

    fun setNotificationStages(stages: Set<String>) = viewModelScope.launch {
        c.settings.setNotificationStages(stages)
        mutable.update { it.copy(notificationStages = stages) }
    }

    fun setPickupTomorrow(v: Boolean) = viewModelScope.launch { c.settings.setPickupTomorrow(v); mutable.update { it.copy(pickupTomorrow = v) } }
    fun setPickupFinalDay(v: Boolean) = viewModelScope.launch { c.settings.setPickupFinalDay(v); mutable.update { it.copy(pickupFinalDay = v) } }
    fun setHomeAttentionTypes(types: Set<String>) = viewModelScope.launch { c.settings.setHomeAttentionTypes(types); mutable.update { it.copy(homeAttentionTypes = types) } }

    fun setAutoCheckUpdates(v: Boolean) = viewModelScope.launch { c.settings.setAutoCheckUpdates(v); mutable.update { it.copy(autoCheckUpdates = v) } }

    fun setDiscordEnabled(v: Boolean) = viewModelScope.launch {
        c.settings.setDiscordEnabled(v)
        mutable.update { it.copy(discordEnabled = v) }
    }

    fun setThemeColor(v: Int) = viewModelScope.launch {
        c.settings.setThemeColor(v)
        mutable.update { it.copy(themeColor = v) }
    }

    fun setAutoArchiveDelivered(v: Boolean) = viewModelScope.launch {
        c.settings.setAutoArchiveDelivered(v)
        mutable.update { it.copy(autoArchiveDelivered = v) }
        if (v) {
            runCatching { c.repository.autoArchiveDelivered() }
            runCatching { c.repository.loadArchive() }
        }
    }

    fun setSyncIntervalMinutes(v: Int) = viewModelScope.launch {
        val normalized = v.coerceAtLeast(15)
        c.settings.setSyncIntervalMinutes(normalized)
        SyncScheduler.ensureScheduled(getApplication(), normalized)
        mutable.update { it.copy(syncIntervalMinutes = normalized, message = "自動更新頻率已設為${syncIntervalLabel(normalized)}") }
    }

    fun testDeviceNotification() {
        Notifications.test(getApplication())
        mutable.update { it.copy(message = "Android 測試通知已送出") }
    }


    fun addCategory(name: String, iconType: String, iconValue: String) = viewModelScope.launch {
        val clean = name.trim()
        if (clean.isBlank()) {
            mutable.update { it.copy(error = "分類名稱不可空白") }
            return@launch
        }
        if (mutable.value.categories.any { it.name.equals(clean, ignoreCase = true) }) {
            mutable.update { it.copy(error = "已存在相同名稱的分類") }
            return@launch
        }
        c.repository.addCategory(clean, iconType, iconValue)
        mutable.update { it.copy(message = "已新增分類「$clean」") }
    }

    fun updateCategoryDefinition(category: CategoryEntity, name: String, iconType: String, iconValue: String) = viewModelScope.launch {
        val clean = name.trim()
        if (clean.isBlank()) {
            mutable.update { it.copy(error = "分類名稱不可空白") }
            return@launch
        }
        if (mutable.value.categories.any { it.id != category.id && it.name.equals(clean, ignoreCase = true) }) {
            mutable.update { it.copy(error = "已存在相同名稱的分類") }
            return@launch
        }
        c.repository.updateCategory(category, clean, iconType, iconValue)
        mutable.update { it.copy(message = "分類已更新") }
    }

    fun deleteCategoryDefinition(category: CategoryEntity) = viewModelScope.launch {
        c.repository.deleteCategory(category)
        mutable.update { it.copy(message = "已刪除分類「${category.name}」；原本使用此分類的包裹已改為未分類") }
    }

    fun saveDiscordWebhook(v: String) = viewModelScope.launch {
        val clean = v.trim()
        if (clean.isBlank()) {
            mutable.update { it.copy(error = "請先輸入 Discord Webhook URL") }
            return@launch
        }
        c.settings.setDiscordWebhook(clean)
        mutable.update { it.copy(discordWebhook = clean, discordSavedAt = System.currentTimeMillis(), message = "Discord Webhook 已儲存") }
    }

    fun testDiscord(webhook: String) = viewModelScope.launch {
        val clean = webhook.trim()
        if (clean.isBlank()) {
            mutable.update { it.copy(error = "請先輸入 Discord Webhook URL") }
            return@launch
        }
        mutable.update { it.copy(loading = true, error = null, message = null) }
        runCatching { DiscordNotifier.sendTest(clean) }
            .onSuccess {
                c.settings.setDiscordWebhook(clean)
                mutable.update { it.copy(discordWebhook = clean, discordSavedAt = System.currentTimeMillis(), message = "Discord 測試通知已送出") }
            }
            .onFailure { e -> mutable.update { it.copy(error = friendly(e)) } }
        mutable.update { it.copy(loading = false) }
    }

    fun consumeMessage() = mutable.update { it.copy(message = null) }
    fun consumeError() = mutable.update { it.copy(error = null) }

    fun refreshCarriers() = viewModelScope.launch {
        if (!requireApi()) return@launch
        runCatching { c.repository.carriers() }
            .onSuccess { list -> mutable.update { it.copy(carriers = list, apiStatus = ApiStatus.CONNECTED, error = null) } }
            .onFailure { e -> mutable.update { it.copy(apiStatus = apiStatusFor(e), error = friendly(e)) } }
    }

    fun detectForImport(trackingNumber: String, onResult: (List<Carrier>) -> Unit) = viewModelScope.launch {
        if (trackingNumber.isBlank()) {
            mutable.update { it.copy(error = "請先輸入物流單號") }
            onResult(emptyList())
            return@launch
        }
        if (!requireApi()) {
            onResult(emptyList())
            return@launch
        }
        try {
            val carriers = if (mutable.value.carriers.isEmpty()) c.repository.carriers().also { list -> mutable.update { it.copy(carriers = list) } } else mutable.value.carriers
            val found = c.repository.detectCarrier(trackingNumber, carriers)
            if (found.isEmpty()) mutable.update { it.copy(message = "無法自動辨識物流商，請手動選擇") }
            onResult(found)
        } catch (e: Throwable) {
            mutable.update { it.copy(apiStatus = apiStatusFor(e), error = friendly(e)) }
            onResult(emptyList())
        }
    }

    fun detectBatchForImport(trackingNumbers: List<String>, onResult: (Map<String, List<Carrier>>) -> Unit) = viewModelScope.launch {
        if (!requireApi()) { onResult(emptyMap()); return@launch }
        try {
            val carriers = if (mutable.value.carriers.isEmpty()) c.repository.carriers().also { list -> mutable.update { it.copy(carriers = list) } } else mutable.value.carriers
            val found = c.repository.detectCarriersBatch(trackingNumbers, carriers)
            onResult(found)
        } catch (e: Throwable) {
            mutable.update { it.copy(apiStatus = apiStatusFor(e), error = friendly(e)) }
            onResult(emptyMap())
        }
    }

    fun importPackages(drafts: List<PackageImportDraft>, onDone: () -> Unit = {}) = viewModelScope.launch {
        if (!requireApi()) return@launch
        if (drafts.isEmpty()) return@launch
        runBusy {
            c.repository.importPackages(drafts)
            c.syncCoordinator.refresh(SyncSource.APP_MANUAL, SyncMode.FAST)
            onDone()
        }
    }

    fun refreshAll() = viewModelScope.launch {
        if (!requireApi(silentIfChecking = true)) return@launch
        runBusy {
            try {
                val result = c.syncCoordinator.refresh(SyncSource.APP_MANUAL, SyncMode.FULL) {
                    if (c.settings.autoArchiveDelivered()) c.repository.autoArchiveDelivered()
                    c.repository.loadArchive()
                    WidgetSyncStatus.recordSuccess(getApplication())
                }
                if (c.settings.deviceNotifications()) checkPickupReminders(result.items)
                lastForegroundSyncAt = System.currentTimeMillis()
                mutable.update { it.copy(counts = result.counts, apiStatus = ApiStatus.CONNECTED) }
            } catch (e: Throwable) {
                WidgetSyncStatus.recordFailure(getApplication())
                runCatching { c.widgetInvalidator.packageWidgetOnly() }
                throw e
            }
        }
    }

    /**
     * Re-entering Packly should never keep showing a pre-notification snapshot.
     * Room remains the UI source of truth; this is a quiet foreground reconciliation
     * for cases where Android kept the Activity/ViewModel alive while background work ran.
     */
    fun refreshOnResume() {
        if (!mutable.value.settingsLoaded || !mutable.value.tokenPresent || foregroundSyncRunning) return
        val now = System.currentTimeMillis()
        if (now - lastForegroundSyncAt < 10_000L) return
        foregroundSyncRunning = true
        lastForegroundSyncAt = now
        viewModelScope.launch {
            try {
                val result = c.syncCoordinator.refresh(SyncSource.APP_RESUME, SyncMode.FULL) {
                    WidgetSyncStatus.recordSuccess(getApplication())
                }
                if (c.settings.deviceNotifications()) checkPickupReminders(result.items)
                mutable.update { it.copy(counts = result.counts, apiStatus = ApiStatus.CONNECTED) }
            } catch (_: Throwable) {
                WidgetSyncStatus.recordFailure(getApplication())
                runCatching { c.widgetInvalidator.packageWidgetOnly() }
                // Foreground reconciliation is intentionally silent; normal manual refresh still reports errors
            } finally {
                foregroundSyncRunning = false
            }
        }
    }

    fun refreshArchive() = viewModelScope.launch {
        if (!requireApi(silentIfChecking = true)) return@launch
        runBusy { c.repository.loadArchive(); c.widgetInvalidator.packagesChanged() }
    }

    fun openDetail(item: PackageEntity) = viewModelScope.launch {
        if (!requireApi()) return@launch
        mutable.update { it.copy(selected = item, detail = null, detailLoading = true, error = null) }
        runCatching { c.syncCoordinator.refreshDetail(item.id) }
            .onSuccess { detail -> mutable.update { it.copy(detail = detail, detailLoading = false, apiStatus = ApiStatus.CONNECTED) } }
            .onFailure { e -> mutable.update { it.copy(detailLoading = false, apiStatus = apiStatusFor(e), error = friendly(e)) } }
    }

    fun refreshDetail() = viewModelScope.launch {
        val item = mutable.value.selected ?: return@launch
        if (!requireApi()) return@launch
        mutable.update { it.copy(detailLoading = true, error = null) }
        runCatching { c.syncCoordinator.refreshDetail(item.id) }.onSuccess { detail ->
            mutable.update { it.copy(detail = detail, detailLoading = false, apiStatus = ApiStatus.CONNECTED) }
        }.onFailure { e -> mutable.update { it.copy(detailLoading = false, apiStatus = apiStatusFor(e), error = friendly(e)) } }
    }

    fun closeDetail() = mutable.update { it.copy(selected = null, detail = null, detailLoading = false) }

    fun updateTitle(title: String) = viewModelScope.launch {
        val id = mutable.value.selected?.id ?: return@launch
        runCatching { c.repository.setNote(id, title) }
            .onSuccess { updated ->
                mutable.update { state ->
                    state.copy(selected = updated ?: state.selected, apiStatus = ApiStatus.CONNECTED, error = null)
                }
                c.widgetInvalidator.packagesChanged()
            }
            .onFailure { e ->
                mutable.update { it.copy(apiStatus = apiStatusFor(e), error = friendly(e)) }
            }
    }

    fun updateAmount(amount: Long?) = viewModelScope.launch {
        val id = mutable.value.selected?.id ?: return@launch
        c.repository.setAmount(id, amount)
        mutable.update { it.copy(selected = it.selected?.copy(amount = amount)) }
        c.widgetInvalidator.packagesChanged()
    }

    fun updateCategory(category: String) = viewModelScope.launch {
        val id = mutable.value.selected?.id ?: return@launch
        // Category is Packly-local only; update the UI immediately and never sync it to Track.TW.
        mutable.update { state ->
            state.copy(
                selected = state.selected?.copy(
                    category = category.trim(),
                    categoryManagedByPackly = false,
                    categorySyncPending = false
                ),
                error = null
            )
        }
        runCatching { c.repository.setCategory(id, category) }
            .onSuccess { updated ->
                mutable.update { state ->
                    state.copy(selected = updated ?: state.selected, apiStatus = ApiStatus.CONNECTED, error = null)
                }
                c.widgetInvalidator.packagesChanged()
            }
            .onFailure { e ->
                mutable.update { it.copy(error = friendly(e)) }
                c.widgetInvalidator.packagesChanged()
            }
    }

    fun togglePackageNotifications() = viewModelScope.launch {
        val item = mutable.value.selected ?: return@launch
        if (item.notifyState == "complete" || item.notifyState == "abort") return@launch
        val enable = item.notifyState != "active"
        runCatching { c.repository.setNotifyEnabled(item.id, enable) }
            .onSuccess { updated ->
                mutable.update { state ->
                    state.copy(selected = updated ?: state.selected, apiStatus = ApiStatus.CONNECTED, error = null)
                }
                c.widgetInvalidator.packagesChanged()
            }
            .onFailure { e ->
                mutable.update { it.copy(apiStatus = apiStatusFor(e), error = friendly(e)) }
            }
    }

    fun archivePackages(ids: Set<String>) = viewModelScope.launch {
        if (!requireApi() || ids.isEmpty()) return@launch
        runBusy {
            ids.forEach { c.repository.archive(it) }
            c.syncCoordinator.refresh(SyncSource.APP_MANUAL, SyncMode.FAST)
            c.repository.loadArchive()
            mutable.update { it.copy(message = "已封存 ${ids.size} 個包裹") }
        }
    }

    fun restorePackages(ids: Set<String>) = viewModelScope.launch {
        if (!requireApi() || ids.isEmpty()) return@launch
        runBusy {
            ids.forEach { c.repository.restore(it) }
            c.syncCoordinator.refresh(SyncSource.APP_MANUAL, SyncMode.FAST)
            c.repository.loadArchive()
            mutable.update { it.copy(message = "已復原 ${ids.size} 個包裹") }
        }
    }

    fun deletePackages(ids: Set<String>) = viewModelScope.launch {
        if (!requireApi() || ids.isEmpty()) return@launch
        runBusy {
            ids.forEach { c.repository.delete(it) }
            c.repository.loadArchive()
            mutable.update { it.copy(message = "已刪除 ${ids.size} 個包裹") }
            c.widgetInvalidator.packagesChanged()
        }
    }

    fun archiveSelected() = viewModelScope.launch {
        val id = mutable.value.selected?.id ?: return@launch
        if (!requireApi()) return@launch
        runBusy {
            val item = mutable.value.selected
            if (item?.folder == "archive") c.repository.restore(id) else c.repository.archive(id)
            closeDetail()
            c.syncCoordinator.refresh(SyncSource.APP_MANUAL, SyncMode.FAST)
            c.repository.loadArchive()
        }
    }

    fun deleteSelected() = viewModelScope.launch {
        val id = mutable.value.selected?.id ?: return@launch
        if (!requireApi()) return@launch
        runBusy {
            c.repository.delete(id)
            closeDetail()
            c.widgetInvalidator.packagesChanged()
        }
    }

    private suspend fun checkPickupReminders(items: List<PackageEntity>) {
        val today = java.time.LocalDate.now()
        val sent = c.settings.pickupReminderKeys().toMutableSet()
        items.filter { it.deliveryStage == "arrived" && it.pickupDeadline.isNotBlank() }.forEach { item ->
            val deadline = runCatching { java.time.LocalDate.parse(item.pickupDeadline.take(10)) }.getOrNull() ?: return@forEach
            val days = java.time.temporal.ChronoUnit.DAYS.between(today, deadline)
            val kind = when {
                days == 0L && c.settings.pickupFinalDay() -> "final"
                days == 1L && c.settings.pickupTomorrow() -> "tomorrow"
                else -> null
            }
            if (kind != null) {
                val key = "${item.id}|$kind|$deadline"
                if (key !in sent) {
                    val posted = runCatching { Notifications.pickupDeadline(getApplication(), item, kind == "final") }.getOrDefault(false)
                    if (posted) {
                        c.settings.markPickupReminder(key)
                        sent += key
                    }
                }
            }
        }
    }

    private suspend fun requireApi(silentIfChecking: Boolean = false): Boolean {
        val token = c.settings.token()
        if (token.isBlank()) {
            mutable.update { it.copy(tokenPresent = false, apiStatus = ApiStatus.NOT_CONFIGURED, error = "尚未設定 Track.TW API Token，請先到設定完成設定") }
            return false
        }
        mutable.update { it.copy(tokenPresent = true) }
        if (mutable.value.apiStatus == ApiStatus.INVALID) {
            mutable.update { it.copy(error = "Track.TW API Token 無效，請重新設定") }
            return false
        }
        if (!silentIfChecking && mutable.value.apiStatus == ApiStatus.CHECKING) {
            mutable.update { it.copy(message = "正在驗證 Track.TW API Token，請稍候") }
            return false
        }
        return true
    }

    private suspend fun runBusy(block: suspend () -> Unit) {
        mutable.update { it.copy(loading = true, error = null, message = null) }
        runCatching { block() }
            .onFailure { e -> mutable.update { it.copy(apiStatus = apiStatusFor(e), error = friendly(e)) } }
        mutable.update { it.copy(loading = false) }
    }

    private fun apiStatusFor(e: Throwable): ApiStatus = when {
        e is HttpException && e.code() == 401 -> ApiStatus.INVALID
        e is IOException -> ApiStatus.NETWORK_ERROR
        "401" in e.message.orEmpty() -> ApiStatus.INVALID
        else -> mutable.value.apiStatus
    }

    private fun friendly(e: Throwable): String {
        if (e is HttpException) {
            return when (e.code()) {
                401 -> "Token 無效或已失效，請重新設定 API Token"
                403 -> "Track.TW 拒絕此操作"
                404 -> "找不到指定包裹"
                422 -> "送出的資料格式不符合 Track.TW API 規格"
                429 -> "API 查詢太頻繁，請稍後再試"
                else -> "Track.TW API 發生錯誤（HTTP ${e.code()}）"
            }
        }
        val m = e.message.orEmpty()
        return when {
            e is IOException -> "無法連線 Track.TW，請檢查網路後再試"
            m.startsWith("更新包裹設定失敗：") -> m
            m.startsWith("分類同步未完成：") -> m
            "401" in m -> "Token 無效或已失效，請重新設定 API Token"
            "422" in m -> "送出的資料格式不正確，請檢查物流單號與必要欄位"
            "429" in m -> "API 查詢太頻繁，請稍後再試"
            m.isBlank() -> "發生未知錯誤"
            else -> m
        }
    }
}

private fun syncIntervalLabel(minutes: Int): String = when (minutes) { 15 -> "15 分鐘"; 30 -> "30 分鐘"; 60 -> "1 小時"; 120 -> "2 小時"; else -> "$minutes 分鐘" }
