package tw.tracklite.notify

import android.content.Context
import android.util.Log
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import tw.tracklite.TrackLiteApp
import tw.tracklite.data.db.PackageEntity
import tw.tracklite.data.repo.PackageChange

/**
 * Shared delivery path for widget, worker, foreground and detail syncs.
 * A detected device alert is persisted BEFORE attempting to post it; a failed permission/
 * disabled channel does not consume the event. The next successful sync retries pending alerts.
 * The Track.TW server-side notify_state is intentionally unrelated to Packly local alerts.
 */
object ChangeNotifier {
    private val mutex = Mutex()

    suspend fun dispatch(context: Context, changes: List<PackageChange>, currentItems: List<PackageEntity>) = mutex.withLock {
        val app = context.applicationContext as TrackLiteApp
        val settings = app.container.settings
        val deviceEnabled = settings.deviceNotifications()
        val discordEnabled = settings.discordEnabled()
        val webhook = settings.discordWebhook()
        val enabledStages = settings.notificationStages()
        val sent = settings.statusNotificationKeys().toMutableSet()

        // Persist new events before attempting an Android post, even when POST_NOTIFICATIONS
        // permission is currently denied. Initial imports are not included in changes.
        if (deviceEnabled) {
            changes.forEach { change ->
                val item = change.new
                if (item.deliveryStage in enabledStages) {
                    val deviceKey = "device|${item.id}|${eventIdentity(item)}"
                    if (deviceKey !in sent) settings.queueDeviceEvent(deviceKey)
                }
            }
        }

        // Use current Room snapshots when retrying. If the shipment progressed again, discard
        // the stale earlier alert rather than claiming its old stage is still current.
        val byId = currentItems.associateBy { it.id }
        if (deviceEnabled) {
            settings.pendingDeviceEvents().forEach { key ->
                val itemId = key.removePrefix("device|").substringBefore('|')
                val item = byId[itemId]
                if (item == null || item.deliveryStage !in enabledStages ||
                    key != "device|${item.id}|${eventIdentity(item)}" || key in sent
                ) {
                    settings.removeDeviceEvent(key)
                } else {
                    val posted = runCatching { Notifications.changed(context, item) }
                        .onFailure { Log.w("PacklyNotify", "Could not post package alert", it) }
                        .getOrDefault(false)
                    if (posted) {
                        settings.markStatusNotification(key)
                        settings.removeDeviceEvent(key)
                        sent += key
                    } else {
                        Log.i("PacklyNotify", "Package alert queued until Android notifications are available")
                    }
                }
            }
        }

        // Discord remains independent of the device channel and official Track.TW notification
        // state. Never claim the webhook succeeded when HTTP delivery failed.
        changes.forEach { change ->
            val item = change.new
            val discordKey = "discord|${item.id}|${eventIdentity(item)}"
            if (discordEnabled && webhook.isNotBlank() && discordKey !in sent) {
                runCatching { DiscordNotifier.sendPackageUpdate(webhook, change.old, item) }
                    .onSuccess {
                        settings.markStatusNotification(discordKey)
                        sent += discordKey
                    }
                    .onFailure { Log.w("PacklyNotify", "Discord notification failed", it) }
            }
        }
    }

    private fun eventIdentity(item: PackageEntity): String {
        val timePart = if (item.eventTime > 0L) item.eventTime.toString() else item.latestEventKey.ifBlank { item.updatedAt }
        return "${item.deliveryStage}|$timePart"
    }
}
