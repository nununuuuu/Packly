package tw.tracklite.data.model

import com.google.gson.JsonElement
import com.google.gson.JsonNull
import com.google.gson.annotations.SerializedName

data class CarrierRequirement(
    val key: String = "",
    val desc: String? = null,
    val regex: String? = null,
    val placeholder: String? = null,
    @SerializedName("keyboard_type") val keyboardType: String? = null
)

data class Carrier(
    val id: String = "",
    val name: String = "",
    val logo: String? = null,
    val phone: String? = null,
    val email: String? = null,
    val website: String? = null,
    @SerializedName("avg_rating") val avgRating: Double? = null,
    @SerializedName("ratings_count") val ratingsCount: Int? = null,
    val requirements: List<CarrierRequirement>? = null
)

data class DetectRequest(@SerializedName("tracking_numbers") val trackingNumbers: List<String>)
data class DetectResponse(val carriers: List<String> = emptyList())

data class ImportRequest(
    @SerializedName("carrier_id") val carrierId: String,
    @SerializedName("tracking_number") val trackingNumber: List<String>,
    @SerializedName("notify_state") val notifyState: String = "active",
    @SerializedName("extra_fields") val extraFields: Map<String, Map<String, String>> = emptyMap()
)

data class PackageHistory(
    val id: String? = null,
    val status: String? = null,
    @SerializedName("checkpoint_status") val checkpointStatus: String? = null,
    @SerializedName("delivery_stage") val deliveryStage: String? = null,
    val time: Long? = null,
    @SerializedName("created_at") val createdAt: String? = null
)

data class CarrierLite(
    val id: String = "",
    val name: String = ""
)

data class PackageSummary(
    val id: String = "",
    @SerializedName("tracking_number") val trackingNumber: String = "",
    @SerializedName("carrier_id") val carrierId: String? = null,
    val carrier: CarrierLite? = null,
    @SerializedName("latest_package_history") val latestPackageHistory: PackageHistory? = null
)

data class UserPackage(
    val id: String = "",
    val note: String? = null,
    @SerializedName("notify_state") val notifyState: String? = null,
    @SerializedName("pickup_reminder_flags") val pickupReminderFlags: Int = 0,
    val state: String = "inbox",
    val extra: JsonElement? = null,
    @SerializedName("user_id") val userId: String? = null,
    @SerializedName("package_id") val packageId: String? = null,
    @SerializedName("created_at") val createdAt: String? = null,
    @SerializedName("updated_at") val updatedAt: String? = null,
    val packageData: PackageSummary? = null
) {
    // Gson maps the JSON key "package" via a setter-compatible backing property below.
    @SerializedName("package")
    private var _package: PackageSummary? = null
    val pkg: PackageSummary? get() = packageData ?: _package
}



data class PackageSettingRequest(
    val id: String,
    val note: String,
    @SerializedName("notify_state") val notifyState: String,
    @SerializedName("pickup_reminder_flags") val pickupReminderFlags: Int,
    val state: String,
    val extra: JsonElement = JsonNull.INSTANCE
)

data class PackagePage(
    @SerializedName("current_page") val currentPage: Int = 1,
    val data: List<UserPackage> = emptyList(),
    val counts: Map<String, Int>? = null,
    @SerializedName("last_page") val lastPage: Int? = null,
    val total: Int? = null
)

data class TrackingPackage(
    val id: String = "",
    @SerializedName("tracking_number") val trackingNumber: String = "",
    @SerializedName("carrier_id") val carrierId: String? = null,
    val metadata: JsonElement? = null,
    @SerializedName("created_at") val createdAt: String? = null,
    @SerializedName("updated_at") val updatedAt: String? = null,
    val carrier: Carrier? = null,
    @SerializedName("package_history") val packageHistory: List<PackageHistory> = emptyList(),
    @SerializedName("short_url") val shortUrl: ShortUrl? = null
)

data class ShortUrl(
    @SerializedName("package_id") val packageId: String? = null,
    val identifier: String? = null
)



fun isSameStatusTransitionText(raw: String?): Boolean {
    val text = raw.orEmpty().replace(Regex("【[^】]*】"), "").trim()
    if (text.isBlank()) return false
    val parts = text.split(Regex("\\s*→\\s*"), limit = 2)
    return parts.size == 2 && parts[0].trim().isNotBlank() && parts[0].trim() == parts[1].trim()
}

fun cleanLogisticsText(raw: String?): String {
    var text = raw.orEmpty()
        .replace(Regex("【[^】]*】"), "")
        .replace(Regex("\\[[^]]*]"), "")
        .replace(Regex("［[^］]*］"), "")
        .trim()
    text = text.replace(Regex("\\s+"), " ").trim()
    val same = Regex("^(.+?)\\s*→\\s*\\1$").matchEntire(text)
    if (same != null) text = same.groupValues[1].trim()
    return text
}

object DeliveryStages {
    const val IN_TRANSIT = "in_transit"
    const val DELIVERED = "delivered"
    const val ARRIVED = "arrived"
    const val PICKED_UP = "picked_up"
    const val EXCEPTION = "exception"
    const val RETURN_REQUESTED = "return_requested"
    const val OUT_FOR_DELIVERY = "out_for_delivery"
    const val CUSTOMS = "customs"
    const val RETURNED = "returned"
    const val CANCEL = "cancel"
    const val PENDING = "pending"
    const val SCHEDULED = "scheduled"
    const val LOST = "lost"

    fun label(stage: String?): String = when (stage) {
        IN_TRANSIT -> "運輸中"
        DELIVERED -> "已送達"
        ARRIVED -> "待取件"
        PICKED_UP -> "已攬收"
        EXCEPTION -> "異常"
        RETURN_REQUESTED -> "待退回"
        OUT_FOR_DELIVERY -> "配送中"
        CUSTOMS -> "清關中"
        RETURNED -> "已退回"
        CANCEL -> "已取消"
        PENDING -> "待攬收"
        SCHEDULED -> "已排程"
        LOST -> "遺失"
        else -> "更新中"
    }

    fun isFinished(stage: String?): Boolean = stage in setOf(DELIVERED, PICKED_UP, RETURNED, CANCEL)
    fun isAttention(stage: String?): Boolean = stage in setOf(ARRIVED, OUT_FOR_DELIVERY, EXCEPTION, RETURN_REQUESTED, LOST)
}

data class PackageImportDraft(
    val trackingNumber: String,
    val carrier: Carrier,
    val title: String = "",
    val amount: Long? = null,
    val category: String = "",
    val requirementValues: Map<String, String> = emptyMap()
)
