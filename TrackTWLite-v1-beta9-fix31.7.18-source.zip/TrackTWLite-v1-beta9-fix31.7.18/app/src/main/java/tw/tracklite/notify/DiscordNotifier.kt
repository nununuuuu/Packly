package tw.tracklite.notify

import com.google.gson.Gson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import tw.tracklite.data.db.PackageEntity
import tw.tracklite.data.model.DeliveryStages
import tw.tracklite.data.model.cleanLogisticsText

object DiscordNotifier {
    private val client = OkHttpClient()
    private val gson = Gson()
    private val jsonType = "application/json; charset=utf-8".toMediaType()

    private const val BLUE = 0x3498DB
    private const val GREEN = 0x2ECC71
    private const val RED = 0xE74C3C

    suspend fun sendPackageUpdate(webhookUrl: String, old: PackageEntity, item: PackageEntity) {
        val oldStage = DeliveryStages.label(old.deliveryStage)
        val newStage = DeliveryStages.label(item.deliveryStage)
        val color = when (item.deliveryStage) {
            DeliveryStages.ARRIVED -> GREEN
            DeliveryStages.EXCEPTION, DeliveryStages.LOST -> RED
            else -> BLUE
        }
        val fields = mutableListOf<Map<String, Any>>()
        if (item.pickupStore.isNotBlank()) fields += field("取件門市", storeName(item.pickupStore), true)
        if (item.pickupDeadline.isNotBlank()) fields += field("取件期限", shortDeadline(item.pickupDeadline), true)
        fields += field("追蹤號碼", item.trackingNumber, false)

        val description = buildString {
            append("**${item.displayTitle()}**\n")
            append(item.carrierName.ifBlank { "物流商" })
            append("\n\n**$oldStage → $newStage**")
            val detail = cleanLogisticsText(item.latestStatus)
            if (detail.isNotBlank() && detail != newStage && detail != "$oldStage → $newStage") {
                append("\n")
                append(detail)
            }
        }
        val embed = linkedMapOf<String, Any>(
            "title" to "Packly · 包裹更新",
            "description" to description,
            "color" to color,
            "fields" to fields,
            "footer" to mapOf("text" to "Packly")
        )
        send(webhookUrl, mapOf("embeds" to listOf(embed)))
    }

    suspend fun sendTest(webhookUrl: String) {
        val embed = linkedMapOf<String, Any>(
            "title" to "Packly · 測試通知",
            "description" to "Discord Webhook 運作正常",
            "color" to BLUE,
            "footer" to mapOf("text" to "Packly")
        )
        send(webhookUrl, mapOf("embeds" to listOf(embed)))
    }

    private fun field(name: String, value: String, inline: Boolean) = mapOf<String, Any>(
        "name" to name,
        "value" to value,
        "inline" to inline
    )

    private fun shortDeadline(raw: String): String {
        val value = raw.trim()
        val match = Regex("""(\\d{4})-(\\d{2})-(\\d{2})""").find(value) ?: return value
        return "${match.groupValues[2]}/${match.groupValues[3]}"
    }

    private fun storeName(raw: String): String = raw.substringBefore(" (").substringBefore("(").substringBefore("（").trim()

    private suspend fun send(webhookUrl: String, payload: Map<String, Any>) = withContext(Dispatchers.IO) {
        require(webhookUrl.startsWith("https://discord.com/api/webhooks/") || webhookUrl.startsWith("https://discordapp.com/api/webhooks/")) {
            "Discord Webhook URL 格式不正確"
        }
        val req = Request.Builder()
            .url(webhookUrl)
            .post(gson.toJson(payload).toRequestBody(jsonType))
            .build()
        client.newCall(req).execute().use { response ->
            if (!response.isSuccessful) error("Discord Webhook 失敗：HTTP ${response.code}")
        }
    }
}
