package tw.tracklite

import android.app.Application
import tw.tracklite.data.AppContainer
import tw.tracklite.notify.Notifications
import tw.tracklite.worker.SyncScheduler
import androidx.work.WorkManager
import tw.tracklite.widget.PackageWidgetReceiver

class TrackLiteApp : Application() {
    lateinit var container: AppContainer

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        // fix31.3 manual widget refreshes execute immediately; discard any persisted legacy
        // one-shot refresh that WorkManager may still be holding from fix31.2.
        WorkManager.getInstance(this).cancelUniqueWork("packly-widget-manual-refresh")
        // Rebind existing package widgets once after process start so upgrades from the old
        // Glance implementation immediately receive the native RemoteViews layout.
        runCatching { PackageWidgetReceiver.rebindAll(this) }
        Notifications.createChannel(this)
        SyncScheduler.ensureScheduled(this, container.settings.syncIntervalMinutesBlocking())
    }
}
