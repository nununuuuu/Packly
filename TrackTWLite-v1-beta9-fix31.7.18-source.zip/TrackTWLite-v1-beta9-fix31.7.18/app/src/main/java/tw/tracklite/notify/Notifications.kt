package tw.tracklite.notify

import android.Manifest
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import tw.tracklite.MainActivity
import tw.tracklite.R
import tw.tracklite.data.db.PackageEntity
import tw.tracklite.data.model.DeliveryStages
import tw.tracklite.data.model.cleanLogisticsText

object Notifications {
    private const val CHANNEL = "tracking_updates"
    private const val DEADLINE_CHANNEL = "pickup_deadlines"

    fun createChannel(context: Context) {
        val nm = context.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "物流更新", NotificationManager.IMPORTANCE_DEFAULT).apply { description = "包裹貨態發生變化時通知" })
        nm.createNotificationChannel(NotificationChannel(DEADLINE_CHANNEL, "取件期限提醒", NotificationManager.IMPORTANCE_HIGH).apply { description = "包裹即將超過取件期限時提醒" })
    }

    private fun allowed(context: Context) = android.os.Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    private fun pending(context: Context, item: PackageEntity) = PendingIntent.getActivity(context, item.id.hashCode(), Intent(context, MainActivity::class.java).apply { flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP }, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    private fun shortDeadline(raw: String) = runCatching { raw.substring(5).replace('-', '/') }.getOrDefault(raw)
    private fun storeName(raw: String) = raw.substringBefore(" (").substringBefore("(").trim()

    fun changed(context: Context, item: PackageEntity): Boolean {
        val manager = NotificationManagerCompat.from(context)
        if (!allowed(context) || !manager.areNotificationsEnabled() ||
            context.getSystemService(NotificationManager::class.java)
                .getNotificationChannel(CHANNEL)?.importance == NotificationManager.IMPORTANCE_NONE
        ) return false
        val stage = DeliveryStages.label(item.deliveryStage)
        val title: String
        val text: String
        if (item.deliveryStage == DeliveryStages.ARRIVED && item.pickupStore.isNotBlank()) {
            title = "${item.displayTitle()}已抵達門市 · ${storeName(item.pickupStore)}"
            text = if (item.pickupDeadline.isNotBlank()) "請於 ${shortDeadline(item.pickupDeadline)} 前完成取件" else cleanLogisticsText(item.latestStatus).ifBlank { stage }
        } else {
            title = "${item.displayTitle()} · $stage"
            text = cleanLogisticsText(item.latestStatus).ifBlank { stage }
        }
        val priority = if (DeliveryStages.isAttention(item.deliveryStage)) NotificationCompat.PRIORITY_HIGH else NotificationCompat.PRIORITY_DEFAULT
        val notification = NotificationCompat.Builder(context, CHANNEL).setSmallIcon(R.drawable.ic_notification_packly).setContentTitle(title).setContentText(text).setStyle(NotificationCompat.BigTextStyle().bigText(text)).setPriority(priority).setContentIntent(pending(context,item)).setAutoCancel(true).build()
        manager.notify(item.id.hashCode(), notification)
        return true
    }

    fun test(context: Context) {
        if (!allowed(context)) return
        val notification = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(R.drawable.ic_notification_packly)
            .setContentTitle("Packly 測試通知")
            .setContentText("App 推送通知運作正常")
            .setStyle(NotificationCompat.BigTextStyle().bigText("App 推送通知運作正常"))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()
        NotificationManagerCompat.from(context).notify("packly-test".hashCode(), notification)
    }

    fun pickupDeadline(context: Context, item: PackageEntity, finalDay: Boolean): Boolean {
        val manager = NotificationManagerCompat.from(context)
        if (!allowed(context) || !manager.areNotificationsEnabled() ||
            context.getSystemService(NotificationManager::class.java)
                .getNotificationChannel(DEADLINE_CHANNEL)?.importance == NotificationManager.IMPORTANCE_NONE
        ) return false
        val store = storeName(item.pickupStore)
        val title = if (finalDay) "${item.displayTitle()}今天是最後取件日" else "${item.displayTitle()}明天到期"
        val text = if (finalDay) "$store 門市 · 請於今天完成取件" else "$store 門市 · ${shortDeadline(item.pickupDeadline)} 前取件"
        val notification = NotificationCompat.Builder(context, DEADLINE_CHANNEL).setSmallIcon(R.drawable.ic_notification_packly).setContentTitle(title).setContentText(text).setStyle(NotificationCompat.BigTextStyle().bigText(text)).setPriority(NotificationCompat.PRIORITY_HIGH).setContentIntent(pending(context,item)).setAutoCancel(true).build()
        manager.notify((item.id + if(finalDay) "final" else "tomorrow").hashCode(), notification)
        return true
    }
}
