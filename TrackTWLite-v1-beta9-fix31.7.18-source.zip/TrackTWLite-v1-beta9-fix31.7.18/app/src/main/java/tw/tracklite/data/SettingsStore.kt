package tw.tracklite.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking

private val Context.ds by preferencesDataStore("settings")

class SettingsStore(private val context: Context) {
    private val TOKEN = stringPreferencesKey("api_token")
    private val AUTH_HEADER = stringPreferencesKey("auth_header")
    private val AUTH_PREFIX = stringPreferencesKey("auth_prefix")
    private val CLIPBOARD_DETECT = booleanPreferencesKey("clipboard_detect")
    private val DEVICE_NOTIFICATIONS = booleanPreferencesKey("device_notifications")
    private val DISCORD_ENABLED = booleanPreferencesKey("discord_enabled")
    private val DISCORD_WEBHOOK = stringPreferencesKey("discord_webhook")
    private val THEME_COLOR = intPreferencesKey("theme_color")
    private val SYNC_INTERVAL_MINUTES = intPreferencesKey("sync_interval_minutes")
    private val AUTO_ARCHIVE_DELIVERED = booleanPreferencesKey("auto_archive_delivered")
    private val NOTIFICATION_STAGES = stringSetPreferencesKey("notification_stages")
    private val PICKUP_TOMORROW = booleanPreferencesKey("pickup_tomorrow")
    private val PICKUP_FINAL_DAY = booleanPreferencesKey("pickup_final_day")
    private val PICKUP_REMINDER_KEYS = stringSetPreferencesKey("pickup_reminder_keys")
    private val AUTO_CHECK_UPDATES = booleanPreferencesKey("auto_check_updates")
    private val HOME_ATTENTION_TYPES = stringSetPreferencesKey("home_attention_types")
    private val STATUS_NOTIFICATION_KEYS = stringSetPreferencesKey("status_notification_keys")
    private val PENDING_DEVICE_EVENTS = stringSetPreferencesKey("pending_device_events")

    suspend fun saveToken(v: String) { context.ds.edit { it[TOKEN] = v.trim() } }
    suspend fun token() = context.ds.data.first()[TOKEN].orEmpty()
    fun tokenBlocking() = runBlocking { token() }
    fun authHeaderBlocking() = runBlocking { context.ds.data.first()[AUTH_HEADER] ?: "Authorization" }
    fun authPrefixBlocking() = runBlocking { context.ds.data.first()[AUTH_PREFIX] ?: "Bearer " }

    suspend fun clipboardDetect(): Boolean = context.ds.data.first()[CLIPBOARD_DETECT] ?: true
    suspend fun setClipboardDetect(v: Boolean) { context.ds.edit { it[CLIPBOARD_DETECT] = v } }

    suspend fun deviceNotifications(): Boolean = context.ds.data.first()[DEVICE_NOTIFICATIONS] ?: true
    suspend fun setDeviceNotifications(v: Boolean) {
        context.ds.edit {
            it[DEVICE_NOTIFICATIONS] = v
            // An explicit opt-out must not generate stale alerts when re-enabled later.
            if (!v) it.remove(PENDING_DEVICE_EVENTS)
        }
    }

    suspend fun discordEnabled(): Boolean = context.ds.data.first()[DISCORD_ENABLED] ?: false
    suspend fun setDiscordEnabled(v: Boolean) { context.ds.edit { it[DISCORD_ENABLED] = v } }

    suspend fun discordWebhook(): String = context.ds.data.first()[DISCORD_WEBHOOK].orEmpty()
    suspend fun setDiscordWebhook(v: String) { context.ds.edit { it[DISCORD_WEBHOOK] = v.trim() } }

    suspend fun themeColor(): Int = context.ds.data.first()[THEME_COLOR] ?: 0xFF6750A4.toInt()
    suspend fun setThemeColor(v: Int) { context.ds.edit { it[THEME_COLOR] = v } }

    suspend fun autoArchiveDelivered(): Boolean = context.ds.data.first()[AUTO_ARCHIVE_DELIVERED] ?: true
    suspend fun setAutoArchiveDelivered(v: Boolean) { context.ds.edit { it[AUTO_ARCHIVE_DELIVERED] = v } }

    suspend fun notificationStages(): Set<String> = context.ds.data.first()[NOTIFICATION_STAGES] ?: setOf(
        "in_transit", "out_for_delivery", "arrived", "delivered", "exception", "picked_up", "customs", "pending", "scheduled", "return_requested", "returned", "cancel", "lost"
    )
    suspend fun setNotificationStages(v: Set<String>) { context.ds.edit { it[NOTIFICATION_STAGES] = v } }
    suspend fun pickupTomorrow(): Boolean = context.ds.data.first()[PICKUP_TOMORROW] ?: true
    suspend fun setPickupTomorrow(v: Boolean) { context.ds.edit { it[PICKUP_TOMORROW] = v } }
    suspend fun pickupFinalDay(): Boolean = context.ds.data.first()[PICKUP_FINAL_DAY] ?: true
    suspend fun setPickupFinalDay(v: Boolean) { context.ds.edit { it[PICKUP_FINAL_DAY] = v } }
    suspend fun pickupReminderKeys(): Set<String> = context.ds.data.first()[PICKUP_REMINDER_KEYS] ?: emptySet()
    suspend fun markPickupReminder(key: String) { context.ds.edit { prefs -> prefs[PICKUP_REMINDER_KEYS] = (prefs[PICKUP_REMINDER_KEYS] ?: emptySet()) + key } }

    suspend fun homeAttentionTypes(): Set<String> = context.ds.data.first()[HOME_ATTENTION_TYPES] ?: setOf("final_day", "tomorrow", "exception", "lost")
    suspend fun setHomeAttentionTypes(v: Set<String>) { context.ds.edit { it[HOME_ATTENTION_TYPES] = v } }

    suspend fun statusNotificationKeys(): Set<String> = context.ds.data.first()[STATUS_NOTIFICATION_KEYS] ?: emptySet()
    suspend fun markStatusNotification(key: String) {
        context.ds.edit { prefs ->
            val values = ((prefs[STATUS_NOTIFICATION_KEYS] ?: emptySet()) + key).toList()
            val next = if (values.size > 300) values.drop(values.size - 300).toSet() else values.toSet()
            prefs[STATUS_NOTIFICATION_KEYS] = next
        }
    }

    suspend fun pendingDeviceEvents(): Set<String> = context.ds.data.first()[PENDING_DEVICE_EVENTS] ?: emptySet()
    suspend fun queueDeviceEvent(key: String) {
        context.ds.edit { prefs ->
            val values = (prefs[PENDING_DEVICE_EVENTS] ?: emptySet()) + key
            prefs[PENDING_DEVICE_EVENTS] = values.takeLast(300).toSet()
        }
    }
    suspend fun removeDeviceEvent(key: String) {
        context.ds.edit { prefs ->
            prefs[PENDING_DEVICE_EVENTS] = (prefs[PENDING_DEVICE_EVENTS] ?: emptySet()) - key
        }
    }

    suspend fun autoCheckUpdates(): Boolean = context.ds.data.first()[AUTO_CHECK_UPDATES] ?: true
    suspend fun setAutoCheckUpdates(v: Boolean) { context.ds.edit { it[AUTO_CHECK_UPDATES] = v } }

    suspend fun syncIntervalMinutes(): Int = context.ds.data.first()[SYNC_INTERVAL_MINUTES] ?: 30
    fun syncIntervalMinutesBlocking(): Int = runBlocking { syncIntervalMinutes() }
    suspend fun setSyncIntervalMinutes(v: Int) {
        val normalized = v.coerceAtLeast(15)
        context.ds.edit { it[SYNC_INTERVAL_MINUTES] = normalized }
    }
}
