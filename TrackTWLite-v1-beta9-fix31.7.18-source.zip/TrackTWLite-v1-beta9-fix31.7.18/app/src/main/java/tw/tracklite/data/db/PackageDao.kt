package tw.tracklite.data.db

import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Dao
interface PackageDao {
    @Query("SELECT * FROM packages WHERE archived = 0 AND folder = 'inbox' ORDER BY updatedAt DESC")
    fun observeInbox(): Flow<List<PackageEntity>>

    @Query("SELECT * FROM packages WHERE folder = 'archive' ORDER BY updatedAt DESC")
    fun observeArchive(): Flow<List<PackageEntity>>

    @Query("SELECT * FROM packages WHERE archived = 0 AND folder = 'inbox' ORDER BY updatedAt DESC")
    suspend fun inbox(): List<PackageEntity>

    @Query("SELECT * FROM packages WHERE folder = :folder ORDER BY updatedAt DESC")
    suspend fun folder(folder: String): List<PackageEntity>

    @Query("SELECT * FROM packages WHERE id = :id")
    suspend fun byId(id: String): PackageEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: PackageEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(items: List<PackageEntity>)

    @Query("UPDATE packages SET archived = 1, folder = 'archive' WHERE id = :id")
    suspend fun markArchived(id: String)

    @Query("UPDATE packages SET customTitle = :title WHERE id = :id")
    suspend fun setCustomTitle(id: String, title: String)

    @Query("UPDATE packages SET title = :note WHERE id = :id")
    suspend fun setOfficialNoteCache(id: String, note: String)

    @Query("UPDATE packages SET amount = :amount WHERE id = :id")
    suspend fun setAmount(id: String, amount: Long?)

    @Query("UPDATE packages SET extraFieldsJson = :json WHERE id = :id")
    suspend fun setExtraFieldsJson(id: String, json: String)

    @Query("UPDATE packages SET category = :category, categoryManagedByPackly = 0, categorySyncPending = 0 WHERE id = :id")
    suspend fun setCategory(id: String, category: String)

    @Query("UPDATE packages SET category = :newName, categoryManagedByPackly = 0, categorySyncPending = 0 WHERE category = :oldName")
    suspend fun renameCategory(oldName: String, newName: String)

    @Query("UPDATE packages SET category = '', categoryManagedByPackly = 0, categorySyncPending = 0 WHERE category = :name")
    suspend fun clearCategory(name: String)


    @Query("UPDATE packages SET categorySyncPending = :pending WHERE id = :id")
    suspend fun setCategorySyncPending(id: String, pending: Boolean)

    @Query("DELETE FROM packages WHERE id = :id")
    suspend fun delete(id: String)
}

@Dao
interface CategoryDao {
    @Query("SELECT * FROM categories ORDER BY sortOrder ASC, name COLLATE NOCASE ASC")
    fun observeAll(): Flow<List<CategoryEntity>>

    @Query("SELECT * FROM categories ORDER BY sortOrder ASC, name COLLATE NOCASE ASC")
    suspend fun all(): List<CategoryEntity>

    @Query("SELECT COUNT(*) FROM categories")
    suspend fun count(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: CategoryEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(items: List<CategoryEntity>)

    @Delete
    suspend fun delete(item: CategoryEntity)
}

@Database(entities = [PackageEntity::class, CategoryEntity::class], version = 10, exportSchema = false)
abstract class TrackDb : RoomDatabase() {
    abstract fun packages(): PackageDao
    abstract fun categories(): CategoryDao
}


val MIGRATION_6_7 = object : Migration(6, 7) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE packages ADD COLUMN extraFieldsJson TEXT NOT NULL DEFAULT ''")
    }
}


val MIGRATION_7_8 = object : Migration(7, 8) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE packages ADD COLUMN pickupReminderFlags INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE packages ADD COLUMN userExtraJson TEXT NOT NULL DEFAULT ''")
    }
}


val MIGRATION_8_9 = object : Migration(8, 9) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE packages ADD COLUMN categoryManagedByPackly INTEGER NOT NULL DEFAULT 0")
    }
}


val MIGRATION_9_10 = object : Migration(9, 10) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE packages ADD COLUMN categorySyncPending INTEGER NOT NULL DEFAULT 0")
    }
}
