package tw.tracklite.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.view.View
import android.widget.RemoteViews
import android.widget.RemoteViewsService
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import tw.tracklite.EXTRA_SCREEN
import tw.tracklite.MainActivity
import tw.tracklite.QuickAddActivity
import tw.tracklite.R
import tw.tracklite.TrackLiteApp
import tw.tracklite.data.db.PackageEntity
import tw.tracklite.data.model.DeliveryStages
import java.io.File

/**
 * Native RemoteViews implementation of the package-list widget.
 *
 * Important design rule: tapping refresh performs only a *partial* RemoteViews update
 * (refresh glyph -> native indeterminate progress circle). The package list is not rebuilt
 * until the sync has committed to Room. This avoids the full Glance recomposition/redraw
 * that previously made the widget appear stuck.
 */
class PackageWidgetReceiver : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { updateWidget(context, manager, it) }
        manager.notifyAppWidgetViewDataChanged(appWidgetIds, R.id.widget_list)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action != ACTION_REFRESH) return

        val widgetId = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
        if (widgetId != AppWidgetManager.INVALID_APPWIDGET_ID) {
            // Partial update only: do not rebuild header/list just to show refresh feedback.
            showRefreshing(context, widgetId)
        }

        runCatching {
            ContextCompat.startForegroundService(context, ManualWidgetSyncService.intent(context))
        }.onFailure {
            // No toast/error label by design. Restore the glyph and keep the previous data/time.
            if (widgetId != AppWidgetManager.INVALID_APPWIDGET_ID) {
                showIdle(context, widgetId)
            }
        }
    }

    companion object {
        const val ACTION_REFRESH = "tw.tracklite.widget.action.REFRESH"

        fun updateAll(context: Context) {
            val appContext = context.applicationContext
            val manager = AppWidgetManager.getInstance(appContext)
            val component = android.content.ComponentName(appContext, PackageWidgetReceiver::class.java)
            val ids = manager.getAppWidgetIds(component)
            if (ids.isEmpty()) return

            // Normal data refresh: only patch the tiny header/refresh area, then invalidate the
            // collection once. Do not replace the whole widget RemoteViews tree.
            val status = WidgetSyncStatus.header(appContext).orEmpty()
            ids.forEach { id ->
                val patch = RemoteViews(appContext.packageName, R.layout.widget_package).apply {
                    setTextViewText(R.id.widget_updated_at, status)
                    setViewVisibility(R.id.widget_updated_at, if (status.isBlank()) View.GONE else View.VISIBLE)
                    setViewVisibility(R.id.widget_refresh_progress, View.GONE)
                    setViewVisibility(R.id.widget_refresh, View.VISIBLE)
                }
                manager.partiallyUpdateAppWidget(id, patch)
            }
            manager.notifyAppWidgetViewDataChanged(ids, R.id.widget_list)
        }

        /** Full layout bind used for first placement and one-time migration from the old Glance widget. */
        fun rebindAll(context: Context) {
            val appContext = context.applicationContext
            val manager = AppWidgetManager.getInstance(appContext)
            val component = android.content.ComponentName(appContext, PackageWidgetReceiver::class.java)
            val ids = manager.getAppWidgetIds(component)
            ids.forEach { updateWidget(appContext, manager, it) }
            if (ids.isNotEmpty()) manager.notifyAppWidgetViewDataChanged(ids, R.id.widget_list)
        }

        private fun updateWidget(context: Context, manager: AppWidgetManager, widgetId: Int) {
            val views = RemoteViews(context.packageName, R.layout.widget_package)

            val status = WidgetSyncStatus.header(context).orEmpty()
            views.setTextViewText(R.id.widget_updated_at, status)
            views.setViewVisibility(R.id.widget_updated_at, if (status.isBlank()) View.GONE else View.VISIBLE)
            views.setViewVisibility(R.id.widget_refresh, View.VISIBLE)
            views.setViewVisibility(R.id.widget_refresh_progress, View.GONE)

            views.setOnClickPendingIntent(R.id.widget_add, quickAddPendingIntent(context, widgetId))
            views.setOnClickPendingIntent(R.id.widget_refresh, refreshPendingIntent(context, widgetId))
            views.setOnClickPendingIntent(R.id.widget_empty, quickAddPendingIntent(context, widgetId + 10_000))

            val serviceIntent = Intent(context, PackageWidgetRemoteViewsService::class.java).apply {
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId)
                // A unique data URI prevents launchers from reusing another widget's adapter intent.
                data = Uri.parse("packly://widget/packages/$widgetId")
            }
            views.setRemoteAdapter(R.id.widget_list, serviceIntent)
            views.setPendingIntentTemplate(R.id.widget_list, openAppPendingIntent(context, widgetId))
            views.setEmptyView(R.id.widget_list, R.id.widget_empty)

            manager.updateAppWidget(widgetId, views)
        }

        private fun showRefreshing(context: Context, widgetId: Int) {
            val views = RemoteViews(context.packageName, R.layout.widget_package).apply {
                setViewVisibility(R.id.widget_refresh, View.GONE)
                setViewVisibility(R.id.widget_refresh_progress, View.VISIBLE)
            }
            AppWidgetManager.getInstance(context).partiallyUpdateAppWidget(widgetId, views)
        }

        private fun showIdle(context: Context, widgetId: Int) {
            val views = RemoteViews(context.packageName, R.layout.widget_package).apply {
                setViewVisibility(R.id.widget_refresh_progress, View.GONE)
                setViewVisibility(R.id.widget_refresh, View.VISIBLE)
            }
            AppWidgetManager.getInstance(context).partiallyUpdateAppWidget(widgetId, views)
        }

        private fun refreshPendingIntent(context: Context, widgetId: Int): PendingIntent {
            val intent = Intent(context, PackageWidgetReceiver::class.java).apply {
                action = ACTION_REFRESH
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId)
            }
            return PendingIntent.getBroadcast(
                context,
                30_000 + widgetId,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        private fun quickAddPendingIntent(context: Context, requestCode: Int): PendingIntent {
            val intent = Intent(context, QuickAddActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            return PendingIntent.getActivity(
                context,
                requestCode,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        private fun openAppPendingIntent(context: Context, widgetId: Int): PendingIntent {
            val intent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra(EXTRA_SCREEN, "home")
            }
            return PendingIntent.getActivity(
                context,
                40_000 + widgetId,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
            )
        }
    }
}

/** Supplies the list portion of the native widget from Room + local logo cache only. */
class PackageWidgetRemoteViewsService : RemoteViewsService() {
    override fun onGetViewFactory(intent: Intent): RemoteViewsFactory = PackageWidgetRemoteViewsFactory(applicationContext)
}

private class PackageWidgetRemoteViewsFactory(private val context: Context) : RemoteViewsService.RemoteViewsFactory {
    private var items: List<PackageEntity> = emptyList()

    override fun onCreate() = reload()
    override fun onDataSetChanged() = reload()
    override fun onDestroy() { items = emptyList() }
    override fun getCount(): Int = items.size
    override fun getLoadingView(): RemoteViews? = null
    override fun getViewTypeCount(): Int = 1
    override fun hasStableIds(): Boolean = true
    override fun getItemId(position: Int): Long = items.getOrNull(position)?.id?.hashCode()?.toLong() ?: position.toLong()

    override fun getViewAt(position: Int): RemoteViews? {
        val item = items.getOrNull(position) ?: return null
        return RemoteViews(context.packageName, R.layout.widget_package_row).apply {
            setTextViewText(R.id.widget_row_title, item.displayTitle())

            val store = shortStoreNameNative(item.pickupStore)
            val subtitle = if (store.isNotBlank()) {
                "${item.carrierName.ifBlank { "物流商" }} · $store"
            } else {
                item.carrierName.ifBlank { item.trackingNumber }
            }
            setTextViewText(R.id.widget_row_subtitle, subtitle)

            setTextViewText(R.id.widget_row_status, DeliveryStages.label(item.deliveryStage))
            val statusBackground: Int
            val statusColor: Int
            when (item.deliveryStage) {
                "arrived" -> {
                    statusBackground = R.drawable.widget_preview_arrived
                    statusColor = 0xFF236B2D.toInt()
                }
                "in_transit", "out_for_delivery" -> {
                    statusBackground = R.drawable.widget_preview_transit
                    statusColor = 0xFF9B4B00.toInt()
                }
                else -> {
                    statusBackground = R.drawable.widget_preview_neutral
                    statusColor = 0xFF555555.toInt()
                }
            }
            setInt(R.id.widget_row_status, "setBackgroundResource", statusBackground)
            setTextColor(R.id.widget_row_status, statusColor)

            val deadline = shortDeadlineNative(item.pickupDeadline)
            if (deadline == null) {
                setViewVisibility(R.id.widget_row_deadline, View.GONE)
            } else {
                setTextViewText(R.id.widget_row_deadline, deadline)
                setViewVisibility(R.id.widget_row_deadline, View.VISIBLE)
            }

            val logo = cachedLogoFile(context, item)
            val bitmap = if (logo?.exists() == true && logo.length() > 0L) BitmapFactory.decodeFile(logo.absolutePath) else null
            if (bitmap != null) {
                setImageViewBitmap(R.id.widget_row_logo, bitmap)
                setViewVisibility(R.id.widget_row_logo, View.VISIBLE)
                setViewVisibility(R.id.widget_row_fallback, View.GONE)
            } else {
                setViewVisibility(R.id.widget_row_logo, View.GONE)
                setViewVisibility(R.id.widget_row_fallback, View.VISIBLE)
            }

            // The template PendingIntent opens the app; this fill-in keeps each row independently clickable.
            setOnClickFillInIntent(R.id.widget_row_root, Intent().apply {
                putExtra(EXTRA_SCREEN, "home")
            })
        }
    }

    private fun reload() {
        items = runBlocking(Dispatchers.IO) {
            runCatching {
                (context.applicationContext as TrackLiteApp).container.db.packages().inbox()
            }.getOrDefault(emptyList())
        }
    }
}

private fun cachedLogoFile(context: Context, item: PackageEntity): File? {
    val dir = File(context.cacheDir, "widget_carrier_logos")
    if (!dir.exists()) return null
    return File(dir, "${item.carrierId.ifBlank { item.carrierName.hashCode().toString() }}.img")
}

private fun shortStoreNameNative(raw: String): String {
    val value = raw.trim()
    if (value.isBlank()) return ""
    val open = listOf(value.indexOf('('), value.indexOf('（')).filter { it >= 0 }.minOrNull() ?: -1
    return if (open > 0) value.substring(0, open).trim() else value
}

private fun shortDeadlineNative(raw: String): String? {
    val match = Regex("""(\\d{4})-(\\d{2})-(\\d{2})""").find(raw.trim()) ?: return null
    return "${match.groupValues[2]}/${match.groupValues[3]}"
}
