package tw.tracklite.data.api

import com.google.gson.GsonBuilder
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import tw.tracklite.data.SettingsStore

object ApiFactory {
    fun create(settings: SettingsStore): TrackApi {
        val client = OkHttpClient.Builder()
            .addInterceptor { chain ->
                val token = settings.tokenBlocking()
                val builder = chain.request().newBuilder().header("Accept", "application/json")
                if (token.isNotBlank()) builder.header(settings.authHeaderBlocking(), settings.authPrefixBlocking() + token)
                chain.proceed(builder.build())
            }
            .addInterceptor(HttpLoggingInterceptor().apply { level = HttpLoggingInterceptor.Level.BASIC })
            .build()
        return Retrofit.Builder()
            .baseUrl("https://track.tw/api/v1/")
            .client(client)
            .addConverterFactory(GsonConverterFactory.create(GsonBuilder().create()))
            .build().create(TrackApi::class.java)
    }
}
