package tw.tracklite.widget

import android.content.Context

/** Presentation metadata only. Package data itself always comes from Room. */
object WidgetSyncStatus {
    private const val PREFS = "packly_widget_state"
    private const val KEY_LAST_SUCCESS = "package_widget_last_sync_success_at"

    /** Only successful refreshes change the visible timestamp. Failures keep the previous time. */
    fun header(context: Context): String? {
        val at = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong(KEY_LAST_SUCCESS, 0L)
        if (at <= 0L) return null
        val formatter = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault())
        return "${formatter.format(java.util.Date(at))}更新"
    }

    fun recordSuccess(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putLong(KEY_LAST_SUCCESS, System.currentTimeMillis())
            .apply()
    }

    /** Intentionally silent: no failure label/toast and no change to last-success time. */
    fun recordFailure(context: Context) = Unit
}
