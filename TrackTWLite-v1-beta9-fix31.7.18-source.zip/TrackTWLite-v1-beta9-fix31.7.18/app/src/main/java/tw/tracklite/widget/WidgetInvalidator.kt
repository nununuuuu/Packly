package tw.tracklite.widget

import android.content.Context
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Single widget invalidation gateway.
 * Package-list widget is native RemoteViews; summary widget remains Glance.
 */
class WidgetInvalidator(context: Context) {
    private val appContext = context.applicationContext
    private val mutex = Mutex()

    suspend fun packagesChanged() = mutex.withLock {
        PackageWidgetReceiver.updateAll(appContext)
        PackageSummaryWidget.updateAll(appContext)
    }

    suspend fun packageListChanged() = packagesChanged()

    suspend fun packageWidgetOnly() = mutex.withLock {
        PackageWidgetReceiver.updateAll(appContext)
    }
}
