package tw.tracklite.worker

import android.content.Context
import androidx.work.*
import tw.tracklite.TrackLiteApp
import tw.tracklite.data.sync.SyncMode
import tw.tracklite.data.sync.SyncSource
import tw.tracklite.notify.Notifications
import tw.tracklite.widget.WidgetSyncStatus
import tw.tracklite.widget.refreshWidgetCarrierLogoCache
import java.util.concurrent.TimeUnit

class PackageSyncWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val app = applicationContext as TrackLiteApp
        if (app.container.settings.token().isBlank()) return Result.success()

        return try {
            val result = app.container.syncCoordinator.refresh(SyncSource.BACKGROUND, SyncMode.FULL) {
                if (app.container.settings.autoArchiveDelivered()) {
                    app.container.repository.autoArchiveDelivered()
                }
                WidgetSyncStatus.recordSuccess(applicationContext)
            }

            if (app.container.settings.deviceNotifications()) {
                val today = java.time.LocalDate.now()
                val sent = app.container.settings.pickupReminderKeys().toMutableSet()
                result.items.filter { it.deliveryStage == "arrived" && it.pickupDeadline.isNotBlank() }.forEach { item ->
                    val deadline = runCatching { java.time.LocalDate.parse(item.pickupDeadline.take(10)) }.getOrNull() ?: return@forEach
                    val days = java.time.temporal.ChronoUnit.DAYS.between(today, deadline)
                    val kind = when {
                        days == 0L && app.container.settings.pickupFinalDay() -> "final"
                        days == 1L && app.container.settings.pickupTomorrow() -> "tomorrow"
                        else -> null
                    }
                    if (kind != null) {
                        val key = "${item.id}|$kind|$deadline"
                        if (key !in sent) {
                            val posted = runCatching { Notifications.pickupDeadline(applicationContext, item, kind == "final") }.getOrDefault(false)
                            if (posted) {
                                app.container.settings.markPickupReminder(key)
                                sent += key
                            }
                        }
                    }
                }
            }

            // Logo downloads are best-effort cache warming only. They never trigger another widget redraw.
            kotlinx.coroutines.withTimeoutOrNull(5_000L) {
                runCatching { refreshWidgetCarrierLogoCache(applicationContext, result.items) }
            }
            Result.success()
        } catch (_: Throwable) {
            WidgetSyncStatus.recordFailure(applicationContext)
            runCatching { app.container.widgetInvalidator.packageWidgetOnly() }
            Result.retry()
        }
    }
}

object SyncScheduler {
    fun ensureScheduled(context: Context, intervalMinutes: Int = 30) {
        val normalized = intervalMinutes.coerceAtLeast(15)
        val req = PeriodicWorkRequestBuilder<PackageSyncWorker>(normalized.toLong(), TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            "package-sync",
            ExistingPeriodicWorkPolicy.UPDATE,
            req
        )
    }
}
