package tw.tracklite

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.OpenInFull
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import tw.tracklite.data.model.Carrier
import tw.tracklite.data.model.PackageImportDraft
import tw.tracklite.ui.ApiStatus
import tw.tracklite.ui.MainViewModel

/**
 * Compact add flow launched from the home-screen widget.
 * It intentionally lives in a translucent floating Activity so adding a package
 * does not navigate through Packly's full UI.
 */
class QuickAddActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val vm: MainViewModel = viewModel()
            val state by vm.state.collectAsStateWithLifecycle()
            MaterialTheme(colorScheme = lightColorScheme(primary = Color(state.themeColor))) {
                if (state.settingsLoaded) QuickAddDialog(
                    apiStatus = state.apiStatus,
                    carriers = state.carriers,
                    busy = state.loading,
                    error = state.error,
                    onConsumeError = vm::consumeError,
                    onDetect = vm::detectForImport,
                    onImport = { number, carrier, title ->
                        vm.importPackages(
                            listOf(PackageImportDraft(trackingNumber = number, carrier = carrier, title = title))
                        ) { finish() }
                    },
                    onClose = { finish() },
                    onOpenFullAdd = { text ->
                        startActivity(Intent(this, MainActivity::class.java).apply {
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                            putExtra(EXTRA_SCREEN, "import")
                            if (text.isNotBlank()) putExtra(EXTRA_IMPORT_TEXT, text)
                        })
                        finish()
                    }
                )
            }
        }
    }


}

const val EXTRA_IMPORT_TEXT = "tw.tracklite.extra.IMPORT_TEXT"

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun QuickAddDialog(
    apiStatus: ApiStatus,
    carriers: List<Carrier>,
    busy: Boolean,
    error: String?,
    onConsumeError: () -> Unit,
    onDetect: (String, (List<Carrier>) -> Unit) -> Unit,
    onImport: (String, Carrier, String) -> Unit,
    onClose: () -> Unit,
    onOpenFullAdd: (String) -> Unit
) {
    var raw by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }
    var selectedCarrier by remember { mutableStateOf<Carrier?>(null) }
    var candidates by remember { mutableStateOf<List<Carrier>>(emptyList()) }
    var detecting by remember { mutableStateOf(false) }
    var carrierMenu by remember { mutableStateOf(false) }
    var localError by remember { mutableStateOf<String?>(null) }
    var candidateDialog by remember { mutableStateOf(false) }
    val clipboard = LocalClipboardManager.current

    val numbers = remember(raw) {
        val direct = raw.trim()
        val isDirectTrackingInput = direct.length in 8..40 &&
            direct.any(Char::isDigit) &&
            direct.all { it.isLetterOrDigit() || it == '-' }
        if (isDirectTrackingInput) listOf(direct) else quickTrackingCandidates(raw)
    }
    val number = numbers.singleOrNull().orEmpty()

    var initialClipboardHandled by remember { mutableStateOf(false) }

    LaunchedEffect(apiStatus, carriers) {
        if (!initialClipboardHandled && apiStatus == ApiStatus.CONNECTED) {
            initialClipboardHandled = true
            val clip = clipboard.getText()?.text?.trim().orEmpty()
            if (clip.isNotBlank()) {
                val foundNumbers = quickTrackingCandidates(clip).ifEmpty {
                    val direct = clip.takeIf { value ->
                        value.length in 8..40 && value.any(Char::isDigit) && value.all { it.isLetterOrDigit() || it == '-' }
                    }
                    if (direct != null) listOf(direct) else emptyList()
                }
                val detectedNumber = foundNumbers.singleOrNull()
                if (detectedNumber != null) {
                    raw = detectedNumber
                    detecting = true
                    localError = null
                    onDetect(detectedNumber) { found ->
                        candidates = found
                        selectedCarrier = found.singleOrNull()
                        detecting = false
                        if (found.isEmpty()) localError = "無法有效辨識物流商，請手動選擇"
                    }
                }
            }
        }
    }

    LaunchedEffect(error) {
        if (!error.isNullOrBlank()) {
            localError = error
            onConsumeError()
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .padding(12.dp),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth().widthIn(max = 440.dp),
            shape = RoundedCornerShape(28.dp),
            tonalElevation = 6.dp,
            shadowElevation = 10.dp
        ) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("快速新增包裹", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                        Text("貼上單號，辨識物流商後直接加入", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton(onClick = onClose) { Icon(Icons.Default.Close, "關閉") }
                }

                OutlinedTextField(
                    value = raw,
                    onValueChange = {
                        raw = it
                        selectedCarrier = null
                        candidates = emptyList()
                        localError = null
                    },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("物流單號") },
                    placeholder = { Text("輸入或貼上追蹤號碼") },
                    singleLine = true,
                    trailingIcon = {
                        IconButton(onClick = {
                            clipboard.getText()?.text?.takeIf { it.isNotBlank() }?.let {
                                raw = it
                                selectedCarrier = null
                                candidates = emptyList()
                            }
                        }) { Icon(Icons.Default.ContentPaste, "貼上") }
                    }
                )

                when {
                    raw.isNotBlank() && numbers.isEmpty() -> Text("沒有找到可用的物流單號", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    numbers.size > 1 -> Text("偵測到 ${numbers.size} 筆單號，Quick Add 一次新增 1 筆，可改用完整新增", color = MaterialTheme.colorScheme.tertiary, style = MaterialTheme.typography.bodySmall)
                }

                if (numbers.size <= 1) {
                    OutlinedButton(
                        onClick = {
                            detecting = true
                            localError = null
                            onDetect(number) { found ->
                                candidates = found
                                selectedCarrier = found.singleOrNull()
                                detecting = false
                                if (found.isEmpty()) localError = "無法有效辨識物流商，請手動選擇"
                            }
                        },
                        enabled = number.isNotBlank() && !detecting && apiStatus == ApiStatus.CONNECTED,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (detecting) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                        Text(if (detecting) "辨識中…" else "自動辨識物流商", Modifier.padding(start = if (detecting) 8.dp else 0.dp))
                    }

                    if (selectedCarrier == null && candidates.size > 1) {
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Color(0xFFE3F2FD)).clickable { candidateDialog = true }.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Info, null, tint = Color(0xFF1565C0), modifier = Modifier.size(20.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("偵測到此單號同時符合多家物流商規則", modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodySmall, color = Color(0xFF1F2937))
                            Icon(Icons.Default.ChevronRight, null, tint = Color(0xFF1565C0))
                        }
                    }

                    ExposedDropdownMenuBox(expanded = carrierMenu, onExpandedChange = { carrierMenu = it }) {
                        OutlinedTextField(
                            value = selectedCarrier?.name.orEmpty(),
                            onValueChange = {},
                            readOnly = true,
                            modifier = Modifier.menuAnchor().fillMaxWidth(),
                            label = { Text("物流商") },
                            placeholder = { Text("請選擇物流商") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(carrierMenu) }
                        )
                        ExposedDropdownMenu(expanded = carrierMenu, onDismissRequest = { carrierMenu = false }) {
                            carriers.forEach { carrier ->
                                DropdownMenuItem(
                                    text = { Text(carrier.name) },
                                    onClick = { selectedCarrier = carrier; carrierMenu = false; localError = null }
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("備註（選填）") },
                        singleLine = true
                    )
                }

                if (apiStatus == ApiStatus.NOT_CONFIGURED) {
                    Text("尚未設定 Track.TW API Token，請先到 Packly 設定", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                } else if (apiStatus == ApiStatus.CHECKING) {
                    Text("正在連線 Track.TW…", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                }

                localError?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End)) {
                    TextButton(onClick = { onOpenFullAdd(raw) }) {
                        Icon(Icons.Default.OpenInFull, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("完整新增")
                    }
                    Button(
                        onClick = { selectedCarrier?.let { onImport(number, it, title.trim()) } },
                        enabled = number.isNotBlank() && selectedCarrier != null && !busy && apiStatus == ApiStatus.CONNECTED
                    ) {
                        if (busy) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                        Text(if (busy) "新增中…" else "新增", Modifier.padding(start = if (busy) 8.dp else 0.dp))
                    }
                }
            }
        }
    }

    if (candidateDialog && candidates.size > 1) {
        AlertDialog(
            onDismissRequest = { candidateDialog = false },
            title = { Text("符合規則的物流商") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    candidates.forEach { carrier ->
                        TextButton(
                            onClick = {
                                selectedCarrier = carrier
                                localError = null
                                candidateDialog = false
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(carrier.name, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Start, color = Color.Black) }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = {
                    candidateDialog = false
                    carrierMenu = true
                }) { Text("都不是，查看其他", color = Color.Black) }
            }
        )
    }

}

private fun quickTrackingCandidates(text: String): List<String> {
    if (text.isBlank() || text.length > 8000) return emptyList()
    val normalized = text.replace('，', ',').replace('；', ';').replace('／', '/').replace('：', ':')
    val tokenRegex = Regex("(?<![A-Za-z0-9])[A-Za-z0-9-]{8,40}(?![A-Za-z0-9])")
    val dateRegex = Regex("^(?:19|20)\\d{2}[-/]?(?:0?[1-9]|1[0-2])[-/]?(?:0?[1-9]|[12]\\d|3[01])$")
    val phoneRegex = Regex("^(?:\\+?886[- ]?)?0?9\\d{8}$")
    val explicitNonTracking = Regex("(?:訂單(?:編號|號碼|號)?|order\\s*(?:id|no|number)?|手機|電話|tel|phone|金額|價格|price|amount)\\s*[:#：]?\\s*$", RegexOption.IGNORE_CASE)
    return tokenRegex.findAll(normalized).mapNotNull { match ->
        val value = match.value.trim('-')
        if (value.length < 8 || !value.any(Char::isDigit)) return@mapNotNull null
        val compact = value.replace("-", "")
        if (phoneRegex.matches(compact) || dateRegex.matches(value)) return@mapNotNull null
        val prefixStart = (match.range.first - 28).coerceAtLeast(0)
        val prefix = normalized.substring(prefixStart, match.range.first).takeLast(28)
        if (explicitNonTracking.containsMatchIn(prefix)) return@mapNotNull null
        value
    }.distinctBy { it.uppercase() }.take(30).toList()
}
