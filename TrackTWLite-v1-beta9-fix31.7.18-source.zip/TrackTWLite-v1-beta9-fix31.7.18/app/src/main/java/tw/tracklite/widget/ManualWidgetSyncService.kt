package tw.tracklite.widget

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout
import java.util.concurrent.atomic.AtomicBoolean
import tw.tracklite.MainActivity
import tw.tracklite.R
import tw.tracklite.TrackLiteApp
import tw.tracklite.data.sync.SyncMode
import tw.tracklite.data.sync.SyncSource

/** Executes user-initiated widget refresh outside Glance ActionCallback lifecycle. */
class ManualWidgetSyncService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val running = AtomicBoolean(false)

    override fun onCreate() {
        super.onCreate()
        ensureChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, buildNotification())
        if (!running.compareAndSet(false, true)) return START_NOT_STICKY
        scope.launch {
            val app = application as TrackLiteApp
            try {
                withTimeout(20_000L) {
                    app.container.syncCoordinator.refresh(SyncSource.WIDGET_MANUAL, SyncMode.FAST) {
                        WidgetSyncStatus.recordSuccess(applicationContext)
                    }
                }
            } catch (_: Throwable) {
                WidgetSyncStatus.recordFailure(applicationContext)
                runCatching { app.container.widgetInvalidator.packageWidgetOnly() }
            } finally {
                running.set(false)
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun ensureChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "手動更新", NotificationManager.IMPORTANCE_LOW).apply {
                description = "從桌面小工具手動更新包裹時使用"
                setShowBadge(false)
            }
        )
    }

    private fun buildNotification(): Notification {
        val pending = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification_packly)
            .setContentTitle("Packly 正在更新")
            .setContentText("正在取得最新包裹狀態")
            .setContentIntent(pending)
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    companion object {
        private const val CHANNEL_ID = "widget_manual_sync"
        private const val NOTIFICATION_ID = 0x5041434B

        fun intent(context: Context) = Intent(context, ManualWidgetSyncService::class.java)
    }
}
