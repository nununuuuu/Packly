package tw.tracklite.data.sync

import android.content.Context
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import tw.tracklite.data.repo.SyncResult
import tw.tracklite.data.repo.PackageRepository
import tw.tracklite.data.repo.PackageChange
import tw.tracklite.data.model.TrackingPackage
import tw.tracklite.notify.ChangeNotifier
import tw.tracklite.widget.WidgetInvalidator

enum class SyncSource { APP_MANUAL, APP_RESUME, WIDGET_MANUAL, BACKGROUND }
enum class SyncMode { FAST, FULL }

/**
 * Single synchronization entry point for inbox refreshes.
 * Repository owns API/Room; this coordinator owns orchestration and the one post-commit widget invalidation.
 */
class PackageSyncCoordinator(
    private val repository: PackageRepository,
    private val widgetInvalidator: WidgetInvalidator,
    private val context: Context
) {
    private val mutex = Mutex()

    suspend fun refresh(
        source: SyncSource,
        mode: SyncMode,
        beforeInvalidate: suspend (SyncResult) -> Unit = {}
    ): SyncResult = mutex.withLock {
        val result = repository.syncInbox(enrichTracking = mode == SyncMode.FULL)
        // Room writes are complete here. Allow callers to update tiny presentation metadata
        // (e.g. last-sync timestamp) before the single widget redraw.
        beforeInvalidate(result)
        // All sync entry points share the same notification path, including FAST widget refresh.
        // Also retry any device alert queued by an earlier denied/disabled system permission.
        ChangeNotifier.dispatch(context, result.changes, result.items)
        widgetInvalidator.packagesChanged()
        result
    }

    suspend fun refreshDetail(id: String): TrackingPackage = mutex.withLock {
        val before = repository.packageById(id)
        val detail = repository.tracking(id)
        val after = repository.packageById(id)
        val changes = if (after != null && before != null && PackageRepository.isNewStage(before, after)) {
            listOf(PackageChange(before, after))
        } else emptyList()
        // Detail reads are state mutations too: the arrival alert must not be silently consumed.
        ChangeNotifier.dispatch(context, changes, repository.inboxSnapshot())
        widgetInvalidator.packagesChanged()
        detail
    }
}
