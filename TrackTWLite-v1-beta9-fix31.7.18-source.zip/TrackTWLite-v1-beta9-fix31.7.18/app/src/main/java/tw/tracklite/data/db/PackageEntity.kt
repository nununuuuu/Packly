package tw.tracklite.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "packages")
data class PackageEntity(
    @PrimaryKey val id: String,
    val trackingNumber: String,
    val carrierId: String,
    val carrierName: String,
    val title: String,
    val latestStatus: String,
    val checkpointStatus: String,
    val deliveryStage: String,
    val latestEventKey: String,
    val eventTime: Long,
    val updatedAt: String,
    val notifyState: String,
    val pickupReminderFlags: Int = 0,
    val userExtraJson: String = "",
    val folder: String,
    val archived: Boolean = false,
    val customTitle: String = "",
    val amount: Long? = null,
    val category: String = "",
    // True once the user explicitly changes this package category in Packly.
    // When true, local category (including an explicit blank) is authoritative and is mirrored to Track.TW.
    val categoryManagedByPackly: Boolean = false,
    // True while a Packly-owned category still needs server confirmation.
    val categorySyncPending: Boolean = false,
    val pickupStore: String = "",
    val pickupDeadline: String = "",
    val deliveredAt: Long = 0L,
    // JSON object containing the carrier-specific /package/import fields used for this tracking number.
    // Retained for future re-import/recovery flows; existing UserPackage settings are edited via /package/setting.
    val extraFieldsJson: String = ""
) {
    fun displayTitle(): String = title.ifBlank { trackingNumber }
}

@Entity(tableName = "categories")
data class CategoryEntity(
    @PrimaryKey val id: String,
    val name: String,
    val iconType: String = "material", // material | emoji
    val iconValue: String = "category",
    val sortOrder: Int = 0
)
