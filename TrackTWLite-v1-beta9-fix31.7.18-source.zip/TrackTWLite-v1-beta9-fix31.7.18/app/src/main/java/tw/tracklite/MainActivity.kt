package tw.tracklite

import android.Manifest
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.IntOffset
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import coil.compose.AsyncImage
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import kotlin.math.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import tw.tracklite.data.db.PackageEntity
import tw.tracklite.data.db.CategoryEntity
import tw.tracklite.data.model.*
import tw.tracklite.ui.ApiStatus
import tw.tracklite.ui.MainState
import tw.tracklite.ui.MainViewModel
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

const val EXTRA_SCREEN = "tw.tracklite.extra.SCREEN"
const val EXTRA_STATUS_FILTER = "tw.tracklite.extra.STATUS_FILTER"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val initialScreen = intent?.getStringExtra(EXTRA_SCREEN) ?: "home"
        val initialStatusFilter = intent?.getStringExtra(EXTRA_STATUS_FILTER) ?: "all"
        val initialImportText = intent?.getStringExtra(EXTRA_IMPORT_TEXT).orEmpty()
        setContent { TrackLiteAppUi(initialScreen = initialScreen, initialStatusFilter = initialStatusFilter, initialImportText = initialImportText) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TrackLiteAppUi(
    initialScreen: String = "home",
    initialStatusFilter: String = "all",
    initialImportText: String = "",
    vm: MainViewModel = viewModel()
) {
    val state by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    var showToken by remember { mutableStateOf(false) }
    var screen by remember(initialScreen) { mutableStateOf(initialScreen) }
    var searchReturnScreen by remember { mutableStateOf(if (initialScreen == "archive") "archive" else "home") }
    var importReturnScreen by remember { mutableStateOf("home") }
    var importInitial by remember(initialImportText) { mutableStateOf(findTrackingCandidates(initialImportText)) }
    var lastClipboard by remember { mutableStateOf("") }
    var pendingNotificationTest by remember { mutableStateOf(false) }

    val notificationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted && pendingNotificationTest) vm.testDeviceNotification()
        pendingNotificationTest = false
    }

    LaunchedEffect(state.deviceNotifications) {
        if (android.os.Build.VERSION.SDK_INT >= 33 && state.deviceNotifications) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    DisposableEffect(lifecycleOwner, state.clipboardDetect, state.settingsLoaded, state.items, state.archivedItems) {
        fun checkClipboard() {
            if (!state.settingsLoaded || !state.clipboardDetect) return
            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val text = cm.primaryClip?.getItemAt(0)?.coerceToText(context)?.toString().orEmpty()
            val candidates = findClipboardTrackingCandidates(text)
                .filterNot { n ->
                    state.items.any { it.trackingNumber.equals(n, ignoreCase = true) } ||
                        state.archivedItems.any { it.trackingNumber.equals(n, ignoreCase = true) }
                }
            val key = candidates.joinToString("|")
            if (candidates.isNotEmpty() && key != lastClipboard) {
                lastClipboard = key
                scope.launch {
                    val label = if (candidates.size == 1) candidates.first() else "${candidates.size} 筆疑似單號"
                    val result = snackbar.showSnackbar(
                        message = "偵測到剪貼簿存在疑似單號：$label",
                        actionLabel = "匯入",
                        withDismissAction = true,
                        duration = SnackbarDuration.Long
                    )
                    if (result == SnackbarResult.ActionPerformed) {
                        importInitial = candidates
                        importReturnScreen = screen.takeIf { it == "home" || it == "archive" } ?: "home"
                        screen = "import"
                    }
                }
            }
        }

        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                checkClipboard()
                vm.refreshOnResume()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)

        // The observer can be attached after ON_RESUME on a cold start, so also check immediately
        // once persisted settings have finished loading and the Activity is already in foreground
        if (lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) {
            checkClipboard()
            vm.refreshOnResume()
        }

        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    LaunchedEffect(state.message) {
        state.message?.let { snackbar.showSnackbar(it); vm.consumeMessage() }
    }
    LaunchedEffect(state.error) {
        state.error?.let { snackbar.showSnackbar(it, withDismissAction = true); vm.consumeError() }
    }

    // Packly uses state-driven screens rather than a NavHost, so explicitly map Android
    // system back to the previous Packly surface instead of letting MainActivity finish.
    BackHandler(enabled = showToken || state.selected != null || screen != "home") {
        when {
            showToken -> showToken = false
            state.selected != null -> vm.closeDetail()
            screen == "search" -> screen = searchReturnScreen
            screen == "import" -> {
                screen = importReturnScreen
                importInitial = emptyList()
            }
            screen == "settings" || screen == "archive" -> screen = "home"
            else -> screen = "home"
        }
    }

    MaterialTheme(colorScheme = themeScheme(Color(state.themeColor))) {
    Box(Modifier.fillMaxSize()) {
        when {
            !state.settingsLoaded -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            state.selected != null -> DetailScreen(
                item = state.selected!!,
                detail = state.detail,
                loading = state.detailLoading,
                onBack = vm::closeDetail,
                onRefresh = vm::refreshDetail,
                onSetTitle = vm::updateTitle,
                onSetAmount = vm::updateAmount,
                onSetCategory = vm::updateCategory,
                onToggleNotify = vm::togglePackageNotifications,
                onArchive = vm::archiveSelected,
                onDelete = vm::deleteSelected,
                categories = state.categories,
                carriers = state.carriers
            )
            screen == "settings" -> SettingsScreen(
                state = state,
                onNavigate = { screen = it },
                onToken = { showToken = true },
                onClearToken = vm::clearToken,
                onVerifyToken = { vm.verifyToken(false) },
                onClipboard = vm::setClipboardDetect,
                onDeviceNotifications = {
                    vm.setDeviceNotifications(it)
                    if (it && android.os.Build.VERSION.SDK_INT >= 33) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                },
                onTestDeviceNotification = {
                    val needsPermission = android.os.Build.VERSION.SDK_INT >= 33 &&
                        androidx.core.content.ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
                    if (needsPermission) {
                        pendingNotificationTest = true
                        notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                    } else vm.testDeviceNotification()
                },
                onNotificationStage = vm::setNotificationStage,
                onNotificationStages = vm::setNotificationStages,
                onHomeAttentionTypes = vm::setHomeAttentionTypes,
                onPickupTomorrow = vm::setPickupTomorrow,
                onPickupFinalDay = vm::setPickupFinalDay,
                onDiscordEnabled = vm::setDiscordEnabled,
                onSaveWebhook = vm::saveDiscordWebhook,
                onTestWebhook = vm::testDiscord,
                onThemeColor = vm::setThemeColor,
                onSyncInterval = vm::setSyncIntervalMinutes,
                onAutoArchive = vm::setAutoArchiveDelivered,
                onAutoCheckUpdates = vm::setAutoCheckUpdates,
                categories = state.categories,
                onAddCategory = vm::addCategory,
                onEditCategory = vm::updateCategoryDefinition,
                onDeleteCategory = vm::deleteCategoryDefinition
            )
            screen == "archive" -> ArchiveScreen(
                state = state,
                onNavigate = { screen = it },
                onRefresh = vm::refreshArchive,
                onSearch = { searchReturnScreen = "archive"; screen = "search" },
                onOpen = vm::openDetail,
                onRestore = { vm.restorePackages(setOf(it.id)) },
                onDelete = { vm.deletePackages(setOf(it.id)) },
                onRestoreBatch = vm::restorePackages,
                onDeleteBatch = vm::deletePackages
            )
            screen == "search" -> GlobalSearchScreen(
                state = state,
                onBack = { screen = searchReturnScreen },
                onOpen = vm::openDetail
            )
            screen == "recent_activity" -> RecentLogisticsActivityScreen(
                items = state.items,
                onBack = { screen = "home" },
                onOpen = vm::openDetail
            )
            screen == "import" -> ImportPackagesScreen(
                initialNumbers = importInitial,
                state = state,
                onBack = { screen = importReturnScreen; importInitial = emptyList() },
                onNeedToken = { showToken = true },
                onDetect = vm::detectForImport,
                onDetectBatch = vm::detectBatchForImport,
                onImport = { drafts -> vm.importPackages(drafts) { screen = "home"; importInitial = emptyList() } }
            )
            else -> HomeScreen(
                state = state,
                onRefresh = vm::refreshAll,
                onNavigate = { screen = it },
                onAdd = { importReturnScreen = "home"; importInitial = emptyList(); screen = "import" },
                onSearch = { searchReturnScreen = "home"; screen = "search" },
                onSetToken = { showToken = true },
                onOpen = vm::openDetail,
                onArchive = { vm.archivePackages(setOf(it.id)) },
                onArchiveBatch = vm::archivePackages,
                initialStatusFilter = initialStatusFilter
            )
        }
        SnackbarHost(snackbar, Modifier.align(Alignment.BottomCenter).padding(12.dp))
    }

    if (showToken) TokenDialog(
        onDismiss = { showToken = false },
        onSave = { vm.saveToken(it); showToken = false }
    )
    }
}

private fun findClipboardTrackingCandidates(text: String): List<String> {
    val direct = text.trim()
    val isDirectTrackingInput = direct.length in 8..40 &&
        direct.any(Char::isDigit) &&
        direct.all { it.isLetterOrDigit() || it == '-' }
    return if (isDirectTrackingInput) listOf(direct) else findTrackingCandidates(text)
}

private fun findTrackingCandidates(text: String): List<String> {
    if (text.isBlank() || text.length > 8000) return emptyList()
    val normalized = text.replace('，', ',').replace('；', ';').replace('／', '/').replace('：', ':')
    val tokenRegex = Regex("(?<![A-Za-z0-9])[A-Za-z0-9-]{8,40}(?![A-Za-z0-9])")
    val dateRegex = Regex("^(?:19|20)\\d{2}[-/]?(?:0?[1-9]|1[0-2])[-/]?(?:0?[1-9]|[12]\\d|3[01])$")
    val phoneRegex = Regex("^(?:\\+?886[- ]?)?0?9\\d{8}$")
    val explicitNonTracking = Regex("(?:訂單(?:編號|號碼|號)?|order\\s*(?:id|no|number)?|手機|電話|tel|phone|金額|價格|price|amount)\\s*[:#：]?\\s*$", RegexOption.IGNORE_CASE)

    return tokenRegex.findAll(normalized).mapNotNull { match ->
        val value = match.value.trim('-')
        if (value.length < 8 || !value.any(Char::isDigit)) return@mapNotNull null
        val compact = value.replace("-", "")
        if (phoneRegex.matches(compact) || dateRegex.matches(value)) return@mapNotNull null
        // If the nearby label explicitly says this is an order number/phone/amount, exclude it.
        val prefixStart = (match.range.first - 28).coerceAtLeast(0)
        val prefix = normalized.substring(prefixStart, match.range.first).takeLast(28)
        if (explicitNonTracking.containsMatchIn(prefix)) return@mapNotNull null
        value
    }.distinctBy { it.uppercase() }.take(30).toList()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun HomeScreen(
    state: MainState,
    onRefresh: () -> Unit,
    onNavigate: (String) -> Unit,
    onAdd: () -> Unit,
    onSearch: () -> Unit,
    onSetToken: () -> Unit,
    onOpen: (PackageEntity) -> Unit,
    onArchive: (PackageEntity) -> Unit,
    onArchiveBatch: (Set<String>) -> Unit,
    initialStatusFilter: String = "all"
) {
    var statusFilter by remember(initialStatusFilter) { mutableStateOf(initialStatusFilter) }
    var carrierFilter by remember { mutableStateOf<String?>(null) }
    var carrierSheet by remember { mutableStateOf(false) }
    var editMode by remember { mutableStateOf(false) }
    var attentionExpanded by rememberSaveable { mutableStateOf(false) }
    var smartPreviewOpen by rememberSaveable { mutableStateOf(false) }
    val selectedIds = remember { mutableStateListOf<String>() }

    val carrierScoped = remember(state.items, carrierFilter) {
        if (carrierFilter == null) state.items else state.items.filter { it.carrierId == carrierFilter }
    }
    val filteredItems = remember(carrierScoped, statusFilter) {
        if (statusFilter == "all") carrierScoped else carrierScoped.filter { it.deliveryStage == statusFilter }
    }
    val activeCarriers = remember(state.items, state.carriers) {
        val ids = state.items.map { it.carrierId }.filter { it.isNotBlank() }.toSet()
        state.carriers.filter { it.id in ids }.sortedBy { it.name }
    }

    Scaffold(
        topBar = {
            if (editMode) {
                TopAppBar(
                    title = { Text("已選 ${selectedIds.size} 項") },
                    navigationIcon = {
                        IconButton(onClick = { editMode = false; selectedIds.clear() }) { Icon(Icons.Default.Close, "取消選取") }
                    },
                    actions = {
                        TextButton(onClick = {
                            val visibleIds = filteredItems.map { it.id }
                            if (visibleIds.all { it in selectedIds }) selectedIds.removeAll(visibleIds.toSet())
                            else visibleIds.forEach { if (it !in selectedIds) selectedIds.add(it) }
                        }) { Text(if (filteredItems.isNotEmpty() && filteredItems.all { it.id in selectedIds }) "清除" else "全選") }
                    }
                )
            } else {
                TopAppBar(
                    title = {
                        val smartSummary = remember(state.items, state.homeAttentionTypes) {
                            smartPreviewSummary(state.items, state.homeAttentionTypes)
                        }
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .clickable { smartPreviewOpen = true }
                                .padding(horizontal = 2.dp, vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    smartSummary.title,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    smartSummary.subtitle,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    },
                    actions = {
                        IconButton(onClick = onSearch) { Icon(Icons.Default.Search, "搜尋所有包裹") }
                        IconButton(onClick = { editMode = true }) { Icon(Icons.Default.Checklist, "批量選取") }
                        IconButton(onClick = onRefresh, enabled = state.apiStatus == ApiStatus.CONNECTED) { Icon(Icons.Default.Refresh, "重新整理") }
                    }
                )
            }
        },
        floatingActionButton = { if (!editMode) FloatingActionButton(onClick = onAdd) { Icon(Icons.Default.Add, "匯入包裹") } },
        bottomBar = {
            if (editMode) {
                BatchActionBar(
                    primaryLabel = "封存",
                    primaryIcon = Icons.Default.Archive,
                    enabled = selectedIds.isNotEmpty(),
                    onPrimary = { onArchiveBatch(selectedIds.toSet()); selectedIds.clear(); editMode = false }
                )
            } else PacklyBottomBar("home", onNavigate)
        }
    ) { padding ->
        PullToRefreshBox(
            isRefreshing = state.loading,
            onRefresh = onRefresh,
            modifier = Modifier.fillMaxSize().padding(padding)
        ) {
            Column(Modifier.fillMaxSize()) {
            when {
                state.apiStatus == ApiStatus.NOT_CONFIGURED -> EmptyState("尚未設定 Track.TW API", "先設定 Token 才能查詢與匯入包裹", "設定 Token", onSetToken)
                state.apiStatus == ApiStatus.CHECKING && state.items.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                state.apiStatus == ApiStatus.INVALID -> EmptyState("API Token 無效", "請重新設定 Track.TW API Token", "重新設定", onSetToken)
                state.loading && state.items.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                else -> {
                    SummaryRow(carrierScoped, statusFilter) { statusFilter = it }
                    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        val selectedCarrier = activeCarriers.firstOrNull { it.id == carrierFilter }
                        AssistChip(
                            onClick = { carrierSheet = true },
                            label = { Text(selectedCarrier?.name ?: "全部物流商") },
                            leadingIcon = {
                                if (selectedCarrier != null) CarrierLogo(selectedCarrier.logo, selectedCarrier.name, Modifier.size(22.dp))
                                else Icon(Icons.Default.FilterList, null, Modifier.size(18.dp))
                            },
                            trailingIcon = { Icon(Icons.Default.ArrowDropDown, null, Modifier.size(18.dp)) }
                        )
                        if (carrierFilter != null) {
                            Spacer(Modifier.width(8.dp))
                            TextButton(onClick = { carrierFilter = null }) { Text("清除物流商篩選") }
                        }
                    }
                    if (statusFilter == "all" && carrierFilter == null && !editMode) {
                        AttentionSection(
                            items = state.items,
                            enabledTypes = state.homeAttentionTypes,
                            expanded = attentionExpanded,
                            onExpandedChange = { attentionExpanded = it },
                            onOpen = onOpen
                        )
                    }
                    if (filteredItems.isEmpty()) EmptyState("沒有符合條件的包裹", "請調整目前的篩選條件", null, null)
                    else LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(filteredItems, key = { it.id }) { item ->
                            if (editMode) SelectablePackageRow(item, state.carriers, item.id in selectedIds) { checked -> if (checked) selectedIds.add(item.id) else selectedIds.remove(item.id) }
                            else SwipePackageRow(item, state.carriers, leftLabel = "封存", leftIcon = Icons.Default.Archive, onLeft = { onArchive(item) }, onOpen = { onOpen(item) })
                        }
                    }
                }
            }
            }
        }
    }

    if (smartPreviewOpen) {
        SmartPreviewSheet(
            items = state.items,
            enabledTypes = state.homeAttentionTypes,
            onOpen = { smartPreviewOpen = false; onOpen(it) },
            onViewAll = { smartPreviewOpen = false; onNavigate("recent_activity") },
            onDismiss = { smartPreviewOpen = false }
        )
    }

    if (carrierSheet) {
        ModalBottomSheet(onDismissRequest = { carrierSheet = false }) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 24.dp)) {
                Text("篩選物流商", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(10.dp))
                ListItem(
                    headlineContent = { Text("全部物流商") },
                    leadingContent = { Icon(Icons.Default.LocalShipping, null) },
                    trailingContent = { if (carrierFilter == null) Icon(Icons.Default.Check, null, tint = MaterialTheme.colorScheme.primary) },
                    modifier = Modifier.clickable { carrierFilter = null; carrierSheet = false }
                )
                activeCarriers.forEach { carrier ->
                    ListItem(
                        headlineContent = { Text(carrier.name) },
                        leadingContent = { CarrierLogo(carrier.logo, carrier.name, Modifier.size(36.dp)) },
                        trailingContent = { if (carrierFilter == carrier.id) Icon(Icons.Default.Check, null, tint = MaterialTheme.colorScheme.primary) },
                        modifier = Modifier.clickable { carrierFilter = carrier.id; carrierSheet = false }
                    )
                }
            }
        }
    }
}

private data class AttentionItem(val item: PackageEntity, val label: String, val priority: Int)

private fun attentionItems(items: List<PackageEntity>): List<AttentionItem> {
    val today = java.time.LocalDate.now()
    return items.mapNotNull { item ->
        when (item.deliveryStage) {
            "exception" -> AttentionItem(item, "配送異常", 1)
            "lost" -> AttentionItem(item, "包裹遺失", 1)
            "arrived" -> {
                val deadline = Regex("\\d{4}-\\d{2}-\\d{2}").find(item.pickupDeadline)?.value
                    ?.let { runCatching { java.time.LocalDate.parse(it) }.getOrNull() }
                val days = deadline?.let { java.time.temporal.ChronoUnit.DAYS.between(today, it) }
                when (days) {
                    0L -> AttentionItem(item, "今天最後取件", 0)
                    1L -> AttentionItem(item, "明天到期", 2)
                    else -> null
                }
            }
            else -> null
        }
    }.sortedWith(compareBy<AttentionItem> { it.priority }.thenBy { it.item.pickupDeadline }.thenByDescending { it.item.updatedAt })
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SmartPreviewSheet(
    items: List<PackageEntity>,
    enabledTypes: Set<String>,
    onOpen: (PackageEntity) -> Unit,
    onViewAll: () -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val active = remember(items) { items.filter { !it.archived } }
    val recentItems = remember(items) { recentLogisticsItems(items) }
    val syncText = remember(smartPreviewOpenKey(items)) { smartPreviewSyncText(context) }
    val now = System.currentTimeMillis()
    val trackingCount = active.count { it.deliveryStage !in setOf("delivered", "returned", "cancel", "lost") }
    val arrivedCount = active.count { it.deliveryStage == "arrived" }
    val deliveryCount = active.count { it.deliveryStage == "out_for_delivery" }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 28.dp)) {
            Text("包裹概況", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            Text(
                "$trackingCount 個追蹤中 · $arrivedCount 個待取件 · $deliveryCount 個配送中",
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(Modifier.height(20.dp))
            Text("最近物流動態", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(3.dp))
            if (recentItems.isEmpty()) {
                Text("近 5 天沒有物流動態", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 6.dp))
            } else {
                recentItems.take(3).forEach { item ->
                    val at = normalizedEventMillis(item.eventTime)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                onDismiss()
                                onOpen(item)
                            }
                            .padding(vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "${item.displayTitle()} · ${DeliveryStages.label(item.deliveryStage)} · ${relativeTimeText(at, now)}",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
                if (recentItems.size > 3) {
                    Row(
                        modifier = Modifier.fillMaxWidth().clickable(onClick = onViewAll).padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("查看全部 ${recentItems.size} 筆", color = MaterialTheme.colorScheme.primary, modifier = Modifier.weight(1f))
                        Text(">", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
            HorizontalDivider(Modifier.padding(vertical = 14.dp))
            Text("同步狀態", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(3.dp))
            Text(syncText, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RecentLogisticsActivityScreen(
    items: List<PackageEntity>,
    onBack: () -> Unit,
    onOpen: (PackageEntity) -> Unit
) {
    val recentItems = remember(items) { recentLogisticsItems(items) }
    val now = System.currentTimeMillis()
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("最近物流動態") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "返回") } }
            )
        }
    ) { padding ->
        if (recentItems.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text("近 5 天沒有物流動態", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
            ) {
                items(recentItems, key = { it.id }) { item ->
                    Column(
                        Modifier.fillMaxWidth().clickable { onOpen(item) }.padding(vertical = 14.dp)
                    ) {
                        Text(item.displayTitle(), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(3.dp))
                        Text(
                            "${DeliveryStages.label(item.deliveryStage)} · ${relativeTimeText(normalizedEventMillis(item.eventTime), now)}",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    HorizontalDivider()
                }
            }
        }
    }
}

private fun recentLogisticsItems(items: List<PackageEntity>): List<PackageEntity> {
    val now = System.currentTimeMillis()
    val window = 5L * 24 * 60 * 60 * 1000
    // PackageEntity is one row per tracked package, so multiple checkpoints for the same
    // package naturally collapse to its newest persisted eventTime/latestEventKey.
    return items
        .filter { !it.archived }
        .filter {
            val at = normalizedEventMillis(it.eventTime)
            at > 0L && now - at in 0L..window
        }
        .sortedByDescending { normalizedEventMillis(it.eventTime) }
}

private data class SmartPreviewSummary(val title: String, val subtitle: String)

private fun smartPreviewSummary(items: List<PackageEntity>, enabledTypes: Set<String>): SmartPreviewSummary {
    // The home preview represents only the single most recent logistics event.
    // Do not call a 1-day/5-day-old event "just updated"; show its real age instead.
    val latest = items
        .asSequence()
        .filter { !it.archived }
        .filter { normalizedEventMillis(it.eventTime) > 0L }
        .maxByOrNull { normalizedEventMillis(it.eventTime) }
    if (latest != null) {
        val at = normalizedEventMillis(latest.eventTime)
        return SmartPreviewSummary(
            title = "1 個包裹 ${smartPreviewUpdateTimeText(at)}",
            subtitle = "${latest.displayTitle()} · ${DeliveryStages.label(latest.deliveryStage)}"
        )
    }

    val attention = attentionItems(items).filter { a ->
        when {
            a.priority == 0 -> "final_day" in enabledTypes
            a.item.deliveryStage == "exception" -> "exception" in enabledTypes
            a.item.deliveryStage == "lost" -> "lost" in enabledTypes
            else -> "tomorrow" in enabledTypes
        }
    }
    if (attention.isNotEmpty()) {
        val first = attention.first()
        return SmartPreviewSummary(
            title = "需要注意 ${attention.size} 項",
            subtitle = "${first.item.displayTitle()} · ${first.label}"
        )
    }
    return SmartPreviewSummary("目前沒有需要注意", "智慧預覽")
}

private fun smartPreviewUpdateTimeText(at: Long, now: Long = System.currentTimeMillis()): String {
    val diff = (now - at).coerceAtLeast(0L)
    return when {
        diff < 60_000L -> "剛剛更新"
        diff < 60L * 60 * 1000 -> "${diff / 60_000L} 分鐘前更新"
        diff < 24L * 60 * 60 * 1000 -> "${diff / (60L * 60 * 1000)} 小時前更新"
        diff < 30L * 24 * 60 * 60 * 1000 -> "${diff / (24L * 60 * 60 * 1000)} 天前更新"
        else -> {
            val formatter = java.text.SimpleDateFormat("MM/dd", java.util.Locale.TAIWAN)
            "${formatter.format(java.util.Date(at))} 更新"
        }
    }
}

private fun latestEventItem(items: List<PackageEntity>): PackageEntity? =
    items.maxByOrNull { normalizedEventMillis(it.eventTime) }

private fun normalizedEventMillis(raw: Long): Long = when {
    raw <= 0L -> 0L
    raw < 10_000_000_000L -> raw * 1000L
    else -> raw
}

private fun relativeTimeText(at: Long, now: Long = System.currentTimeMillis()): String {
    val diff = (now - at).coerceAtLeast(0L)
    return when {
        diff < 60_000L -> "剛剛"
        diff < 60L * 60 * 1000 -> "${diff / 60_000L} 分鐘前"
        diff < 24L * 60 * 60 * 1000 -> "${diff / (60L * 60 * 1000)} 小時前"
        else -> "${diff / (24L * 60 * 60 * 1000)} 天前"
    }
}

private fun smartPreviewSyncText(context: Context): String {
    val prefs = context.getSharedPreferences("packly_widget_state", Context.MODE_PRIVATE)
    if (prefs.getBoolean("package_widget_last_sync_failed", false)) return "最近同步失敗"
    val at = prefs.getLong("package_widget_last_sync_success_at", 0L)
    return if (at > 0L) "最後成功同步 · ${relativeTimeText(at)}" else "尚無成功同步紀錄"
}

private fun smartPreviewOpenKey(items: List<PackageEntity>): String =
    items.joinToString("|") { "${it.id}:${it.latestEventKey}:${it.eventTime}" }

@Composable
private fun AttentionSection(
    items: List<PackageEntity>,
    enabledTypes: Set<String>,
    expanded: Boolean,
    onExpandedChange: (Boolean) -> Unit,
    onOpen: (PackageEntity) -> Unit
) {
    val attention = remember(items, enabledTypes) { attentionItems(items).filter { a ->
        when {
            a.priority == 0 -> "final_day" in enabledTypes
            a.item.deliveryStage == "exception" -> "exception" in enabledTypes
            a.item.deliveryStage == "lost" -> "lost" in enabledTypes
            else -> "tomorrow" in enabledTypes
        }
    } }
    if (attention.isEmpty()) return
    Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 2.dp)) {
        Surface(
            modifier = Modifier.fillMaxWidth().clickable { onExpandedChange(!expanded) },
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.42f)
        ) {
            Row(Modifier.padding(horizontal = 12.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.WarningAmber, null, Modifier.size(19.dp), tint = MaterialTheme.colorScheme.error)
                Spacer(Modifier.width(8.dp))
                Text("需要注意 ${attention.size}", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                Text(if (expanded) "收起" else "展開", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                Icon(if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, Modifier.size(18.dp))
            }
        }
        if (expanded) {
            Spacer(Modifier.height(4.dp))
            attention.forEach { a ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable { onOpen(a.item) }.padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        when (a.priority) { 0 -> Icons.Default.ErrorOutline; 1 -> Icons.Default.WarningAmber; else -> Icons.Default.Schedule },
                        null,
                        Modifier.size(18.dp),
                        tint = if (a.priority <= 1) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.tertiary
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(a.item.displayTitle(), fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                    Spacer(Modifier.width(8.dp))
                    val store = shortStoreName(a.item.pickupStore)
                    Text(
                        if (store.isBlank()) a.label else "${a.label} · $store",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (a.priority <= 1) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Icon(Icons.Default.ChevronRight, null, Modifier.size(18.dp))
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun GlobalSearchScreen(
    state: MainState,
    onBack: () -> Unit,
    onOpen: (PackageEntity) -> Unit
) {
    var query by rememberSaveable { mutableStateOf("") }
    var scope by rememberSaveable { mutableStateOf("all") }
    val scopes = listOf("all" to "全部", "store" to "門市", "nickname" to "備註", "category" to "分類", "carrier" to "物流商")
    fun matches(item: PackageEntity, q: String): Boolean {
        fun hit(v: String) = v.contains(q, ignoreCase = true)
        return when (scope) {
            "store" -> hit(item.pickupStore)
            "nickname" -> hit(item.displayTitle())
            "category" -> hit(item.category)
            "carrier" -> hit(item.carrierName)
            else -> hit(item.pickupStore) || hit(item.displayTitle()) || hit(item.category) || hit(item.carrierName) || hit(item.trackingNumber)
        }
    }
    val q = query.trim()
    val current = remember(state.items, q, scope) { if (q.isBlank()) emptyList() else state.items.filter { matches(it, q) } }
    val archived = remember(state.archivedItems, q, scope) { if (q.isBlank()) emptyList() else state.archivedItems.filter { matches(it, q) } }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("搜尋包裹") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "返回") } }
            )
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                singleLine = true,
                leadingIcon = { Icon(Icons.Default.Search, null) },
                trailingIcon = { if (query.isNotBlank()) IconButton(onClick = { query = "" }) { Icon(Icons.Default.Close, "清除") } },
                placeholder = { Text("搜尋目前與已封存包裹") }
            )
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                scopes.forEach { (key, label) ->
                    FilterChip(selected = scope == key, onClick = { scope = key }, label = { Text(label) })
                }
            }
            when {
                q.isBlank() -> EmptyState("搜尋所有包裹", "可依門市、備註、分類、物流商或單號搜尋目前與封存紀錄", null, null)
                current.isEmpty() && archived.isEmpty() -> EmptyState("找不到包裹", "沒有符合「$q」的目前或封存包裹", null, null)
                else -> LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (current.isNotEmpty()) {
                        item { Text("目前包裹 · ${current.size}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold) }
                        items(current, key = { "inbox-${it.id}" }) { item -> PackageCard(item, state.carriers, onClick = { onOpen(item) }) }
                    }
                    if (archived.isNotEmpty()) {
                        item { Text("已封存 · ${archived.size}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = if (current.isNotEmpty()) 8.dp else 0.dp)) }
                        items(archived, key = { "archive-${it.id}" }) { item -> PackageCard(item, state.carriers, onClick = { onOpen(item) }) }
                    }
                }
            }
        }
    }
}

@Composable
private fun PacklyBottomBar(selected: String, onNavigate: (String) -> Unit) {
    val tabs = listOf(
        Triple("home", "首頁", Icons.Default.Home),
        Triple("archive", "已封存", Icons.Default.Archive),
        Triple("settings", "設定", Icons.Default.Settings)
    )
    Box(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp), contentAlignment = Alignment.Center) {
        Surface(
            modifier = Modifier.fillMaxWidth().height(58.dp),
            shape = RoundedCornerShape(30.dp),
            color = MaterialTheme.colorScheme.surfaceContainer.copy(alpha = 0.94f),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f)),
            shadowElevation = 3.dp,
            tonalElevation = 0.dp
        ) {
            Row(Modifier.fillMaxSize().padding(5.dp), verticalAlignment = Alignment.CenterVertically) {
                tabs.forEach { (key, label, icon) ->
                    val active = selected == key
                    val fg = if (active) MaterialTheme.colorScheme.onSecondaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                    val bg = if (active) MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.78f) else Color.Transparent
                    Row(
                        modifier = Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(24.dp)).background(bg).clickable { if (!active) onNavigate(key) }.padding(horizontal = 6.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(icon, label, tint = fg, modifier = Modifier.size(21.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(label, color = fg, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Medium, maxLines = 1)
                    }
                }
            }
        }
    }
}

@Composable
private fun SummaryRow(items: List<PackageEntity>, selected: String, onSelect: (String) -> Unit) {
    val primary = listOf(
        "all" to "全部",
        "in_transit" to "運輸中",
        "out_for_delivery" to "配送中",
        "arrived" to "待取件",
        "delivered" to "已送達"
    )
    val secondary = listOf(
        "exception" to "異常",
        "picked_up" to "已攬收",
        "customs" to "清關中",
        "pending" to "待攬收",
        "scheduled" to "已排程",
        "return_requested" to "待退回",
        "returned" to "已退回",
        "cancel" to "已取消",
        "lost" to "遺失"
    )
    val secondaryKeys = secondary.map { it.first }.toSet()
    val counts = remember(items) { items.groupingBy { it.deliveryStage }.eachCount() }
    var expanded by rememberSaveable { mutableStateOf(selected in secondaryKeys) }

    @Composable
    fun StatusLabel(key: String, label: String) {
        val count = if (key == "all") items.size else (counts[key] ?: 0)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label)
            if (count > 0) {
                Spacer(Modifier.width(4.dp))
                Text(
                    count.toString(),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }

    Column(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            primary.forEach { (key, label) ->
                FilterChip(
                    selected = selected == key,
                    onClick = { onSelect(key) },
                    label = { StatusLabel(key, label) }
                )
            }
            FilterChip(
                selected = expanded || selected in secondaryKeys,
                onClick = { expanded = !expanded },
                label = { Text("更多") },
                trailingIcon = {
                    Icon(
                        if (expanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                        null,
                        Modifier.size(18.dp)
                    )
                }
            )
        }
        if (expanded) {
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                secondary.forEach { (key, label) ->
                    FilterChip(
                        selected = selected == key,
                        onClick = { onSelect(key) },
                        label = { StatusLabel(key, label) }
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ArchiveScreen(
    state: MainState,
    onNavigate: (String) -> Unit,
    onRefresh: () -> Unit,
    onSearch: () -> Unit,
    onOpen: (PackageEntity) -> Unit,
    onRestore: (PackageEntity) -> Unit,
    onDelete: (PackageEntity) -> Unit,
    onRestoreBatch: (Set<String>) -> Unit,
    onDeleteBatch: (Set<String>) -> Unit
) {
    var statusFilter by remember { mutableStateOf("all") }
    var editMode by remember { mutableStateOf(false) }
    var deleteConfirm by remember { mutableStateOf<Set<String>?>(null) }
    val selectedIds = remember { mutableStateListOf<String>() }
    val filtered = remember(state.archivedItems, statusFilter) {
        if (statusFilter == "all") state.archivedItems else state.archivedItems.filter { it.deliveryStage == statusFilter }
    }
    Scaffold(
        topBar = {
            if (editMode) {
                TopAppBar(
                    title = { Text("已選 ${selectedIds.size} 項") },
                    navigationIcon = { IconButton(onClick = { editMode = false; selectedIds.clear() }) { Icon(Icons.Default.Close, "取消選取") } },
                    actions = {
                        TextButton(onClick = {
                            val visibleIds = filtered.map { it.id }
                            if (visibleIds.all { it in selectedIds }) selectedIds.removeAll(visibleIds.toSet())
                            else visibleIds.forEach { if (it !in selectedIds) selectedIds.add(it) }
                        }) { Text(if (filtered.isNotEmpty() && filtered.all { it.id in selectedIds }) "清除" else "全選") }
                    }
                )
            } else {
                TopAppBar(
                    title = { Text("已封存") },
                    actions = {
                        IconButton(onClick = onSearch) { Icon(Icons.Default.Search, "搜尋所有包裹") }
                        IconButton(onClick = { editMode = true }) { Icon(Icons.Default.Checklist, "批量選取") }
                        IconButton(onClick = onRefresh) { Icon(Icons.Default.Refresh, "重新整理") }
                    }
                )
            }
        },
        bottomBar = {
            if (editMode) {
                BatchActionBar(
                    primaryLabel = "復原",
                    primaryIcon = Icons.Default.Restore,
                    enabled = selectedIds.isNotEmpty(),
                    onPrimary = { onRestoreBatch(selectedIds.toSet()); selectedIds.clear(); editMode = false },
                    secondaryLabel = "刪除",
                    secondaryIcon = Icons.Default.Delete,
                    onSecondary = { deleteConfirm = selectedIds.toSet() }
                )
            } else PacklyBottomBar("archive", onNavigate)
        }
    ) { padding ->
        PullToRefreshBox(isRefreshing = state.loading, onRefresh = onRefresh, modifier = Modifier.fillMaxSize().padding(padding)) {
            Column(Modifier.fillMaxSize()) {
                SummaryRow(state.archivedItems, statusFilter) { statusFilter = it }
                if (filtered.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(if (state.archivedItems.isEmpty()) "尚無封存包裹" else "此狀態沒有封存包裹", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                } else {
                    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(filtered, key = { it.id }) { item ->
                            if (editMode) SelectablePackageRow(item, state.carriers, item.id in selectedIds) { checked -> if(checked) selectedIds.add(item.id) else selectedIds.remove(item.id) }
                            else ArchiveSwipePackageRow(item, state.carriers, onRestore = { onRestore(item) }, onDelete = { deleteConfirm = setOf(item.id) }, onOpen = { onOpen(item) })
                        }
                    }
                }
            }
        }
    }
    deleteConfirm?.let { ids ->
        AlertDialog(
            onDismissRequest = { deleteConfirm = null },
            title = { Text("確認刪除") },
            text = { Text("將永久刪除 ${ids.size} 個封存包裹，確定繼續？此操作無法復原") },
            confirmButton = { TextButton({ onDeleteBatch(ids); selectedIds.removeAll(ids); deleteConfirm = null; editMode = false }) { Text("刪除") } },
            dismissButton = { TextButton({ deleteConfirm = null }) { Text("取消") } }
        )
    }
}

@Composable
private fun SwipePackageRow(item: PackageEntity, carriers: List<Carrier>, leftLabel: String, leftIcon: ImageVector, onLeft: () -> Unit, onOpen: () -> Unit) {
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val revealPx = with(LocalDensity.current) { maxWidth.toPx() * 0.45f }
        var offsetX by remember(item.id) { mutableFloatStateOf(0f) }
        Box(Modifier.fillMaxWidth()) {
            Box(
                Modifier.matchParentSize().clip(RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.secondaryContainer)
                    .clickable { offsetX = 0f; onLeft() }.padding(horizontal = 24.dp),
                contentAlignment = Alignment.CenterEnd
            ) { Row(verticalAlignment = Alignment.CenterVertically) { Icon(leftIcon, null); Spacer(Modifier.width(6.dp)); Text(leftLabel, fontWeight = FontWeight.Medium) } }
            Box(
                Modifier.offset { IntOffset(offsetX.roundToInt(), 0) }
                    .pointerInput(item.id, revealPx) {
                        detectHorizontalDragGestures(
                            onDragEnd = { offsetX = if (offsetX < -revealPx * .32f) -revealPx else 0f },
                            onHorizontalDrag = { change, dragAmount ->
                                change.consume()
                                offsetX = (offsetX + dragAmount).coerceIn(-revealPx, 0f)
                            }
                        )
                    }
            ) { PackageCard(item, carriers, onClick = onOpen) }
        }
    }
}

@Composable
private fun ArchiveSwipePackageRow(item: PackageEntity, carriers: List<Carrier>, onRestore: () -> Unit, onDelete: () -> Unit, onOpen: () -> Unit) {
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val revealPx = with(LocalDensity.current) { maxWidth.toPx() * 0.45f }
        var offsetX by remember(item.id) { mutableFloatStateOf(0f) }
        Box(Modifier.fillMaxWidth()) {
            Row(Modifier.matchParentSize()) {
                Box(
                    Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(topStart = 18.dp, bottomStart = 18.dp)).background(MaterialTheme.colorScheme.primaryContainer)
                        .clickable { offsetX = 0f; onRestore() }.padding(horizontal = 24.dp),
                    contentAlignment = Alignment.CenterStart
                ) { Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Restore, null); Spacer(Modifier.width(6.dp)); Text("復原", fontWeight = FontWeight.Medium) } }
                Box(
                    Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(topEnd = 18.dp, bottomEnd = 18.dp)).background(MaterialTheme.colorScheme.errorContainer)
                        .clickable { offsetX = 0f; onDelete() }.padding(horizontal = 24.dp),
                    contentAlignment = Alignment.CenterEnd
                ) { Row(verticalAlignment = Alignment.CenterVertically) { Text("刪除", fontWeight = FontWeight.Medium); Spacer(Modifier.width(6.dp)); Icon(Icons.Default.Delete, null) } }
            }
            Box(
                Modifier.offset { IntOffset(offsetX.roundToInt(), 0) }
                    .pointerInput(item.id, revealPx) {
                        detectHorizontalDragGestures(
                            onDragEnd = {
                                offsetX = when {
                                    offsetX > revealPx * .32f -> revealPx
                                    offsetX < -revealPx * .32f -> -revealPx
                                    else -> 0f
                                }
                            },
                            onHorizontalDrag = { change, dragAmount ->
                                change.consume()
                                offsetX = (offsetX + dragAmount).coerceIn(-revealPx, revealPx)
                            }
                        )
                    }
            ) { PackageCard(item, carriers, onClick = onOpen) }
        }
    }
}

@Composable
private fun SelectablePackageRow(item: PackageEntity, carriers: List<Carrier>, selected: Boolean, onSelected: (Boolean) -> Unit) {
    Box(Modifier.fillMaxWidth()) {
        PackageCard(item, carriers, onClick = { onSelected(!selected) }, selected = selected)
        if (selected) {
            Surface(
                modifier = Modifier.align(Alignment.TopEnd).padding(8.dp).size(24.dp),
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primary
            ) { Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.Check, null, tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(16.dp)) } }
        }
    }
}

@Composable
private fun BatchActionBar(
    primaryLabel: String,
    primaryIcon: ImageVector,
    enabled: Boolean,
    onPrimary: () -> Unit,
    secondaryLabel: String? = null,
    secondaryIcon: ImageVector? = null,
    onSecondary: (() -> Unit)? = null
) {
    Surface(shadowElevation = 8.dp, tonalElevation = 2.dp) {
        Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = onPrimary, enabled = enabled, modifier = Modifier.weight(1f)) {
                Icon(primaryIcon, null); Spacer(Modifier.width(8.dp)); Text(primaryLabel)
            }
            if (secondaryLabel != null && secondaryIcon != null && onSecondary != null) {
                OutlinedButton(onClick = onSecondary, enabled = enabled, modifier = Modifier.weight(1f)) {
                    Icon(secondaryIcon, null); Spacer(Modifier.width(8.dp)); Text(secondaryLabel)
                }
            }
        }
    }
}

@Composable
private fun PackageCard(item: PackageEntity, carriers: List<Carrier>, onClick: () -> Unit, selected: Boolean = false) {
    val carrier = carriers.firstOrNull { it.id == item.carrierId }
    val showStageBadge = hasMeaningfulDeliveryStage(item.deliveryStage) && cleanLogisticsText(item.latestStatus) != "尚無貨態"
    val stageLabel = if (showStageBadge) DeliveryStages.label(item.deliveryStage) else ""
    val badge = stageBadgeColors(item.deliveryStage)
    val deadline = deadlineDisplay(item.pickupDeadline, item.deliveryStage)
    val shape = RoundedCornerShape(16.dp)
    ElevatedCard(
        modifier = Modifier.fillMaxWidth().then(if (selected) Modifier.border(2.dp, MaterialTheme.colorScheme.primary, shape) else Modifier).clickable(onClick = onClick),
        shape = shape,
        colors = CardDefaults.elevatedCardColors(containerColor = if (selected) MaterialTheme.colorScheme.secondaryContainer.copy(alpha = .55f) else MaterialTheme.colorScheme.surface)
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
            Column(
                modifier = Modifier.width(72.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                CarrierLogo(carrier?.logo, item.carrierName, Modifier.size(48.dp))
                if (item.category.isNotBlank()) {
                    Spacer(Modifier.height(7.dp))
                    PackageMetaBadge(
                        text = item.category,
                        borderColor = Color(0xFF2563EB),
                        textColor = Color(0xFF2563EB)
                    )
                }
                item.amount?.let { amount ->
                    Spacer(Modifier.height(if (item.category.isNotBlank()) 5.dp else 7.dp))
                    PackageMetaBadge(
                        text = "NT$${NumberFormat.getIntegerInstance().format(amount)}",
                        borderColor = Color(0xFFF59E0B),
                        textColor = Color(0xFFB45309)
                    )
                }
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(item.displayTitle(), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(3.dp))
                val place = shortStoreName(item.pickupStore)
                Text(
                    if (place.isNotBlank()) "${item.carrierName.ifBlank { "物流商" }} · $place" else "${item.carrierName.ifBlank { "物流商" }} · ${item.trackingNumber}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(5.dp))
                Text(cleanLogisticsText(item.latestStatus), maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(8.dp))
                Text("最後更新 · ${relativeTime(item.updatedAt)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.width(8.dp))
            Column(horizontalAlignment = Alignment.End) {
                if (showStageBadge) {
                    Surface(shape = RoundedCornerShape(50), color = badge.first, border = BorderStroke(1.dp, badge.second.copy(alpha = .35f))) {
                        Text(stageLabel, modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp), color = badge.second, style = MaterialTheme.typography.labelMedium)
                    }
                }
                deadline?.let { deadlineUi -> Text(deadlineUi.text, style = MaterialTheme.typography.labelSmall, color = if (deadlineUi.urgent) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = if (showStageBadge) 4.dp else 0.dp)) }
            }
        }
    }
}

@Composable
private fun PackageMetaBadge(text: String, borderColor: Color, textColor: Color) {
    Surface(
        modifier = Modifier.widthIn(max = 72.dp),
        shape = RoundedCornerShape(6.dp),
        color = Color.Transparent,
        border = BorderStroke(1.dp, borderColor)
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
            style = MaterialTheme.typography.labelSmall,
            color = textColor,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center
        )
    }
}

private fun carrierLogoUrl(logo: String?): String? {
    val clean = logo?.trim().orEmpty()
    if (clean.isBlank()) return null
    return if (clean.startsWith("http://") || clean.startsWith("https://")) clean else "https://track.tw/storage/$clean"
}

@Composable
private fun CarrierLogo(logo: String?, carrierName: String, modifier: Modifier = Modifier) {
    val model = carrierLogoUrl(logo)
    Surface(modifier, shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
        if (model != null) {
            AsyncImage(model = model, contentDescription = carrierName, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize().padding(5.dp))
        } else {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                if (carrierName.isNotBlank()) Text(carrierName.take(1).uppercase(), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                else Icon(Icons.Default.LocalShipping, carrierName, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

data class DeadlineUi(val text: String, val urgent: Boolean)

private fun deadlineDisplay(raw: String, stage: String): DeadlineUi? {
    // Pickup deadlines only have meaning while the package is actually waiting for pickup.
    // Old/finished packages may retain a historical deadline in Room; never label those as overdue.
    if (raw.isBlank() || stage != DeliveryStages.ARRIVED) return null
    val normalized = Regex("\\d{4}-\\d{2}-\\d{2}").find(raw)?.value ?: return DeadlineUi(raw, false)
    val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { isLenient = false }
    val target = runCatching { sdf.parse(normalized) }.getOrNull() ?: return DeadlineUi(normalized, false)
    val todayText = sdf.format(Date())
    val today = sdf.parse(todayText) ?: return DeadlineUi(normalized, false)
    val days = ((target.time - today.time) / 86_400_000L).toInt()
    return when {
        days < 0 -> DeadlineUi("已逾期", true)
        days == 0 -> DeadlineUi("今天截止", true)
        days <= 3 -> DeadlineUi("剩餘 ${days} 天", true)
        else -> DeadlineUi(SimpleDateFormat("MM/dd", Locale.TAIWAN).format(target), false)
    }
}

private fun shortStoreName(raw: String): String {
    if (raw.isBlank()) return ""
    return raw.substringBefore("（").substringBefore("(").trim()
}


private fun hasMeaningfulDeliveryStage(stage: String?): Boolean = stage in setOf(
    DeliveryStages.IN_TRANSIT,
    DeliveryStages.DELIVERED,
    DeliveryStages.ARRIVED,
    DeliveryStages.PICKED_UP,
    DeliveryStages.EXCEPTION,
    DeliveryStages.RETURN_REQUESTED,
    DeliveryStages.OUT_FOR_DELIVERY,
    DeliveryStages.CUSTOMS,
    DeliveryStages.RETURNED,
    DeliveryStages.CANCEL,
    DeliveryStages.PENDING,
    DeliveryStages.SCHEDULED,
    DeliveryStages.LOST
)

@Composable
private fun stageBadgeColors(stage: String): Pair<Color, Color> = when (stage) {
    "in_transit", "out_for_delivery" -> Color(0xFFFFF1E6) to Color(0xFFB45309)
    "arrived" -> Color(0xFFEAF7EE) to Color(0xFF2E7D32)
    else -> MaterialTheme.colorScheme.surfaceVariant to MaterialTheme.colorScheme.onSurfaceVariant
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DetailScreen(
    item: PackageEntity,
    detail: TrackingPackage?,
    loading: Boolean,
    onBack: () -> Unit,
    onRefresh: () -> Unit,
    onSetTitle: (String) -> Unit,
    onSetAmount: (Long?) -> Unit,
    onSetCategory: (String) -> Unit,
    onToggleNotify: () -> Unit,
    onArchive: () -> Unit,
    onDelete: () -> Unit,
    categories: List<CategoryEntity>,
    carriers: List<Carrier>
) {
    val context = LocalContext.current
    var menu by remember { mutableStateOf(false) }
    var titleDialog by remember { mutableStateOf(false) }
    var amountDialog by remember { mutableStateOf(false) }
    var categorySheet by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    val history = detail?.packageHistory.orEmpty().sortedWith(compareByDescending<PackageHistory> { it.time ?: 0L }.thenByDescending { it.createdAt ?: "" })

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(item.displayTitle(), maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "返回") } },
                actions = {
                    val terminalNotifyState = item.notifyState == "complete" || item.notifyState == "abort"
                    val notifyEnabled = item.notifyState == "active"
                    val notifyKnown = item.notifyState in setOf("active", "inactive", "complete", "abort")
                    IconButton(onClick = onToggleNotify, enabled = !terminalNotifyState) {
                        Icon(
                            if (!notifyKnown) Icons.Default.NotificationsNone else if (notifyEnabled) Icons.Default.Notifications else Icons.Default.NotificationsOff,
                            if (terminalNotifyState) "Track.TW 通知狀態已結束" else if (!notifyKnown) "官方通知狀態未知；點擊嘗試啟用 Track.TW 主動通知" else if (notifyEnabled) "關閉 Track.TW 主動通知" else "開啟 Track.TW 主動通知"
                        )
                    }
                    IconButton(onClick = onRefresh) { Icon(Icons.Default.Refresh, "更新") }
                    Box {
                        IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "更多") }
                        DropdownMenu(menu, { menu = false }) {
                            DropdownMenuItem({ Text("修改備註") }, { menu = false; titleDialog = true }, leadingIcon = { Icon(Icons.Default.Edit, null) })
                            DropdownMenuItem({ Text("記錄金額") }, { menu = false; amountDialog = true }, leadingIcon = { Icon(Icons.Default.AttachMoney, null) })
                            DropdownMenuItem({ Text("選擇分類") }, { menu = false; categorySheet = true }, leadingIcon = { Icon(Icons.Default.Label, null) })
                            HorizontalDivider()
                            DropdownMenuItem({ Text(if (item.folder == "archive") "移回首頁" else "封存包裹") }, { menu = false; onArchive() }, leadingIcon = { Icon(if (item.folder == "archive") Icons.Default.Unarchive else Icons.Default.Archive, null) })
                            DropdownMenuItem({ Text("刪除包裹", color = MaterialTheme.colorScheme.error) }, { menu = false; confirmDelete = true }, leadingIcon = { Icon(Icons.Default.Delete, null, tint = MaterialTheme.colorScheme.error) })
                        }
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            // Only show the staged progress when Track.TW has real history to support it.
            // Older/finished packages can lose detailed history; inferring a stage from the
            // summary status alone can leave the indicator stuck at a misleading position.
            if (history.isNotEmpty()) {
                item { DeliveryProgress(item.deliveryStage) }
            }
            item {
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CarrierLogo(detail?.carrier?.logo ?: carriers.firstOrNull { it.id == item.carrierId || it.name == item.carrierName }?.logo, item.carrierName, Modifier.size(44.dp))
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text("物流廠商", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(item.carrierName.ifBlank { detail?.carrier?.name ?: "未知物流商" }, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        InfoRow("追蹤號碼", item.trackingNumber) {
                            IconButton(onClick = {
                                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                cm.setPrimaryClip(android.content.ClipData.newPlainText("tracking", item.trackingNumber))
                            }) { Icon(Icons.Default.ContentCopy, "複製") }
                        }
                    }
                }
            }
            val rows = metadataRows(detail, item)
            if (rows.isNotEmpty()) item {
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("包裹資訊", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(8.dp))
                        rows.forEachIndexed { i, pair ->
                            InfoRow(pair.first, pair.second)
                            if (i != rows.lastIndex) HorizontalDivider()
                        }
                    }
                }
            }
            item {
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        EditableInfoRow("備註", packageNoteForDisplay(item).ifBlank { "點此設定" }) { titleDialog = true }
                        HorizontalDivider()
                        EditableInfoRow("金額", item.amount?.let { "NT$ ${NumberFormat.getIntegerInstance().format(it)}" } ?: "點此記錄") { amountDialog = true }
                        HorizontalDivider()
                        CategoryEditableInfoRow(item.category, categories) { categorySheet = true }
                    }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("物流貨態", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    if (loading) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                    else TextButton(onClick = onRefresh) { Icon(Icons.Default.Refresh, null); Spacer(Modifier.width(4.dp)); Text("更新紀錄") }
                }
            }
            if (!loading && history.isEmpty()) item { Text("目前沒有物流歷程", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(history.size) { index -> HistoryTimelineItem(history[index], isLatest = index == 0, isLast = index == history.lastIndex) }
        }
    }

    if (titleDialog) TextValueDialog("修改備註", "備註", packageNoteForDisplay(item), { titleDialog = false }) { onSetTitle(it); titleDialog = false }
    if (amountDialog) AmountDialog(item.amount, { amountDialog = false }) { onSetAmount(it); amountDialog = false }
    if (categorySheet) CategorySheet(item.category, categories, { categorySheet = false }) { onSetCategory(it); categorySheet = false }
    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        title = { Text("刪除包裹？") },
        text = { Text("此操作會同步刪除 Track.TW 中的包裹") },
        confirmButton = { Button(onClick = { confirmDelete = false; onDelete() }, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) { Text("刪除") } },
        dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("取消") } }
    )
}

private fun packageNoteForDisplay(item: PackageEntity): String {
    val tracking = item.trackingNumber.trim()
    return item.title.trim().takeIf { it.isNotBlank() && !it.equals(tracking, ignoreCase = true) }.orEmpty()
}

@Composable
private fun DeliveryProgress(stage: String) {
    val steps = listOf("已攬收", "運輸中", "配送中", "待取件", "已送達")
    val current = when (stage) {
        "pending", "scheduled" -> 0
        "in_transit", "customs" -> 1
        "out_for_delivery" -> 2
        "arrived" -> 3
        "picked_up" -> 0
        "delivered" -> 4
        else -> 1
    }
    val completedColor = Color(0xFF2E7D32)
    val currentColor = MaterialTheme.colorScheme.primary
    val futureColor = MaterialTheme.colorScheme.outlineVariant
    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 14.dp)) {
            Box(Modifier.fillMaxWidth()) {
                Canvas(Modifier.fillMaxWidth().height(24.dp).padding(horizontal = 18.dp)) {
                    val step = size.width / 4f
                    for (i in 0 until 4) {
                        drawLine(
                            color = if (i < current) completedColor else futureColor,
                            start = Offset(i * step, size.height / 2f),
                            end = Offset((i + 1) * step, size.height / 2f),
                            strokeWidth = 5f
                        )
                    }
                }
                Row(Modifier.fillMaxWidth()) {
                    steps.forEachIndexed { index, _ ->
                        val done = index < current
                        val active = index == current
                        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                Modifier.size(if (active) 22.dp else 18.dp).clip(CircleShape)
                                    .background(when {
                                        done -> completedColor
                                        active -> currentColor
                                        else -> MaterialTheme.colorScheme.surfaceVariant
                                    }),
                                contentAlignment = Alignment.Center
                            ) {
                                if (done) Icon(Icons.Default.Check, null, Modifier.size(12.dp), tint = Color.White)
                                else if (active) Box(Modifier.size(7.dp).clip(CircleShape).background(MaterialTheme.colorScheme.onPrimary))
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(7.dp))
            Row(Modifier.fillMaxWidth()) {
                steps.forEachIndexed { index, label ->
                    Text(
                        label,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = if (index == current) FontWeight.Bold else FontWeight.Normal,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.weight(1f),
                        maxLines = 1
                    )
                }
            }
        }
    }
}

@Composable
private fun HistoryTimelineItem(event: PackageHistory, isLatest: Boolean, isLast: Boolean) {
    Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min)) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(30.dp).fillMaxHeight()) {
            Box(
                Modifier.size(if (isLatest) 16.dp else 12.dp).clip(CircleShape)
                    .background(if (isLatest) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline)
            )
            if (!isLast) Box(Modifier.width(2.dp).weight(1f).background(MaterialTheme.colorScheme.outlineVariant))
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f).padding(bottom = if (isLast) 4.dp else 24.dp)) {
            val cleanedStatus = cleanLogisticsText(event.status)
            val cleanedCheckpoint = cleanLogisticsText(event.checkpointStatus)
            val historyText = if (isSameStatusTransitionText(event.status) && cleanedCheckpoint.isNotBlank() && cleanedCheckpoint != cleanedStatus) {
                cleanedCheckpoint
            } else cleanedStatus.ifBlank { cleanedCheckpoint.ifBlank { "物流更新" } }
            Text(
                historyText,
                style = if (isLatest) MaterialTheme.typography.titleMedium else MaterialTheme.typography.bodyLarge,
                fontWeight = if (isLatest) FontWeight.SemiBold else FontWeight.Medium
            )
            if (isLatest) {
                val stage = event.deliveryStage?.let(DeliveryStages::label).orEmpty()
                if (stage.isNotBlank()) {
                    Spacer(Modifier.height(5.dp))
                    Surface(shape = RoundedCornerShape(50), color = MaterialTheme.colorScheme.primaryContainer) {
                        Text(stage, Modifier.padding(horizontal = 8.dp, vertical = 3.dp), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    }
                }
            }
            Spacer(Modifier.height(5.dp))
            Text(formatEventTime(event), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

private fun metadataRows(detail: TrackingPackage?, item: PackageEntity? = null): List<Pair<String, String>> {
    val flat = flattenMetadata(detail?.metadata)
    fun find(keys: List<String>): String? = keys.asSequence().mapNotNull { wanted ->
        flat.entries.firstOrNull { (k, _) ->
            val key = k.lowercase()
            val w = wanted.lowercase()
            key == w || key.endsWith(".$w") || key.contains(w)
        }?.value
    }.firstOrNull()

    // Track.TW convenience-store packages expose destination as metadata.dst.
    // metadata itself may be a JSON-encoded string, which flattenMetadata() decodes first.
    val dst = find(listOf("dst")) ?: item?.pickupStore?.takeIf { it.isNotBlank() }
    val (dstName, dstAddress) = splitDestination(dst.orEmpty())

    val fallbackStoreName = find(listOf(
        "pickup_store_name", "pickupStoreName", "store_name", "storeName", "shop_name", "shopName",
        "branch_name", "branchName", "recipient_store", "recipientStore", "pickup_store", "pickupStore",
        "取件門市", "門市名稱", "取貨門市", "取件店舖", "取貨店舖", "門市"
    ))
    val fallbackStoreAddress = find(listOf(
        "pickup_store_address", "pickupStoreAddress", "store_address", "storeAddress", "shop_address", "shopAddress",
        "branch_address", "branchAddress", "pickup_address", "pickupAddress", "recipient_address", "recipientAddress",
        "取件地址", "門市地址", "取貨地址"
    ))

    val storeName = dstName.ifBlank { fallbackStoreName.orEmpty() }
    val storeAddress = dstAddress?.takeIf { it.isNotBlank() } ?: fallbackStoreAddress
    val payment = find(listOf("payment", "payment_method", "paymentMethod", "cod", "付款方式", "付款"))
    val deadline = find(listOf("deadline", "pickup_deadline", "expire", "expiry", "pickup_date", "取件期限", "領取期限"))
        ?: item?.pickupDeadline?.takeIf { it.isNotBlank() }

    return buildList {
        storeName.takeIf { it.isNotBlank() }?.let { add("取件門市" to it) }
        storeAddress?.takeIf { it.isNotBlank() }?.let { add("門市地址" to it) }
        payment?.takeIf { it.isNotBlank() }?.let { add("付款方式" to it) }
        deadline?.takeIf { it.isNotBlank() }?.let { add("取件期限" to it) }
    }.distinctBy { it.first }
}

private fun splitDestination(raw: String): Pair<String, String?> {
    val clean = raw.trim()
    if (clean.isBlank()) return "" to null
    val match = Regex("""^(.+?)\s*[（(](.+)[）)]$""").matchEntire(clean)
    return if (match != null) {
        match.groupValues[1].trim() to match.groupValues[2].trim().takeIf { it.isNotBlank() }
    } else {
        clean to null
    }
}

private fun flattenMetadata(meta0: com.google.gson.JsonElement?): LinkedHashMap<String, String> {
    var meta = meta0 ?: return linkedMapOf()
    if (meta.isJsonPrimitive && meta.asJsonPrimitive.isString) {
        val raw = meta.asString.trim()
        if (raw.startsWith("{") || raw.startsWith("[")) {
            runCatching { com.google.gson.JsonParser.parseString(raw) }.getOrNull()?.let { meta = it }
        }
    }
    val flat = linkedMapOf<String, String>()
    fun walk(prefix: String, e: com.google.gson.JsonElement) {
        when {
            e.isJsonObject -> e.asJsonObject.entrySet().forEach { (k, v) -> walk(if (prefix.isBlank()) k else "$prefix.$k", v) }
            e.isJsonArray -> e.asJsonArray.forEachIndexed { i, v -> walk("$prefix[$i]", v) }
            e.isJsonPrimitive -> scalarText(e)?.takeIf { it.isNotBlank() }?.let { flat[prefix] = it }
        }
    }
    when {
        meta.isJsonObject || meta.isJsonArray -> walk("", meta)
        meta.isJsonPrimitive -> flat["value"] = meta.asString
    }
    return flat
}

private fun scalarText(e: com.google.gson.JsonElement): String? = when {
    !e.isJsonPrimitive -> null
    e.asJsonPrimitive.isString -> e.asString
    e.asJsonPrimitive.isNumber -> e.asNumber.toString()
    e.asJsonPrimitive.isBoolean -> if (e.asBoolean) "是" else "否"
    else -> null
}

@Composable
private fun InfoRow(label: String, value: String, trailing: (@Composable () -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.widthIn(min = 86.dp))
        Spacer(Modifier.width(12.dp))
        Text(value, Modifier.weight(1f), fontWeight = FontWeight.Medium)
        trailing?.invoke()
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun NotificationStageDialog(selected: Set<String>, onStage: (String, Boolean) -> Unit, onStages: (Set<String>) -> Unit, onDismiss: () -> Unit) {
    val stages = listOf("in_transit" to "運輸中", "out_for_delivery" to "配送中", "arrived" to "待取件", "delivered" to "已送達", "exception" to "異常", "picked_up" to "已攬收", "customs" to "清關中", "pending" to "待攬收", "scheduled" to "已排程", "return_requested" to "待退回", "returned" to "已退回", "cancel" to "已取消", "lost" to "遺失")
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("通知狀態") },
        text = {
            Column {
                Text("選擇哪些貨態變化要發送 Android 系統通知", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = { onStages(stages.map { it.first }.toSet()) }) { Text("全選") }
                    TextButton(onClick = { onStages(emptySet()) }) { Text("清除") }
                }
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    stages.chunked(4).forEach { rowStages ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            rowStages.forEach { (key, label) ->
                                FilterChip(
                                    selected = key in selected,
                                    onClick = { onStage(key, key !in selected) },
                                    modifier = Modifier.weight(1f).height(40.dp),
                                    label = { Text(label, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, maxLines = 1) }
                                )
                            }
                            repeat(4 - rowStages.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("完成") } }
    )
}

@Composable
private fun EditableInfoRow(label: String, value: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Text(value, color = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.width(6.dp)); Icon(Icons.Default.ChevronRight, null)
    }
}

@Composable
private fun CategoryEditableInfoRow(value: String, categories: List<CategoryEntity>, onClick: () -> Unit) {
    val category = categories.firstOrNull { it.name == value }
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("分類", Modifier.weight(1f))
        if (category != null) {
            CategoryIcon(category, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp))
        }
        Text(value.ifBlank { "點此設定" }, color = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.width(6.dp)); Icon(Icons.Default.ChevronRight, null)
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun HomeAttentionDialog(selected: Set<String>, onSelected: (Set<String>) -> Unit, onDismiss: () -> Unit) {
    val options = listOf("final_day" to "最後取件日", "tomorrow" to "明天到期", "exception" to "物流異常", "lost" to "包裹遺失")
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("首頁需要注意") },
        text = {
            Column {
                Text("選擇首頁「需要注意」要顯示的提醒", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = { onSelected(options.map { it.first }.toSet()) }) { Text("全選") }
                    TextButton(onClick = { onSelected(emptySet()) }) { Text("清除") }
                }
                options.forEach { (key, label) ->
                    Row(Modifier.fillMaxWidth().clickable { onSelected(if (key in selected) selected - key else selected + key) }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = key in selected, onCheckedChange = { checked -> onSelected(if (checked) selected + key else selected - key) })
                        Spacer(Modifier.width(8.dp)); Text(label)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("完成") } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SettingsScreen(
    state: MainState,
    onNavigate: (String) -> Unit,
    onToken: () -> Unit,
    onClearToken: () -> Unit,
    onVerifyToken: () -> Unit,
    onClipboard: (Boolean) -> Unit,
    onDeviceNotifications: (Boolean) -> Unit,
    onTestDeviceNotification: () -> Unit,
    onNotificationStage: (String, Boolean) -> Unit,
    onNotificationStages: (Set<String>) -> Unit,
    onHomeAttentionTypes: (Set<String>) -> Unit,
    onPickupTomorrow: (Boolean) -> Unit,
    onPickupFinalDay: (Boolean) -> Unit,
    onDiscordEnabled: (Boolean) -> Unit,
    onSaveWebhook: (String) -> Unit,
    onTestWebhook: (String) -> Unit,
    onThemeColor: (Int) -> Unit,
    onSyncInterval: (Int) -> Unit,
    onAutoArchive: (Boolean) -> Unit,
    onAutoCheckUpdates: (Boolean) -> Unit,
    categories: List<CategoryEntity>,
    onAddCategory: (String, String, String) -> Unit,
    onEditCategory: (CategoryEntity, String, String, String) -> Unit,
    onDeleteCategory: (CategoryEntity) -> Unit
) {
    var webhook by remember(state.discordWebhook) { mutableStateOf(state.discordWebhook) }
    var themePicker by remember { mutableStateOf(false) }
    var categoryManager by remember { mutableStateOf(false) }
    var syncIntervalDialog by remember { mutableStateOf(false) }
    var notificationStageDialog by remember { mutableStateOf(false) }
    var pickupReminderDialog by remember { mutableStateOf(false) }
    var homeAttentionDialog by remember { mutableStateOf(false) }
    var discordDialog by remember { mutableStateOf(false) }
    var apiDialog by remember { mutableStateOf(false) }
    var aboutPage by remember { mutableStateOf(false) }
    var appNotificationDetailsExpanded by rememberSaveable { mutableStateOf(false) }

    BackHandler(enabled = aboutPage) { aboutPage = false }

    if (aboutPage) {
        val context = LocalContext.current
        val versionName = remember {
            runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "" }.getOrDefault("")
        }
        Scaffold(topBar = { TopAppBar(title = { Text("關於") }, navigationIcon = { IconButton(onClick = { aboutPage = false }) { Icon(Icons.Default.ArrowBack, "返回") } }) }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Spacer(Modifier.height(24.dp))
                Text("Packly", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                Text(versionName, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(18.dp))
                Text("簡單、快速的包裹追蹤與取件管理工具", style = MaterialTheme.typography.bodyLarge, textAlign = TextAlign.Center)
                Spacer(Modifier.height(24.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(onClick = { /* 更新來源待 GitHub Release 建立後接入 */ }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Refresh, null); Spacer(Modifier.width(6.dp)); Text("檢查更新") }
                    OutlinedButton(onClick = { /* 更新日誌待 Release 資料源建立後接入 */ }, modifier = Modifier.weight(1f)) { Text("更新日誌") }
                }
                Spacer(Modifier.height(24.dp))
                SettingsSection("更新") {
                    SettingsSwitchRow("自動檢查更新", "有新版本時主動提醒", state.autoCheckUpdates, onAutoCheckUpdates)
                }
            }
        }
        return
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("設定") }) },
        bottomBar = { PacklyBottomBar("settings", onNavigate) }
    ) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            item {
                SettingsSection("包裹與自動化") {
                    SettingsNavRow("檢查頻率", "背景自動檢查包裹狀態", syncIntervalLabel(state.syncIntervalMinutes), Icons.Default.Sync) { syncIntervalDialog = true }
                    HorizontalDivider(Modifier.padding(vertical = 8.dp))
                    SettingsSwitchRow("自動偵測剪貼簿單號", "進入或返回 App 時偵測疑似物流單號；只有按下「匯入」才會送到 API", state.clipboardDetect, onClipboard)
                    HorizontalDivider(Modifier.padding(vertical = 8.dp))
                    SettingsSwitchRow("已送達後自動封存", "包裹送達 2 天後自動封存", state.autoArchiveDelivered, onAutoArchive)
                }
            }
            item {
                SettingsSection("通知") {
                    SettingsNavRow("首頁需要注意", "選擇首頁要顯示哪些重要提醒", "已選 ${state.homeAttentionTypes.size} 種", Icons.Default.WarningAmber) { homeAttentionDialog = true }
                    HorizontalDivider(Modifier.padding(vertical = 8.dp))
                    SettingsExpandableSwitchRow(
                        title = "App 推送通知",
                        description = "貨態出現新事件時發送 Android 系統通知",
                        checked = state.deviceNotifications,
                        expanded = appNotificationDetailsExpanded,
                        onChecked = onDeviceNotifications,
                        onExpandedChange = { appNotificationDetailsExpanded = !appNotificationDetailsExpanded }
                    )
                    if (appNotificationDetailsExpanded) {
                        HorizontalDivider(Modifier.padding(vertical = 8.dp))
                        SettingsNavRow("測試通知", "發送一則 Android 系統測試通知", null, Icons.Default.NotificationsActive) { onTestDeviceNotification() }
                        HorizontalDivider(Modifier.padding(vertical = 8.dp))
                        SettingsNavRow("通知狀態", "選擇要接收哪些貨態變化", "已選 ${state.notificationStages.size} 種", Icons.Default.Notifications) { notificationStageDialog = true }
                        HorizontalDivider(Modifier.padding(vertical = 8.dp))
                        SettingsNavRow("取件期限提醒", "明天到期、最後取件日", null, Icons.Default.Schedule) { pickupReminderDialog = true }
                        HorizontalDivider(Modifier.padding(vertical = 8.dp))
                        SettingsNavRow("Discord 通知", "Webhook 推送", if (state.discordEnabled) "已啟用" else "未啟用", Icons.Default.Send) { discordDialog = true }
                    }
                }
            }
            item {
                SettingsSection("個人化") {
                    SettingsNavRow("分類管理", "新增、刪除、編輯分類", null, Icons.Default.Category) { categoryManager = true }
                    HorizontalDivider(Modifier.padding(vertical = 8.dp))
                    SettingsNavRow("主題色", String.format("#%06X", 0xFFFFFF and state.themeColor), null, Icons.Default.Palette) { themePicker = true }
                }
            }
            item {
                SettingsSection("資料與連線") {
                    SettingsNavRow("Track.TW API", apiStatusText(state.apiStatus), if (state.tokenPresent) "已設定" else "未設定", Icons.Default.Cloud) { apiDialog = true }
                }
            }
            item {
                SettingsSection("關於") {
                    SettingsNavRow("關於", "", null, Icons.Default.Info) { aboutPage = true }
                }
            }
        }
    }
    if (notificationStageDialog) NotificationStageDialog(
        selected = state.notificationStages,
        onStage = onNotificationStage,
        onStages = onNotificationStages,
        onDismiss = { notificationStageDialog = false }
    )
    if (homeAttentionDialog) HomeAttentionDialog(
        selected = state.homeAttentionTypes,
        onSelected = onHomeAttentionTypes,
        onDismiss = { homeAttentionDialog = false }
    )
    if (pickupReminderDialog) AlertDialog(
        onDismissRequest = { pickupReminderDialog = false },
        title = { Text("取件期限提醒") },
        text = {
            Column {
                SettingsSwitchRow("明天到期", "在取件期限前一天提醒", state.pickupTomorrow, onPickupTomorrow)
                HorizontalDivider(Modifier.padding(vertical = 10.dp))
                SettingsSwitchRow("最後取件日", "在最後取件日再次提醒", state.pickupFinalDay, onPickupFinalDay)
            }
        },
        confirmButton = { TextButton(onClick = { pickupReminderDialog = false }) { Text("完成") } }
    )
    if (discordDialog) AlertDialog(
        onDismissRequest = { discordDialog = false },
        icon = { DiscordLogo(Modifier.size(30.dp)) },
        title = { Text("Discord 通知") },
        text = {
            Column {
                SettingsSwitchRow("啟用 Discord Webhook", "貨態更新時同步傳送到指定 Discord 頻道", state.discordEnabled, onDiscordEnabled)
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(webhook, { webhook = it }, Modifier.fillMaxWidth(), label = { Text("Webhook URL") }, singleLine = true)
                if (state.discordSavedAt > 0L && webhook.trim() == state.discordWebhook) {
                    Spacer(Modifier.height(8.dp)); Text("✓ Webhook 已儲存", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                }
            }
        },
        confirmButton = { Button(onClick = { onSaveWebhook(webhook) }) { Text("儲存") } },
        dismissButton = { OutlinedButton(onClick = { onTestWebhook(webhook) }) { Text("測試通知") } }
    )
    if (apiDialog) AlertDialog(
        onDismissRequest = { apiDialog = false },
        title = { Text("Track.TW API") },
        text = {
            Column {
                ListItem(
                    headlineContent = { Text("API Token") },
                    supportingContent = { Text(apiStatusText(state.apiStatus)) },
                    leadingContent = { Icon(apiStatusIcon(state.apiStatus), null) },
                    trailingContent = { TextButton(onClick = onToken) { Text(if (state.tokenPresent) "修改" else "設定") } },
                    colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                )
                if (state.tokenPresent) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onVerifyToken, enabled = state.apiStatus != ApiStatus.CHECKING) { Text("測試連線") }
                    TextButton(onClick = onClearToken) { Text("清除 Token") }
                }
            }
        },
        confirmButton = { TextButton(onClick = { apiDialog = false }) { Text("完成") } }
    )

    if (themePicker) ThemeColorDialog(
        initial = Color(state.themeColor),
        onDismiss = { themePicker = false },
        onSave = { onThemeColor(it.toArgb()); themePicker = false }
    )
    if (categoryManager) CategoryManagerSheet(
        categories = categories,
        onDismiss = { categoryManager = false },
        onAdd = onAddCategory,
        onEdit = onEditCategory,
        onDelete = onDeleteCategory
    )
    if (syncIntervalDialog) SyncIntervalDialog(
        selected = state.syncIntervalMinutes,
        onDismiss = { syncIntervalDialog = false },
        onSelect = { onSyncInterval(it); syncIntervalDialog = false }
    )
}
@Composable
private fun SyncIntervalDialog(selected: Int, onDismiss: () -> Unit, onSelect: (Int) -> Unit) {
    val options = listOf(15, 30, 60, 120)
    var customSelected by remember(selected) { mutableStateOf(selected !in options) }
    var customValue by remember(selected) { mutableStateOf(if (selected !in options) selected.toString() else "") }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("自動更新頻率") },
        text = {
            Column {
                options.forEach { minutes ->
                    Row(
                        Modifier.fillMaxWidth().clickable { onSelect(minutes) }.padding(vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = !customSelected && selected == minutes, onClick = { onSelect(minutes) })
                        Spacer(Modifier.width(8.dp))
                        Text(syncIntervalLabel(minutes))
                    }
                }
                Row(
                    Modifier.fillMaxWidth().clickable { customSelected = true }.padding(vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(selected = customSelected, onClick = { customSelected = true })
                    Spacer(Modifier.width(8.dp))
                    Text("自訂")
                }
                if (customSelected) {
                    OutlinedTextField(
                        value = customValue,
                        onValueChange = { customValue = it.filter(Char::isDigit); error = null },
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                        label = { Text("分鐘") },
                        supportingText = { Text(error ?: "最低 15 分鐘") },
                        isError = error != null,
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )
                }
            }
        },
        confirmButton = {
            if (customSelected) TextButton(onClick = {
                val value = customValue.toIntOrNull()
                when {
                    value == null -> error = "請輸入分鐘數"
                    value < 15 -> error = "背景自動更新最低為 15 分鐘"
                    else -> onSelect(value)
                }
            }) { Text("確定") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("取消") } }
    )
}

private fun syncIntervalLabel(minutes: Int): String = when (minutes) {
    15 -> "15 分鐘"
    30 -> "30 分鐘"
    60 -> "1 小時"
    120 -> "2 小時"
    else -> "$minutes 分鐘"
}

private fun apiStatusText(status: ApiStatus) = when (status) {
    ApiStatus.NOT_CONFIGURED -> "尚未設定"
    ApiStatus.CHECKING -> "驗證中…"
    ApiStatus.CONNECTED -> "已連線"
    ApiStatus.INVALID -> "Token 無效"
    ApiStatus.NETWORK_ERROR -> "連線失敗"
}
private fun apiStatusIcon(status: ApiStatus) = when (status) {
    ApiStatus.CONNECTED -> Icons.Default.CheckCircle
    ApiStatus.INVALID -> Icons.Default.Error
    ApiStatus.NETWORK_ERROR -> Icons.Default.CloudOff
    ApiStatus.CHECKING -> Icons.Default.Sync
    ApiStatus.NOT_CONFIGURED -> Icons.Default.Key
}

@Composable
private fun DiscordLogo(modifier: Modifier = Modifier) {
    Icon(
        painter = painterResource(R.drawable.ic_discord),
        contentDescription = "Discord",
        modifier = modifier,
        tint = MaterialTheme.colorScheme.onSurfaceVariant
    )
}

@Composable
private fun SettingsNavRow(title: String, description: String, value: String?, icon: ImageVector, onClick: () -> Unit) {
    val rowShape = RoundedCornerShape(12.dp)
    ListItem(
        headlineContent = { Text(title) },
        supportingContent = { if (description.isNotBlank()) Text(description) },
        leadingContent = {
            if (title == "Discord 通知") DiscordLogo(Modifier.size(24.dp))
            else Icon(icon, null)
        },
        trailingContent = { Row(verticalAlignment = Alignment.CenterVertically) { value?.let { Text(it, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall); Spacer(Modifier.width(4.dp)) }; Icon(Icons.Default.ChevronRight, null) } },
        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
        modifier = Modifier
            .fillMaxWidth()
            .clip(rowShape)
            .clickable(onClick = onClick)
    )
}

@Composable
private fun SettingsSection(
    title: String,
    expanded: Boolean = true,
    onToggle: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    Column {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .then(if (onToggle != null) Modifier.clickable(onClick = onToggle) else Modifier)
                .padding(vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            if (onToggle != null) {
                Icon(
                    imageVector = if (expanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                    contentDescription = if (expanded) "收合" else "展開",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        if (expanded) {
            Spacer(Modifier.height(8.dp))
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
                elevation = CardDefaults.elevatedCardElevation(defaultElevation = 0.dp)
            ) {
                Column(Modifier.padding(16.dp), content = content)
            }
        }
    }
}

@Composable
private fun SettingsExpandableSwitchRow(
    title: String,
    description: String,
    checked: Boolean,
    expanded: Boolean,
    onChecked: (Boolean) -> Unit,
    onExpandedChange: () -> Unit
) {
    val rowShape = RoundedCornerShape(12.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(rowShape),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(
            Modifier
                .weight(1f)
                .clip(rowShape)
                .clickable(onClick = onExpandedChange)
                .padding(vertical = 6.dp, horizontal = 2.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, fontWeight = FontWeight.Medium)
                Spacer(Modifier.width(4.dp))
                Icon(
                    if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    if (expanded) "收合" else "展開",
                    modifier = Modifier.size(20.dp)
                )
            }
            Text(description, style = MaterialTheme.typography.bodySmall)
        }
        Switch(checked, onChecked)
    }
}

@Composable
private fun SettingsSwitchRow(title: String, description: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    val rowShape = RoundedCornerShape(12.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(rowShape)
            .clickable { onChecked(!checked) }
            .padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.Medium); Text(description, style = MaterialTheme.typography.bodySmall) }
        Switch(checked, onChecked)
    }
}

private data class ImportRowUi(
    val key: Long,
    val number: String = "",
    val title: String = "",
    val amount: String = "",
    val category: String = "",
    val selectedCarrier: Carrier? = null,
    val candidates: List<Carrier> = emptyList(),
    val detecting: Boolean = false,
    val extras: Map<String, String> = emptyMap(),
    val lastDetectedNumber: String = "",
    val detectFailed: Boolean = false,
    val expanded: Boolean = true
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ImportPackagesScreen(
    initialNumbers: List<String>,
    state: MainState,
    onBack: () -> Unit,
    onNeedToken: () -> Unit,
    onDetect: (String, (List<Carrier>) -> Unit) -> Unit,
    onDetectBatch: (List<String>, (Map<String, List<Carrier>>) -> Unit) -> Unit,
    onImport: (List<PackageImportDraft>) -> Unit
) {
    val context = LocalContext.current
    val rows = remember(initialNumbers) {
        mutableStateListOf<ImportRowUi>().apply {
            val init = initialNumbers.ifEmpty { listOf("") }
            init.forEachIndexed { i, n -> add(ImportRowUi(System.nanoTime() + i, number = n, expanded = i == 0)) }
        }
    }
    var categoryIndex by remember { mutableStateOf<Int?>(null) }
    var carrierCandidatesIndex by remember { mutableStateOf<Int?>(null) }
    var openCarrierSelectorKey by remember { mutableStateOf<Long?>(null) }
    val scanner = remember {
        val options = GmsBarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_ALL_FORMATS).enableAutoZoom().build()
        GmsBarcodeScanning.getClient(context, options)
    }

    fun update(index: Int, transform: (ImportRowUi) -> ImportRowUi) { if (index in rows.indices) rows[index] = transform(rows[index]) }
    fun focus(index: Int) { rows.indices.forEach { i -> update(i) { it.copy(expanded = i == index) } } }
    fun addRow(number: String = "") {
        rows.indices.forEach { i -> update(i) { it.copy(expanded = false) } }
        rows.add(ImportRowUi(System.nanoTime(), number = number, expanded = true))
    }
    fun detect(index: Int, number: String) {
        val clean = number.trim()
        if (clean.isBlank()) return
        if (state.apiStatus == ApiStatus.NOT_CONFIGURED || state.apiStatus == ApiStatus.INVALID) { onNeedToken(); return }
        update(index) { it.copy(detecting = true, candidates = emptyList(), detectFailed = false) }
        onDetect(clean) { found ->
            update(index) { old ->
                old.copy(
                    detecting = false,
                    candidates = found,
                    selectedCarrier = if (found.size == 1) found.first() else old.selectedCarrier,
                    extras = if (found.size == 1) emptyMap() else old.extras,
                    lastDetectedNumber = clean,
                    detectFailed = found.isEmpty() && old.selectedCarrier == null
                )
            }
        }
    }

    rows.forEachIndexed { index, row ->
        LaunchedEffect(row.number) {
            val clean = row.number.trim()
            if (clean.length >= 8 && clean.any(Char::isDigit) && clean != row.lastDetectedNumber) {
                delay(500)
                if (rows.getOrNull(index)?.number?.trim() == clean) detect(index, clean)
            }
        }
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("匯入包裹") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "返回") } }) },
        bottomBar = {
            Surface(shadowElevation = 8.dp) {
                Button(
                    onClick = {
                        val invalidIndex = rows.indexOfFirst { !isImportRowValid(it) }
                        if (invalidIndex >= 0) {
                            update(invalidIndex) { row -> row.copy(
                                expanded = true,
                                detectFailed = row.selectedCarrier == null && row.number.isNotBlank()
                            ) }
                            focus(invalidIndex)
                            return@Button
                        }
                        val drafts = rows.mapNotNull { row ->
                            val c = row.selectedCarrier ?: return@mapNotNull null
                            PackageImportDraft(row.number.trim(), c, row.title.trim(), row.amount.toLongOrNull(), row.category, row.extras)
                        }
                        onImport(drafts)
                    },
                    enabled = rows.isNotEmpty() && !state.loading,
                    modifier = Modifier.fillMaxWidth().padding(16.dp)
                ) {
                    if (state.loading) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(6.dp)); Text(if (state.loading) "匯入中…" else "匯入 ${rows.size} 筆包裹")
                }
            }
        }
    ) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                if (state.apiStatus != ApiStatus.CONNECTED) {
                    AssistChip(onClick = onNeedToken, label = { Text("${apiStatusText(state.apiStatus)} · 點此設定 API") }, leadingIcon = { Icon(Icons.Default.Key, null) })
                    Spacer(Modifier.height(8.dp))
                }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("包裹清單（共 ${rows.size} 筆）", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    TextButton(onClick = { addRow() }) { Icon(Icons.Default.Add, null); Text("新增一筆") }
                }
            }
            items(rows.size, key = { rows[it].key }) { index ->
                val row = rows[index]
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().clickable { update(index) { it.copy(expanded = !it.expanded) } }) {
                            Surface(shape = RoundedCornerShape(8.dp), color = MaterialTheme.colorScheme.primaryContainer) { Text("${index + 1}", Modifier.padding(horizontal = 9.dp, vertical = 5.dp), color = MaterialTheme.colorScheme.onPrimaryContainer) }
                            Spacer(Modifier.width(8.dp))
                            Column(Modifier.weight(1f)) {
                                Text(row.title.ifBlank { "包裹 ${index + 1}" }, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                if (!row.expanded) {
                                    Text(
                                        listOf(row.number.ifBlank { "尚未輸入單號" }, row.selectedCarrier?.name.orEmpty()).filter { it.isNotBlank() }.joinToString(" · "),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                            Icon(if (row.expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore, if (row.expanded) "收合" else "展開")
                            if (rows.size > 1) IconButton(onClick = { rows.removeAt(index) }) { Icon(Icons.Default.Close, "移除") }
                        }

                        if (row.expanded) {
                            OutlinedTextField(
                                row.number,
                                { value ->
                                    val direct = value.trim()
                                    val isDirectTrackingInput = direct.length in 8..40 &&
                                        direct.any(Char::isDigit) &&
                                        direct.all { it.isLetterOrDigit() || it == '-' }
                                    val found = if (isDirectTrackingInput) listOf(direct) else findTrackingCandidates(value)
                                    when {
                                        found.size > 1 -> {
                                            val existingNumbers = rows.map { it.number.trim().uppercase() }.toMutableSet()
                                            update(index) { it.copy(number = found.first(), selectedCarrier = null, candidates = emptyList(), extras = emptyMap(), detecting = true, lastDetectedNumber = found.first(), detectFailed = false) }
                                            existingNumbers.add(found.first().uppercase())
                                            found.drop(1).forEach { n ->
                                                if (n.uppercase() !in existingNumbers) {
                                                    rows.add(ImportRowUi(System.nanoTime() + rows.size, number = n, detecting = true, lastDetectedNumber = n, expanded = false))
                                                    existingNumbers.add(n.uppercase())
                                                }
                                            }
                                            if (state.apiStatus == ApiStatus.CONNECTED) {
                                                onDetectBatch(found) { result ->
                                                    rows.indices.forEach { i ->
                                                        val number = rows[i].number.trim()
                                                        val carriers = result[number].orEmpty()
                                                        if (number in found) update(i) { old -> old.copy(
                                                            detecting = false,
                                                            candidates = carriers,
                                                            selectedCarrier = if (carriers.size == 1) carriers.first() else old.selectedCarrier,
                                                            extras = if (carriers.size == 1) emptyMap() else old.extras,
                                                            detectFailed = carriers.isEmpty() && old.selectedCarrier == null,
                                                            lastDetectedNumber = number
                                                        ) }
                                                    }
                                                }
                                            } else rows.indices.forEach { i -> if (rows[i].number in found) update(i) { it.copy(detecting = false) } }
                                        }
                                        found.size == 1 && (value.any(Char::isWhitespace) || value.contains(':') || value.contains(',') || value.contains('/') || value.length > found.first().length) -> {
                                            update(index) { it.copy(number = found.first(), selectedCarrier = null, candidates = emptyList(), extras = emptyMap(), lastDetectedNumber = "", detectFailed = false) }
                                        }
                                        else -> {
                                            update(index) { it.copy(number = value.trim(), selectedCarrier = null, candidates = emptyList(), extras = emptyMap(), lastDetectedNumber = "", detectFailed = false) }
                                        }
                                    }
                                },
                                Modifier.fillMaxWidth(),
                                label = { Text("追蹤號碼") },
                                singleLine = true,
                                trailingIcon = {
                                    IconButton(onClick = {
                                        scanner.startScan().addOnSuccessListener { barcode ->
                                            val raw = barcode.rawValue.orEmpty().trim()
                                            if (raw.isNotBlank()) update(index) { it.copy(number = raw, selectedCarrier = null, candidates = emptyList(), extras = emptyMap(), lastDetectedNumber = "", detectFailed = false) }
                                        }
                                    }) { Icon(Icons.Default.QrCodeScanner, "掃描條碼或 QR Code") }
                                }
                            )
                            OutlinedButton(onClick = { detect(index, row.number) }, enabled = row.number.isNotBlank() && !row.detecting, modifier = Modifier.fillMaxWidth()) {
                                if (row.detecting) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp) else Icon(Icons.Default.AutoAwesome, null)
                                Spacer(Modifier.width(6.dp)); Text(if (row.detecting) "辨識中…" else "自動辨識物流商")
                            }
                            if (row.selectedCarrier == null && row.candidates.size > 1 && row.lastDetectedNumber == row.number.trim() && !row.detecting) {
                                Row(
                                    Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Color(0xFFE3F2FD)).clickable { carrierCandidatesIndex = index }.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Info, null, tint = Color(0xFF1565C0), modifier = Modifier.size(20.dp))
                                    Spacer(Modifier.width(8.dp))
                                    Text("偵測到此單號同時符合多家物流商規則", modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodySmall, color = Color(0xFF1F2937))
                                    Icon(Icons.Default.ChevronRight, null, tint = Color(0xFF1565C0))
                                }
                            } else if (row.selectedCarrier == null && (row.detectFailed || (row.lastDetectedNumber == row.number.trim() && row.number.isNotBlank() && !row.detecting && row.candidates.isEmpty()))) {
                                Row(
                                    Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(MaterialTheme.colorScheme.errorContainer).padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.WarningAmber, null, tint = MaterialTheme.colorScheme.onErrorContainer, modifier = Modifier.size(20.dp))
                                    Spacer(Modifier.width(8.dp))
                                    Text("無法有效辨識物流商，請手動選擇", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onErrorContainer)
                                }
                            }
                            CarrierSelector(
                                row = row,
                                allCarriers = state.carriers,
                                openRequested = openCarrierSelectorKey == row.key,
                                onOpenConsumed = { if (openCarrierSelectorKey == row.key) openCarrierSelectorKey = null },
                                onSelect = { carrier -> update(index) { it.copy(selectedCarrier = carrier, extras = emptyMap(), detectFailed = false) } }
                            )
                            row.selectedCarrier?.requirements.orEmpty().forEach { req ->
                                val v = row.extras[req.key].orEmpty()
                                OutlinedTextField(
                                    v,
                                    { nv -> update(index) { it.copy(extras = it.extras + (req.key to nv)) } },
                                    Modifier.fillMaxWidth(),
                                    label = { Text(req.desc ?: req.key) },
                                    placeholder = { Text(req.placeholder.orEmpty()) },
                                    isError = v.isNotBlank() && !requirementValid(req, v),
                                    keyboardOptions = KeyboardOptions(keyboardType = when (req.keyboardType) { "number" -> KeyboardType.Number; "tel" -> KeyboardType.Phone; else -> KeyboardType.Text }),
                                    singleLine = true
                                )
                            }
                            OutlinedTextField(row.title, { v -> update(index) { it.copy(title = v) } }, Modifier.fillMaxWidth(), label = { Text("備註（選填）") }, singleLine = true)
                            OutlinedTextField(row.amount, { v -> update(index) { it.copy(amount = v.filter(Char::isDigit)) } }, Modifier.fillMaxWidth(), label = { Text("金額（選填，TWD）") }, leadingIcon = { Icon(Icons.Default.AttachMoney, null) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                            OutlinedButton(onClick = { categoryIndex = index }, modifier = Modifier.fillMaxWidth()) {
                                val selectedCategory = state.categories.firstOrNull { it.name == row.category }
                                if (selectedCategory != null) CategoryIcon(selectedCategory, Modifier.size(18.dp)) else Icon(Icons.Default.Label, null)
                                Spacer(Modifier.width(8.dp)); Text(row.category.ifBlank { "分類（選填）" }, modifier = Modifier.weight(1f)); Icon(Icons.Default.ChevronRight, null)
                            }
                        }
                    }
                }
            }
        }
    }

    carrierCandidatesIndex?.let { idx ->
        if (idx in rows.indices) {
            val candidateRow = rows[idx]
            AlertDialog(
                onDismissRequest = { carrierCandidatesIndex = null },
                title = { Text("符合規則的物流商") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        candidateRow.candidates.forEach { carrier ->
                            TextButton(
                                onClick = {
                                    update(idx) { it.copy(selectedCarrier = carrier, extras = emptyMap(), detectFailed = false) }
                                    carrierCandidatesIndex = null
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text(carrier.name, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Start, color = Color.Black) }
                        }
                    }
                },
                confirmButton = {},
                dismissButton = {
                    TextButton(onClick = {
                        carrierCandidatesIndex = null
                        openCarrierSelectorKey = candidateRow.key
                    }) { Text("都不是，查看其他", color = Color.Black) }
                }
            )
        } else carrierCandidatesIndex = null
    }

    categoryIndex?.let { idx ->
        if (idx in rows.indices) CategorySheet(rows[idx].category, state.categories, { categoryIndex = null }) { c -> update(idx) { it.copy(category = c) }; categoryIndex = null }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CarrierSelector(
    row: ImportRowUi,
    allCarriers: List<Carrier>,
    openRequested: Boolean = false,
    onOpenConsumed: () -> Unit = {},
    onSelect: (Carrier) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    LaunchedEffect(openRequested) {
        if (openRequested) {
            expanded = true
            onOpenConsumed()
        }
    }
    ExposedDropdownMenuBox(expanded, { expanded = it }) {
        OutlinedTextField(
            row.selectedCarrier?.name.orEmpty(), {}, readOnly = true,
            modifier = Modifier.menuAnchor().fillMaxWidth(),
            label = { Text("物流商") },
            placeholder = { Text("請選擇物流商") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }
        )
        ExposedDropdownMenu(expanded, { expanded = false }) {
            allCarriers.forEach { carrier -> DropdownMenuItem({ Text(carrier.name) }, { onSelect(carrier); expanded = false }) }
        }
    }
}

private fun requirementValid(req: CarrierRequirement, value: String): Boolean = value.isNotBlank() && (req.regex.isNullOrBlank() || runCatching { Regex(req.regex).matches(value) }.getOrDefault(false))
private fun isImportRowValid(row: ImportRowUi): Boolean {
    val carrier = row.selectedCarrier ?: return false
    if (row.number.isBlank()) return false
    return carrier.requirements.orEmpty().all { req -> requirementValid(req, row.extras[req.key].orEmpty()) }
}

@Composable
private fun EmptyState(title: String, message: String, action: String?, onClick: (() -> Unit)?) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(32.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(6.dp)); Text(message, style = MaterialTheme.typography.bodyMedium)
            if (action != null && onClick != null) { Spacer(Modifier.height(14.dp)); Button(onClick = onClick) { Text(action) } }
        }
    }
}

@Composable
private fun TokenDialog(onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var value by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Track.TW API Token") },
        text = { Column { Text("會員中心 → API 產生，只貼 Token 本身，不需要 Bearer", style = MaterialTheme.typography.bodySmall); Spacer(Modifier.height(8.dp)); OutlinedTextField(value, { value = it }, label = { Text("Token") }, singleLine = true, visualTransformation = PasswordVisualTransformation()) } },
        confirmButton = { Button(onClick = { onSave(value) }, enabled = value.isNotBlank()) { Text("儲存並驗證") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("取消") } }
    )
}

@Composable
private fun TextValueDialog(title: String, label: String, initial: String, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var value by remember(initial) { mutableStateOf(initial) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(title) }, text = { OutlinedTextField(value, { value = it }, label = { Text(label) }, singleLine = true) }, confirmButton = { Button(onClick = { onSave(value) }) { Text("儲存") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("取消") } })
}

@Composable
private fun AmountDialog(initial: Long?, onDismiss: () -> Unit, onSave: (Long?) -> Unit) {
    var value by remember(initial) { mutableStateOf(initial?.toString().orEmpty()) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("記錄金額") }, text = { OutlinedTextField(value, { value = it.filter(Char::isDigit) }, label = { Text("金額（NT$）") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true) }, confirmButton = { Button(onClick = { onSave(value.toLongOrNull()) }) { Text("儲存") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("取消") } })
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun CategorySheet(selected: String, categories: List<CategoryEntity>, onDismiss: () -> Unit, onSelect: (String) -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 20.dp)) {
            Text("選擇分類", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(14.dp))
            if (categories.isEmpty()) {
                Text("目前沒有分類，可到設定 → 分類調整新增", color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    categories.forEach { c ->
                        FilterChip(
                            selected = selected == c.name,
                            onClick = { onSelect(c.name) },
                            label = { Text(c.name) },
                            leadingIcon = { CategoryIcon(c, Modifier.size(18.dp)) }
                        )
                    }
                }
            }
            if (selected.isNotBlank()) {
                Spacer(Modifier.height(12.dp))
                TextButton(onClick = { onSelect("") }) { Text("清除分類") }
            }
        }
    }
}

@Composable
private fun CategoryIcon(category: CategoryEntity, modifier: Modifier = Modifier) {
    if (category.iconType == "emoji" && category.iconValue.isNotBlank()) {
        Text(category.iconValue, modifier = modifier, textAlign = TextAlign.Center)
    } else {
        Icon(materialIcon(category.iconValue), contentDescription = category.name, modifier = modifier)
    }
}

private fun materialIcon(name: String): ImageVector = when (name) {
    "restaurant" -> Icons.Default.Restaurant
    "shopping_basket" -> Icons.Default.ShoppingBasket
    "home" -> Icons.Default.Home
    "edit" -> Icons.Default.Edit
    "devices" -> Icons.Default.Devices
    "kitchen" -> Icons.Default.Kitchen
    "checkroom" -> Icons.Default.Checkroom
    "face" -> Icons.Default.Face
    "medical_services" -> Icons.Default.MedicalServices
    "sports_soccer" -> Icons.Default.SportsSoccer
    "directions_car" -> Icons.Default.DirectionsCar
    "build" -> Icons.Default.Build
    "construction" -> Icons.Default.Construction
    "confirmation_number" -> Icons.Default.ConfirmationNumber
    "menu_book" -> Icons.Default.MenuBook
    "pets" -> Icons.Default.Pets
    "toys" -> Icons.Default.Toys
    "child_care" -> Icons.Default.ChildCare
    "account_balance" -> Icons.Default.AccountBalance
    "block" -> Icons.Default.Block
    "headphones" -> Icons.Default.Headphones
    "computer" -> Icons.Default.Computer
    "sports_esports" -> Icons.Default.SportsEsports
    "local_shipping" -> Icons.Default.LocalShipping
    "inventory_2" -> Icons.Default.Inventory2
    else -> Icons.Default.Category
}

private val materialIconChoices = listOf(
    "restaurant" to "餐飲",
    "shopping_basket" to "購物",
    "home" to "居家",
    "edit" to "文具",
    "devices" to "裝置",
    "kitchen" to "家電",
    "checkroom" to "服飾",
    "face" to "美妝",
    "medical_services" to "醫療",
    "sports_soccer" to "運動",
    "directions_car" to "汽車",
    "build" to "工具",
    "construction" to "建材",
    "confirmation_number" to "票券",
    "menu_book" to "書籍",
    "pets" to "寵物",
    "toys" to "玩具",
    "child_care" to "母嬰",
    "account_balance" to "金融",
    "headphones" to "耳機",
    "computer" to "電腦",
    "sports_esports" to "遊戲",
    "local_shipping" to "物流",
    "inventory_2" to "包裹",
    "block" to "非商品",
    "category" to "其他"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CategoryManagerSheet(
    categories: List<CategoryEntity>,
    onDismiss: () -> Unit,
    onAdd: (String, String, String) -> Unit,
    onEdit: (CategoryEntity, String, String, String) -> Unit,
    onDelete: (CategoryEntity) -> Unit
) {
    var editing by remember { mutableStateOf<CategoryEntity?>(null) }
    var adding by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<CategoryEntity?>(null) }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 24.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("分類調整", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                FilledTonalButton(onClick = { adding = true }) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("新增") }
            }
            Spacer(Modifier.height(10.dp))
            if (categories.isEmpty()) Text("目前沒有分類", color = MaterialTheme.colorScheme.onSurfaceVariant)
            categories.forEach { category ->
                ListItem(
                    headlineContent = { Text(category.name) },
                    leadingContent = {
                        Surface(Modifier.size(38.dp), shape = RoundedCornerShape(10.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CategoryIcon(category, Modifier.size(22.dp)) }
                        }
                    },
                    trailingContent = {
                        Row {
                            IconButton(onClick = { editing = category }) { Icon(Icons.Default.Edit, "編輯") }
                            IconButton(onClick = { deleting = category }) { Icon(Icons.Default.Delete, "刪除", tint = MaterialTheme.colorScheme.error) }
                        }
                    },
                    colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                )
                HorizontalDivider()
            }
        }
    }

    if (adding) CategoryEditDialog(
        initial = null,
        onDismiss = { adding = false },
        onSave = { name, type, value -> onAdd(name, type, value); adding = false }
    )
    editing?.let { category ->
        CategoryEditDialog(
            initial = category,
            onDismiss = { editing = null },
            onSave = { name, type, value -> onEdit(category, name, type, value); editing = null }
        )
    }
    deleting?.let { category ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("刪除分類「${category.name}」？") },
            text = { Text("使用此分類的包裹會改成未分類，包裹本身不會被刪除") },
            confirmButton = {
                Button(
                    onClick = { onDelete(category); deleting = null },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) { Text("刪除") }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("取消") } }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun CategoryEditDialog(
    initial: CategoryEntity?,
    onDismiss: () -> Unit,
    onSave: (String, String, String) -> Unit
) {
    var name by remember(initial) { mutableStateOf(initial?.name.orEmpty()) }
    var iconType by remember(initial) { mutableStateOf(initial?.iconType ?: "material") }
    var iconValue by remember(initial) { mutableStateOf(initial?.iconValue ?: "category") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "新增分類" else "編輯分類") },
        text = {
            Column {
                OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), label = { Text("分類名稱") }, singleLine = true)
                Spacer(Modifier.height(12.dp))
                SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                    SegmentedButton(selected = iconType == "material", onClick = { iconType = "material" }, shape = SegmentedButtonDefaults.itemShape(0, 2)) { Text("內建圖標") }
                    SegmentedButton(selected = iconType == "emoji", onClick = { iconType = "emoji" }, shape = SegmentedButtonDefaults.itemShape(1, 2)) { Text("Emoji") }
                }
                Spacer(Modifier.height(12.dp))
                if (iconType == "emoji") {
                    OutlinedTextField(
                        iconValue,
                        { iconValue = it.take(8) },
                        Modifier.fillMaxWidth(),
                        label = { Text("Emoji") },
                        placeholder = { Text("例如 🎧") },
                        singleLine = true
                    )
                } else {
                    Text("選擇圖標", style = MaterialTheme.typography.labelLarge)
                    Spacer(Modifier.height(8.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        materialIconChoices.forEach { (value, label) ->
                            FilterChip(
                                selected = iconValue == value,
                                onClick = { iconValue = value },
                                label = { Text(label) },
                                leadingIcon = { Icon(materialIcon(value), null, Modifier.size(18.dp)) }
                            )
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("預覽：", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.width(6.dp))
                    val preview = CategoryEntity("preview", name.ifBlank { "分類" }, iconType, iconValue, 0)
                    CategoryIcon(preview, Modifier.size(22.dp)); Spacer(Modifier.width(6.dp)); Text(preview.name)
                }
            }
        },
        confirmButton = { Button(onClick = { onSave(name.trim(), iconType, iconValue.ifBlank { if (iconType == "emoji") "📦" else "category" }) }, enabled = name.isNotBlank()) { Text("儲存") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("取消") } }
    )
}

@Composable
private fun themeScheme(seed: Color): ColorScheme {
    fun contrastOn(color: Color): Color = if (color.luminance() > .48f) Color(0xFF161616) else Color.White

    // Derive the complete tonal family from the user's seed color.  Material components such as
    // FilterChip, NavigationBar and FilledTonalButton mainly use secondary/tertiary containers;
    // leaving those at lightColorScheme() defaults is what caused the old purple accents to remain.
    val primaryContainer = mixColor(seed, Color.White, .80f)
    val secondary = mixColor(seed, Color(0xFF5F6368), .34f)
    val secondaryContainer = mixColor(seed, Color.White, .86f)
    val tertiary = mixColor(seed, Color(0xFF6A5F68), .42f)
    val tertiaryContainer = mixColor(seed, Color.White, .89f)
    val surfaceVariant = mixColor(seed, Color(0xFFF3F3F5), .94f)
    val outline = mixColor(seed, Color(0xFF74777F), .78f)

    return lightColorScheme(
        primary = seed,
        onPrimary = contrastOn(seed),
        primaryContainer = primaryContainer,
        onPrimaryContainer = contrastOn(primaryContainer),
        secondary = secondary,
        onSecondary = contrastOn(secondary),
        secondaryContainer = secondaryContainer,
        onSecondaryContainer = contrastOn(secondaryContainer),
        tertiary = tertiary,
        onTertiary = contrastOn(tertiary),
        tertiaryContainer = tertiaryContainer,
        onTertiaryContainer = contrastOn(tertiaryContainer),
        surfaceVariant = surfaceVariant,
        onSurfaceVariant = Color(0xFF44474E),
        outline = outline,
        surfaceTint = seed,
        inversePrimary = mixColor(seed, Color.White, .35f)
    )
}

private fun mixColor(a: Color, b: Color, t: Float): Color = Color(
    red = a.red * (1 - t) + b.red * t,
    green = a.green * (1 - t) + b.green * t,
    blue = a.blue * (1 - t) + b.blue * t,
    alpha = 1f
)

private enum class ColorInputMode(val label: String) { HEX("Hex"), RGB("RGB"), HSL("HSL"), HSV("HSV"), OKLCH("OKLCH") }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ThemeColorDialog(initial: Color, onDismiss: () -> Unit, onSave: (Color) -> Unit) {
    val initialHsv = remember(initial) { FloatArray(3).also { android.graphics.Color.colorToHSV(initial.toArgb(), it) } }
    var hue by remember(initial) { mutableFloatStateOf(initialHsv[0]) }
    var saturation by remember(initial) { mutableFloatStateOf(initialHsv[1]) }
    var value by remember(initial) { mutableFloatStateOf(initialHsv[2]) }
    var mode by remember { mutableStateOf(ColorInputMode.HEX) }
    var modeMenu by remember { mutableStateOf(false) }

    fun currentColor(): Color = Color(android.graphics.Color.HSVToColor(floatArrayOf(hue, saturation, value)))
    var input by remember(initial) { mutableStateOf(formatColorValue(initial, mode)) }
    fun applyColor(c: Color) {
        val h = FloatArray(3)
        android.graphics.Color.colorToHSV(c.toArgb(), h)
        hue = h[0]; saturation = h[1]; value = h[2]
        input = formatColorValue(c, mode)
    }
    fun syncInput() { input = formatColorValue(currentColor(), mode) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("主題色") },
        text = {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                BoxWithConstraints(Modifier.fillMaxWidth().aspectRatio(1f)) {
                    Canvas(
                        Modifier.fillMaxSize().padding(8.dp).pointerInput(Unit) {
                            var ringDrag = false
                            fun update(pos: Offset, forceRing: Boolean? = null) {
                                val center = Offset(size.width / 2f, size.height / 2f)
                                val dx = pos.x - center.x
                                val dy = pos.y - center.y
                                val radius = min(size.width, size.height) / 2f
                                val innerRadius = radius * .72f
                                val distance = sqrt(dx * dx + dy * dy)
                                val isRing = forceRing ?: (distance > innerRadius * 1.03f)
                                if (isRing) {
                                    hue = ((Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())) + 360.0) % 360.0).toFloat()
                                } else {
                                    val half = innerRadius / sqrt(2f)
                                    saturation = ((dx / half + 1f) / 2f).coerceIn(0f, 1f)
                                    value = (1f - ((dy / half + 1f) / 2f)).coerceIn(0f, 1f)
                                }
                                syncInput()
                            }
                            detectDragGestures(
                                onDragStart = { pos ->
                                    val center = Offset(size.width / 2f, size.height / 2f)
                                    val dx = pos.x - center.x
                                    val dy = pos.y - center.y
                                    val radius = min(size.width, size.height) / 2f
                                    ringDrag = sqrt(dx * dx + dy * dy) > radius * .74f
                                    update(pos, ringDrag)
                                }
                            ) { change, _ -> update(change.position, ringDrag) }
                        }
                    ) {
                        val radius = min(size.width, size.height) / 2f
                        val ringWidth = radius * .13f
                        val innerRadius = radius * .72f
                        drawCircle(
                            brush = Brush.sweepGradient(
                                listOf(Color.Red, Color.Yellow, Color.Green, Color.Cyan, Color.Blue, Color.Magenta, Color.Red),
                                center = center
                            ),
                            radius = radius - ringWidth / 2f,
                            style = Stroke(width = ringWidth)
                        )
                        val hueColor = Color(android.graphics.Color.HSVToColor(floatArrayOf(hue, 1f, 1f)))
                        drawCircle(
                            brush = Brush.horizontalGradient(listOf(Color.White, hueColor), startX = center.x - innerRadius, endX = center.x + innerRadius),
                            radius = innerRadius
                        )
                        drawCircle(
                            brush = Brush.verticalGradient(listOf(Color.Transparent, Color.Black), startY = center.y - innerRadius, endY = center.y + innerRadius),
                            radius = innerRadius
                        )
                        val angle = Math.toRadians(hue.toDouble())
                        val ringR = radius - ringWidth / 2f
                        val huePoint = Offset(center.x + cos(angle).toFloat() * ringR, center.y + sin(angle).toFloat() * ringR)
                        drawCircle(Color.White, 8f, huePoint)
                        drawCircle(hueColor, 5f, huePoint)

                        val half = innerRadius / sqrt(2f)
                        val svPoint = Offset(
                            center.x + (saturation * 2f - 1f) * half,
                            center.y + ((1f - value) * 2f - 1f) * half
                        )
                        drawCircle(Color.White, 9f, svPoint)
                        drawCircle(currentColor(), 6f, svPoint)
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Surface(Modifier.size(34.dp), shape = CircleShape, color = currentColor(), border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)) {}
                    Spacer(Modifier.width(10.dp))
                    ExposedDropdownMenuBox(expanded = modeMenu, onExpandedChange = { modeMenu = it }) {
                        OutlinedTextField(
                            value = mode.label,
                            onValueChange = {},
                            readOnly = true,
                            modifier = Modifier.width(120.dp).menuAnchor(),
                            label = { Text("格式") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(modeMenu) },
                            singleLine = true
                        )
                        ExposedDropdownMenu(expanded = modeMenu, onDismissRequest = { modeMenu = false }) {
                            ColorInputMode.entries.forEach { option ->
                                DropdownMenuItem(
                                    text = { Text(option.label) },
                                    onClick = {
                                        mode = option
                                        input = formatColorValue(currentColor(), option)
                                        modeMenu = false
                                    },
                                    trailingIcon = { if (mode == option) Icon(Icons.Default.Check, null) }
                                )
                            }
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = input,
                    onValueChange = { text ->
                        input = text
                        parseColorValue(text, mode)?.let { c ->
                            val h = FloatArray(3)
                            android.graphics.Color.colorToHSV(c.toArgb(), h)
                            hue = h[0]; saturation = h[1]; value = h[2]
                        }
                    },
                    label = { Text(mode.label) },
                    supportingText = { Text(colorInputHint(mode)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = { Button(onClick = { onSave(currentColor()) }) { Text("套用") } },
        dismissButton = {
            Row {
                TextButton(onClick = { applyColor(Color(0xFF6750A4)) }) { Text("重設") }
                TextButton(onClick = onDismiss) { Text("取消") }
            }
        }
    )
}

private fun colorInputHint(mode: ColorInputMode): String = when (mode) {
    ColorInputMode.HEX -> "例如 #6750A4"
    ColorInputMode.RGB -> "例如 103, 80, 164"
    ColorInputMode.HSL -> "例如 256, 35, 48"
    ColorInputMode.HSV -> "例如 256, 51, 64"
    ColorInputMode.OKLCH -> "例如 0.52, 0.14, 291"
}

private fun formatColorValue(color: Color, mode: ColorInputMode): String = when (mode) {
    ColorInputMode.HEX -> String.format("#%06X", 0xFFFFFF and color.toArgb())
    ColorInputMode.RGB -> "${(color.red * 255).roundToInt()}, ${(color.green * 255).roundToInt()}, ${(color.blue * 255).roundToInt()}"
    ColorInputMode.HSL -> rgbToHsl(color).let { "${it[0].roundToInt()}, ${(it[1] * 100).roundToInt()}, ${(it[2] * 100).roundToInt()}" }
    ColorInputMode.HSV -> FloatArray(3).also { android.graphics.Color.colorToHSV(color.toArgb(), it) }.let { "${it[0].roundToInt()}, ${(it[1] * 100).roundToInt()}, ${(it[2] * 100).roundToInt()}" }
    ColorInputMode.OKLCH -> rgbToOklch(color).let { String.format(Locale.US, "%.3f, %.3f, %.1f", it[0], it[1], it[2]) }
}

private fun parseColorValue(text: String, mode: ColorInputMode): Color? = runCatching {
    when (mode) {
        ColorInputMode.HEX -> {
            val clean = text.trim().removePrefix("#")
            if (clean.length != 6) return@runCatching null
            Color((0xFF000000L or clean.toLong(16)).toInt())
        }
        ColorInputMode.RGB -> {
            val n = numericParts(text); if (n.size < 3) return@runCatching null
            Color(android.graphics.Color.rgb(n[0].roundToInt().coerceIn(0,255), n[1].roundToInt().coerceIn(0,255), n[2].roundToInt().coerceIn(0,255)))
        }
        ColorInputMode.HSL -> {
            val n = numericParts(text); if (n.size < 3) return@runCatching null
            hslToRgb(n[0].toFloat(), (n[1] / 100.0).toFloat(), (n[2] / 100.0).toFloat())
        }
        ColorInputMode.HSV -> {
            val n = numericParts(text); if (n.size < 3) return@runCatching null
            Color(android.graphics.Color.HSVToColor(floatArrayOf(n[0].toFloat(), (n[1] / 100.0).toFloat().coerceIn(0f,1f), (n[2] / 100.0).toFloat().coerceIn(0f,1f))))
        }
        ColorInputMode.OKLCH -> {
            val n = numericParts(text); if (n.size < 3) return@runCatching null
            oklchToRgb(n[0], n[1], n[2])
        }
    }
}.getOrNull()

private fun numericParts(text: String): List<Double> = Regex("-?\\d+(?:\\.\\d+)?").findAll(text).mapNotNull { it.value.toDoubleOrNull() }.toList()

private fun rgbToHsl(c: Color): FloatArray {
    val r = c.red; val g = c.green; val b = c.blue
    val maxC = max(r, max(g, b)); val minC = min(r, min(g, b)); val d = maxC - minC
    val l = (maxC + minC) / 2f
    val s = if (d == 0f) 0f else d / (1f - abs(2f * l - 1f))
    val h = when {
        d == 0f -> 0f
        maxC == r -> 60f * (((g - b) / d) % 6f)
        maxC == g -> 60f * (((b - r) / d) + 2f)
        else -> 60f * (((r - g) / d) + 4f)
    }.let { if (it < 0f) it + 360f else it }
    return floatArrayOf(h, s.coerceIn(0f,1f), l.coerceIn(0f,1f))
}

private fun hslToRgb(h: Float, s0: Float, l0: Float): Color {
    val s = s0.coerceIn(0f,1f); val l = l0.coerceIn(0f,1f)
    val c = (1f - abs(2f * l - 1f)) * s
    val hp = ((h % 360f) + 360f) % 360f / 60f
    val x = c * (1f - abs(hp % 2f - 1f))
    val (r1,g1,b1) = when {
        hp < 1 -> Triple(c,x,0f); hp < 2 -> Triple(x,c,0f); hp < 3 -> Triple(0f,c,x)
        hp < 4 -> Triple(0f,x,c); hp < 5 -> Triple(x,0f,c); else -> Triple(c,0f,x)
    }
    val m = l - c/2f
    return Color(android.graphics.Color.rgb(((r1+m)*255).roundToInt().coerceIn(0,255), ((g1+m)*255).roundToInt().coerceIn(0,255), ((b1+m)*255).roundToInt().coerceIn(0,255)))
}

private fun srgbToLinear(x: Double): Double = if (x <= 0.04045) x / 12.92 else ((x + 0.055) / 1.055).pow(2.4)
private fun linearToSrgb(x: Double): Double = if (x <= 0.0031308) 12.92 * x else 1.055 * x.pow(1.0/2.4) - 0.055

private fun rgbToOklch(c: Color): DoubleArray {
    val r = srgbToLinear(c.red.toDouble()); val g = srgbToLinear(c.green.toDouble()); val b = srgbToLinear(c.blue.toDouble())
    val l = 0.4122214708*r + 0.5363325363*g + 0.0514459929*b
    val m = 0.2119034982*r + 0.6806995451*g + 0.1073969566*b
    val s = 0.0883024619*r + 0.2817188376*g + 0.6299787005*b
    val l_ = cbrt(l); val m_ = cbrt(m); val s_ = cbrt(s)
    val L = 0.2104542553*l_ + 0.7936177850*m_ - 0.0040720468*s_
    val a = 1.9779984951*l_ - 2.4285922050*m_ + 0.4505937099*s_
    val bb = 0.0259040371*l_ + 0.7827717662*m_ - 0.8086757660*s_
    val C = sqrt(a*a + bb*bb)
    var H = Math.toDegrees(atan2(bb, a)); if (H < 0) H += 360.0
    return doubleArrayOf(L, C, H)
}

private fun oklchToRgb(L: Double, C: Double, H: Double): Color {
    val hr = Math.toRadians(H)
    val a = C * cos(hr); val b = C * sin(hr)
    val l_ = L + 0.3963377774*a + 0.2158037573*b
    val m_ = L - 0.1055613458*a - 0.0638541728*b
    val s_ = L - 0.0894841775*a - 1.2914855480*b
    val l = l_.pow(3.0); val m = m_.pow(3.0); val ss = s_.pow(3.0)
    val rLin = 4.0767416621*l - 3.3077115913*m + 0.2309699292*ss
    val gLin = -1.2684380046*l + 2.6097574011*m - 0.3413193965*ss
    val bLin = -0.0041960863*l - 0.7034186147*m + 1.7076147010*ss
    val r = (linearToSrgb(rLin).coerceIn(0.0,1.0)*255).roundToInt()
    val g = (linearToSrgb(gLin).coerceIn(0.0,1.0)*255).roundToInt()
    val bl = (linearToSrgb(bLin).coerceIn(0.0,1.0)*255).roundToInt()
    return Color(android.graphics.Color.rgb(r,g,bl))
}

private fun formatEventTime(event: PackageHistory): String {
    if ((event.time ?: 0L) > 0L) return SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.TAIWAN).format(Date(event.time!! * 1000L))
    return formatIso(event.createdAt)
}
private fun formatIso(value: String?): String {
    if (value.isNullOrBlank()) return "時間未提供"
    return runCatching {
        val src = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US)
        src.timeZone = TimeZone.getTimeZone("UTC")
        val d = src.parse(value.take(19)) ?: return@runCatching value
        SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.TAIWAN).format(d)
    }.getOrDefault(value)
}
private fun relativeTime(value: String?): String {
    if (value.isNullOrBlank()) return "未知"
    val date = runCatching {
        val src = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
        src.parse(value.take(19))
    }.getOrNull() ?: return formatIso(value)
    val diff = (System.currentTimeMillis() - date.time).coerceAtLeast(0L)
    val minutes = diff / 60_000L
    return when {
        minutes < 1 -> "剛剛"
        minutes < 60 -> "${minutes} 分鐘前"
        minutes < 1440 -> "${minutes / 60} 小時前"
        minutes < 4320 -> "${minutes / 1440} 天前"
        else -> SimpleDateFormat("MM/dd", Locale.TAIWAN).format(date)
    }
}
