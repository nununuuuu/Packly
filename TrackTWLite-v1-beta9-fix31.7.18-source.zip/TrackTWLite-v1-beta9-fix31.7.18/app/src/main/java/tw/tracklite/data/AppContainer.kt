package tw.tracklite.data

import android.content.Context
import androidx.room.Room
import tw.tracklite.data.api.ApiFactory
import tw.tracklite.data.db.TrackDb
import tw.tracklite.data.db.MIGRATION_6_7
import tw.tracklite.data.db.MIGRATION_7_8
import tw.tracklite.data.db.MIGRATION_8_9
import tw.tracklite.data.db.MIGRATION_9_10
import tw.tracklite.data.repo.PackageRepository
import tw.tracklite.data.sync.PackageSyncCoordinator
import tw.tracklite.widget.WidgetInvalidator

class AppContainer(context: Context) {
    val settings = SettingsStore(context)
    val db = Room.databaseBuilder(context, TrackDb::class.java, "tracklite.db")
        .addMigrations(MIGRATION_6_7, MIGRATION_7_8, MIGRATION_8_9, MIGRATION_9_10)
        .fallbackToDestructiveMigration()
        .build()
    val api by lazy { ApiFactory.create(settings) }
    val repository by lazy { PackageRepository(api, db.packages(), db.categories()) }
    val widgetInvalidator by lazy { WidgetInvalidator(context.applicationContext) }
    val syncCoordinator by lazy { PackageSyncCoordinator(repository, widgetInvalidator, context.applicationContext) }
}
